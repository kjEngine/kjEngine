package de.kjEngine.test;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class JS {

	public static void main(String[] args) throws ScriptException, IOException {
		ScriptEngineManager sem = new ScriptEngineManager();
		ScriptEngine e = sem.getEngineByName("LOGO");
		e.eval(new String(Files.readAllBytes(Paths.get("test.js"))));
	}
}
