package de.kjEngine.test;

import de.kjEngine.core.EntryPoint;
import de.kjEngine.core.api.States;

public class BuildTest {
	
	public static void main(String[] args) {
		EntryPoint.launch("/de/kjEngine/test/build.properties", args);
	}

	public static States getComponent(String[] args) {
		System.out.println("hello, it works");
		return null;
	}
}
