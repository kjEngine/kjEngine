package de.kjEngine.test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class LineCounter {

	public static void main(String[] args) {
		printLines("src/de/kjEngine");
	}

	private static void printLines(String string) {
		File file = new File(string);
		List<File> files = new ArrayList<>();
		search(files, file);
		try {
			System.out.println(countLines(files, new BufferedWriter(new FileWriter(new File("whole_src.txt")))));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static int countLines(List<File> files, BufferedWriter dest) {
		int result = 0;
		for (File file : files) {
			result += countLines(file, dest);
		}
		return result;
	}

	private static int countLines(File file, BufferedWriter dest) {
		int result = 0;
		try (BufferedReader r = new BufferedReader(new FileReader(file))) {
			String line;
			while ((line = r.readLine()) != null) {
				result++;
				dest.write(line + "\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return result;
	}

	private static void search(List<File> files, File file) {
		if (file.isDirectory()) {
			File[] f = file.listFiles();
			for (File e : f) {
				search(files, e);
			}
		} else {
			files.add(file);
		}
	}
}
