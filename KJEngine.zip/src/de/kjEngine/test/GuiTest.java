package de.kjEngine.test;

import static org.lwjgl.opengl.GL11.*;

import org.lwjgl.opengl.Display;
import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector4f;

import de.kjEngine.core.api.Camera;
import de.kjEngine.core.api.FirstPersonCamera;
import de.kjEngine.core.api.ViewPortSetting;
import de.kjEngine.core.awt.DisplayManager;
import de.kjEngine.core.awt.KButton;
import de.kjEngine.core.awt.KColor;
import de.kjEngine.core.awt.KComboBox;
import de.kjEngine.core.awt.KPanel;
import de.kjEngine.core.awt.KScrollBar;
import de.kjEngine.core.awt.KTextInputGui;
import de.kjEngine.core.awt.KTickBox;
import de.kjEngine.core.awt.font.FontType;
import de.kjEngine.core.awt.font.GUIText;
import de.kjEngine.core.awt.font.Text;
import de.kjEngine.core.mainrendering.Renderer;
import de.kjEngine.core.model.Rectangle;
import de.kjEngine.core.util.KJEngineException;
import de.kjEngine.core.util.Loader;

public class GuiTest {

	public static void main(String[] args) {
		try {
			DisplayManager.create(720, 400, "gui tests", false, false);
		} catch (KJEngineException e1) {
			e1.printStackTrace();
		}
		
		FontType font = new FontType(Loader.loadTexturei("fonts/retro.png"), "fonts/retro.fnt");
		
		Camera cam = new FirstPersonCamera();
		Renderer renderer = new Renderer(new ViewPortSetting(60f, DisplayManager.getAspect(), 0.1f, 100f), cam);
		renderer.setClearColor(new Vector4f(1f,  0f,  0f,  1f));
		
		KPanel panel = new KPanel(0.5f, 0.5f, 1f, 1f);
		panel.setForeground(Loader.loadColorToTexture(new Vector4f(0.7f, 0.7f, 0.7f, 1f)));
		panel.setVisible(true);
		
		KButton button = new KButton(0f, 0f, 0.2f, 0.2f);
		GUIText t0 = new GUIText("Hi", 1f, font, new Vector2f(), 1f, true, false);
		t0.setColour(1f, 0f, 0f);
		button.setText("hi");
		button.setVisible(true);
		panel.add(button);
		
		KButton button2 = new KButton(0.1f, 0.1f, 0.2f, 0.2f);
		button2.setVisible(true);
		panel.add(button2);
		
		KScrollBar sb = new KScrollBar(0f, 0.2f, 0.2f, 0.1f);
		sb.setVisible(true);
		panel.add(sb);
		
		KTextInputGui inputGui = new KTextInputGui(1f, 1f, 0.5f, 0.1f);
		inputGui.setForeground(KColor.GRAY_09.getId());
		inputGui.setText("hi");
		inputGui.setVisible(true);
		panel.add(inputGui);
		
		KComboBox cb = new KComboBox(0.2f, 0.7f, 0.4f, 0.1f, font, 1f);
		cb.setForeground(KColor.GRAY_08.getId());
		cb.setFont(font);
		cb.addElement("Hi");
		cb.addElement("Hi");
		cb.addElement("Hi");
		cb.addElement("Hi");
		cb.setVisible(true);
		panel.add(cb);
		
		KTickBox box = new KTickBox(0.2f, 0.2f, 0.1f, 0.1f);
//		box.setBackground(ImageCache.TICKBOX_DESELECTED);
//		box.setForeground(ImageCache.TICKBOX_DESELECTED);
//		box.setSelectedTexture(ImageCache.TICKBOX_SELECTED);
//		box.setDeselectedTexture(ImageCache.TICKBOX_SELECTED);
//		box.setVisible(true);
		panel.add(box);
		
		//DisplayManager.getRootPanel().setForeground(Loader.loadColorToTexture(renderer.getClearColor()));
		DisplayManager.getRootPanel().add(panel);
		
		while(!Display.isCloseRequested()) {
			
			renderer.clear();
			DisplayManager.getRootPanel().render(renderer.getGuiRenderer());
			glClear(GL_DEPTH_BUFFER_BIT);
			GUIText t1 = new GUIText("Hi!", 3f, font, new Vector2f(), 3f, false, false);
			t1.setColour(1f, 0f, 0f);
			renderer.getGuiRenderer().getFontRenderer().render(new Text(font, t1), new Rectangle(-1f, -1f, 2f, 2f));
			
			try {
				DisplayManager.update();
			} catch (KJEngineException e) {
				e.printStackTrace();
			}
			Display.setTitle("gui tests  | " + DisplayManager.getFps() + " fps");
		}
		renderer.cleanUp();
		DisplayManager.destroy();
		
		System.exit(0);
	}
}
