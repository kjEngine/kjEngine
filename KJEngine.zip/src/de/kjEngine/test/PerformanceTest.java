package de.kjEngine.test;

import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferStrategy;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;

public class PerformanceTest {

	private static Image TEST_IMG;
	static {
		try {
			TEST_IMG = ImageIO.read(new File("res/images/tiles/dirt.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		JFrame frame = new JFrame("test");
		Canvas c = new Canvas();
		c.setSize(1280, 720);
		frame.add(c);
		frame.pack();
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
		BufferStrategy bs = null;

		long lastTime = System.currentTimeMillis();
		int frames = 0;
		
		while (true) {
			bs = c.getBufferStrategy();
			if (bs == null) {
				c.createBufferStrategy(3);
				continue;
			}
			Graphics g = bs.getDrawGraphics();
			render(g);
			bs.show();
			g.dispose();
			frames++;
			if (System.currentTimeMillis() - lastTime > 1000) {
				frame.setTitle("test | " + frames + " fps");
				frames = 0;
				lastTime += 1000;
			}
		}
	}

	private static void render(Graphics g) {
		g.fillRect(0, 0, 1280, 720);
		int w = 1280 / 18;
		for (int y = 0; y < 10; y++) {
			for (int x = 0; x < 18; x++) {
				g.drawImage(TEST_IMG, x * w, y * w, w, w, null);
			}
		}
	}
}
