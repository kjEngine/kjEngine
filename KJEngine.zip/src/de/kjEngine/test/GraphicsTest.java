package de.kjEngine.test;

import static de.kjEngine.core.GameEngine.*;

import org.lwjgl.opengl.Display;
import org.lwjgl.util.vector.Vector3f;
import org.lwjgl.util.vector.Vector4f;

import de.kjEngine.core.EngineSettings;
import de.kjEngine.core.api.Entity;
import de.kjEngine.core.api.States;
import de.kjEngine.core.awt.DisplayManager;
import de.kjEngine.core.awt.KColor;
import de.kjEngine.core.util.KTexture;
import de.kjEngine.core.util.Loader;

public class GraphicsTest {

	public static void main(String[] args) {
		addStatesObject(new States() {

			@Override
			public void init() {
				getRenderer().setClearColor(new Vector4f(1f, 0f, 0f, 1f));
				addEntity("plane", new Entity(new Vector3f(0f, 0f, 10f), 0f, 0f, 0f, new Vector3f(1f, 1f, 1f),
						Loader.loadObjModel("res/planes/plane0.obj", new KTexture(KColor.GREEN.getId()), "")));
			}

			@Override
			public void dispose() {
			}

			@Override
			public void action() {
				Display.setTitle("test | " + DisplayManager.getFps());
			}
		});
		EngineSettings s = new EngineSettings();
		s.width = 1280;
		s.height = 600;
		s.title = "test";
		s.resizable = false;
		s.console = false;
		setRender(true);
		setMode(Mode.GAME);
		start(s);
	}
}
