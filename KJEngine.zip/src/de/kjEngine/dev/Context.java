package de.kjEngine.dev;

import java.util.ArrayList;
import java.util.List;

import de.kjEngine.dev.ui.DevWindow;
import de.kjEngine.dev.ui.editor.FileEditWindow;

public class Context {
	
	public static DevWindow window;
	private static List<FileEditWindow> editors = new ArrayList<>();

	public static void create() {
		window = new DevWindow();
	}
	
	public static void edit(String file) {
		FileEditWindow w = new FileEditWindow(file);
		w.setVisible(true);
		editors.add(w);
	}
	
	public static String getWorkspaceLocation() {
		return "C:/dev";
	}
}
