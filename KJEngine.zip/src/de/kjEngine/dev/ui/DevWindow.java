package de.kjEngine.dev.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;

import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.Border;
import javax.swing.plaf.basic.BasicSplitPaneDivider;
import javax.swing.plaf.basic.BasicSplitPaneUI;

import de.kj.kgui.MainWindow;
import de.kj.kgui.WindowConfig;
import de.kjEngine.dev.ui.editor.LevelEditor;

public class DevWindow extends MainWindow {
	private static final long serialVersionUID = 1L;

	private JSplitPane right, lvs, mvs, rvs;
	private ProjectExplorer projectExplorer;
	private LevelEditor levelEditor;
	private JPanel toolBar;

	public DevWindow() {
		initLookAndFeel();
		initStructure();
		initContent();
		initSizes();
		create(new WindowConfig(1280, 720, true, "kjengine", true));
	}

	private void initSizes() {
	}

	private void initLookAndFeel() {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException
				| UnsupportedLookAndFeelException e) {
			e.printStackTrace();
		}
	}

	private void initStructure() {
		right = new JSplitPane();
		applyStyle(right);
		getPanel().setRightComponent(right);
		lvs = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
		lvs.setLeftComponent(new JPanel());
		lvs.setRightComponent(new JPanel());
		applyStyle(lvs);
		getPanel().setLeftComponent(lvs);
		mvs = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
		mvs.setLeftComponent(new JPanel());
		mvs.setRightComponent(new JPanel());
		applyStyle(mvs);
		right.setLeftComponent(mvs);
		rvs = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
		rvs.setLeftComponent(new JPanel());
		rvs.setRightComponent(new JPanel());
		applyStyle(rvs);
		right.setRightComponent(rvs);
		applyStyle(getPanel());
		toolBar = new JPanel();
		toolBar.setBackground(UI.BG);
		getContentPane().add(toolBar, BorderLayout.NORTH);
	}

	private void applyStyle(JSplitPane p) {
		p.setDividerSize(4);
		p.setForeground(Color.RED);
		p.setUI(new BasicSplitPaneUI() {
			public BasicSplitPaneDivider createDefaultDivider() {
				return new BasicSplitPaneDivider(this) {
					private static final long serialVersionUID = 1L;

					public void setBorder(Border b) {
					}

					@Override
					public void paint(Graphics g) {
						g.setColor(Color.BLACK);
						g.fillRect(0, 0, getSize().width, getSize().height);
						super.paint(g);
					}
				};
			}
		});
	}

	private void initContent() {
		projectExplorer = new ProjectExplorer();
		set(0, 0, projectExplorer);
		levelEditor = new LevelEditor();
		set(1, 0, levelEditor);
	}

	public void set(int x, int y, Component c) {
		if (x == 0 && y == 0) {
			lvs.setLeftComponent(c);
		} else if (x == 0 && y == 1) {
			lvs.setRightComponent(c);
		} else if (x == 1 && y == 0) {
			mvs.setLeftComponent(c);
		} else if (x == 1 && y == 1) {
			mvs.setRightComponent(c);
		} else if (x == 2 && y == 0) {
			rvs.setLeftComponent(c);
		} else if (x == 2 && y == 1) {
			rvs.setRightComponent(c);
		}
	}

	public Component get(int x, int y) {
		if (x == 0 && y == 0) {
			return lvs.getLeftComponent();
		}
		if (x == 0 && y == 1) {
			return lvs.getRightComponent();
		}
		if (x == 1 && y == 0) {
			return mvs.getLeftComponent();
		}
		if (x == 1 && y == 1) {
			return mvs.getRightComponent();
		}
		if (x == 2 && y == 0) {
			return rvs.getLeftComponent();
		}
		if (x == 2 && y == 1) {
			return rvs.getRightComponent();
		}
		return null;
	}

	public ProjectExplorer getProjectExplorer() {
		return projectExplorer;
	}

	public LevelEditor getLevelEditor() {
		return levelEditor;
	}
}
