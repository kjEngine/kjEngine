package de.kjEngine.dev.ui;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.io.File;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.ToolTipManager;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;

import de.kjEngine.dev.Context;
import de.kjEngine.dev.ui.createn.NewClassWindow;
import de.kjEngine.dev.ui.icons.IconCache;

public class ProjectExplorer extends View {
	private static final long serialVersionUID = 1L;

	private JScrollPane pane;
	private JTree explorer;
	private JMenuBar bar;
	private JMenu file, newf, java, engine;
	private JMenuItem open, save, saveas;
	private JButton edit;

	public ProjectExplorer() {
		createMenu();
		createExplorer();
	}

	private void createMenu() {
		bar = new JMenuBar();
		file = new JMenu("file");
		file.setPreferredSize(new Dimension(20, 10));
		createNewf();
		createOpen();
		createSave();
		createSaveas();
		bar.add(file);
		header.add(bar);
		createEdit();
	}

	private void createEdit() {
		edit = new JButton(IconCache.get("edit_20.png"));
		edit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				TreePath[] selections = explorer.getSelectionPaths();
				if (selections != null) {
					TreePath path = selections[0];
					StringBuilder pathBuilder = new StringBuilder("C:");
					for (Object o : path.getPath()) {
						pathBuilder.append("/" + o.toString());
					}
					Context.edit(pathBuilder.toString());
				}
			}
		});
		header.add(edit);
	}

	private void createNewf() {
		newf = new JMenu("new");
		newf.setToolTipText("create new...");
		file.add(newf);
		
		java = new JMenu("java");
		java.setToolTipText("java category (classes, enums, interfaces, annotations)");
		
		JMenuItem classi = new JMenuItem("class");
		classi.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new NewClassWindow().setVisible(true);
			}
		});
		java.add(classi);
		
		JMenuItem enumi = new JMenuItem("enum");
		enumi.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			}
		});
		java.add(enumi);
		
		JMenuItem interfacei = new JMenuItem("interface");
		interfacei.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			}
		});
		java.add(interfacei);
		
		JMenuItem annotation = new JMenuItem("annotation");
		annotation.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			}
		});
		java.add(annotation);
		
		newf.add(java);
		
		engine = new JMenu("engine");
		engine.setToolTipText("engine category (entities)");
		
		JMenuItem entity = new JMenuItem("entity");
		entity.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			}
		});
		engine.add(entity);
		
		JMenuItem obj = new JMenuItem("obj-model");
		obj.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			}
		});
		engine.add(obj);
		
		newf.add(engine);
	}

	private void createOpen() {
		open = new JMenuItem("open");
		open.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			}
		});
		open.setToolTipText("Open file");
		file.add(open);
	}

	private void createSave() {
		save = new JMenuItem("save");
		save.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			}
		});
		save.setToolTipText("Save current resource");
		file.add(save);
	}

	private void createSaveas() {
		saveas = new JMenuItem("save as");
		saveas.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			}
		});
		saveas.setToolTipText("Save current resource as");
		file.add(saveas);
	}

	private void createExplorer() {
		pane = new JScrollPane();
		explorer = new JTree(loadFiles("C:/dev"));
		ToolTipManager.sharedInstance().registerComponent(explorer);
		explorer.setCellRenderer(new DefaultTreeCellRenderer() {
			private static final long serialVersionUID = 1L;

			@Override
			public Component getTreeCellRendererComponent(JTree tree, Object value, boolean sel, boolean expanded,
					boolean leaf, int row, boolean hasFocus) {
				super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);

				DefaultMutableTreeNode node = (DefaultMutableTreeNode) value;
				String name = node.getUserObject().toString();
				String canonicalName = "C:/" + getCanonicalName(node);
				File canonicalFile = new File(canonicalName);
				String fext;
				{
					String[] pts = name.split("\\.");
					fext = pts[pts.length - 1];
				}

				if (canonicalFile.isDirectory()) {
					setToolTipText("Folder");
					setIcon(IconCache.get("folder_20.png"));
				} else {
					switch (fext) {
					case "java":
						setToolTipText("Java source file");
						setIcon(IconCache.get("java_file_20.png"));
						break;
					case "class":
						setToolTipText("Java binary file");
						setIcon(IconCache.get("class_file_20.png"));
						break;
					case "txt":
						setToolTipText("Text file");
						setIcon(IconCache.get("text_file_20.png"));
						break;
					case "png":
					case "PNG":
					case "bmp":
					case "BMP":
					case "jpg":
					case "JPG":
						setToolTipText(fext + " mage file");
						setIcon(IconCache.get("image_file_20.png"));
						break;
					default:
						setToolTipText(fext + " file");
						setIcon(IconCache.get("file_20.png"));
						break;
					}
				}

				setBackgroundNonSelectionColor(UI.BG);
				setBackgroundSelectionColor(UI.BG2);
				setForeground(UI.FONT_COLOR);

				return this;
			}

			private String getCanonicalName(DefaultMutableTreeNode node) {
				TreeNode parent = node.getParent();
				if (parent != null) {
					return getCanonicalName((DefaultMutableTreeNode) parent) + "/" + node.getUserObject().toString();
				} else {
					return node.getUserObject().toString();
				}
			}
		});

		addComponentListener(new ComponentAdapter() {

			@Override
			public void componentResized(ComponentEvent e) {
				pane.setBounds(0, 0, getWidth(), content.getHeight());
			}
		});
		pane.setBackground(UI.BG);
		explorer.setBackground(UI.BG);
		pane.setViewportView(explorer);
		content.add(pane);
	}

	private MutableTreeNode loadFiles(String dir) {
		File dirf = new File(dir);
		File dirp = dirf.getParentFile();
		DefaultMutableTreeNode result = null;
		try {
			String name = dir.substring(dirp.getCanonicalPath().length());
			if (name.startsWith("/") || name.startsWith("\\")) {
				name = name.substring(1);
			}
			result = new DefaultMutableTreeNode(name);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		File[] children = dirf.listFiles();
		for (File file : children) {
			if (file.isDirectory()) {
				try {
					result.add(loadFiles(file.getCanonicalPath()));
				} catch (IOException e) {
					e.printStackTrace();
				}
			} else {
				result.add(new DefaultMutableTreeNode(file.getName()));
			}
		}
		return result;
	}
}
