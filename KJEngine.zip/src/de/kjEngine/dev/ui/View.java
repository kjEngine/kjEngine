package de.kjEngine.dev.ui;

import java.awt.LayoutManager;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

import javax.swing.JPanel;

public class View extends JPanel {
	private static final long serialVersionUID = 1L;

	protected JPanel header, content;

	public View() {
		init();
	}

	public View(LayoutManager layout) {
		super(layout);
		init();
	}

	public View(boolean isDoubleBuffered) {
		super(isDoubleBuffered);
		init();
	}

	public View(LayoutManager layout, boolean isDoubleBuffered) {
		super(layout, isDoubleBuffered);
		init();
	}

	private void init() {
		setBackground(UI.BG);
		header = new JPanel();
		header.setBackground(UI.BG2);
		addComponentListener(new ComponentAdapter() {

			@Override
			public void componentResized(ComponentEvent e) {
				header.setBounds(0, 0, getWidth(), header.getHeight());
			}
		});
		add(header);
		content = new JPanel();
		content.setBackground(UI.BG2);
		addComponentListener(new ComponentAdapter() {

			@Override
			public void componentResized(ComponentEvent e) {
				content.setBounds(0, header.getHeight(), getWidth(), getHeight() - header.getHeight());
			}
		});
		add(content);
	}

	public JPanel getHeader() {
		return header;
	}

	public JPanel getContent() {
		return content;
	}
}
