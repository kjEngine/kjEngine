package de.kjEngine.dev.ui.createn;

public class NewClassWindow extends CreateWindow {
	private static final long serialVersionUID = 1L;

	public NewClassWindow() {
		super("java class", new ClassContentCreator());
	}

	@Override
	protected Object getOthers() {
		return null;
	}
}
