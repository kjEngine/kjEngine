package de.kjEngine.dev.ui.createn;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public abstract class AbstractFileContentCreator implements FileContentCreator {
	
	protected BufferedWriter out;
	private boolean opened;

	public AbstractFileContentCreator() {
	}

	protected void open(String file) {
		try {
			File filef = new File(file);
			File dir = filef.getParentFile();
			if (!dir.exists()) {
				dir.mkdirs();
			}
			filef.createNewFile();
			out = new BufferedWriter(new FileWriter(filef));
			opened = true;
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	protected void write(String data) {
		if (!opened) {
			System.err.println("File has not been opened!");
			return;
		}
		try {
			out.write(data);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	protected void close() {
		if (!opened) {
			System.err.println("File has not been opened!");
			return;
		}
		try {
			out.close();
			opened = false;
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
