package de.kjEngine.dev.ui.createn;

public interface FileContentCreator {

	void create(String name, String location, Object others);
}
