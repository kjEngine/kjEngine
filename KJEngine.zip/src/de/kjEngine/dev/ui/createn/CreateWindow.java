package de.kjEngine.dev.ui.createn;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public abstract class CreateWindow extends JFrame {
	private static final long serialVersionUID = 1L;
	
	private JPanel contentPane;
	private JTextField nameField;
	private JTextField locationField;

	public CreateWindow(String type, FileContentCreator c) {
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(new GridLayout(8, 3, 0, 0));
		
		JLabel heading = new JLabel("Create new " + type);
		panel.add(heading);
		
		JLabel lblName = new JLabel("name: ");
		panel.add(lblName);
		
		nameField = new JTextField();
		panel.add(nameField);
		nameField.setColumns(10);
		
		JLabel lblLocation = new JLabel("location: ");
		panel.add(lblLocation);
		
		locationField = new JTextField();
		panel.add(locationField);
		locationField.setColumns(10);
		
		JButton create = new JButton("create");
		create.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				c.create(nameField.getText(), locationField.getText(), getOthers());
				dispose();
			}
		});
		contentPane.add(create, BorderLayout.SOUTH);
	}
	
	protected abstract Object getOthers();
}
