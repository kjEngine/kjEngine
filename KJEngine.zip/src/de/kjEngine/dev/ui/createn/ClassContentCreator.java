package de.kjEngine.dev.ui.createn;

public class ClassContentCreator extends AbstractFileContentCreator {

	public ClassContentCreator() {
	}

	@Override
	public void create(String name, String location, Object others) {
		open((location + "." + name).replaceAll("\\.", "/") + ".java");
		write("package " + location + ";\n\n");
		write("public class " + name + " {\n\n");
		write("}");
		close();
	}
}
