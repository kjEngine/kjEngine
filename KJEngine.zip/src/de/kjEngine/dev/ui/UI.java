package de.kjEngine.dev.ui;

import java.awt.Color;

public class UI {

	public static final Color BG = Color.DARK_GRAY;
	public static final Color BG2 = Color.GRAY;
	public static final Color FONT_COLOR = Color.WHITE;
}
