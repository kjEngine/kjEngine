package de.kjEngine.dev.ui.icons;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public class IconCache {

	private static final Map<String, ImageIcon> cache = new HashMap<>();
	
	public static ImageIcon get(String res) {
		if (!cache.containsKey(res)) {
			try {
				final String root = "/de/kjEngine/dev/ui/icons/";
				ImageIcon icon = new ImageIcon(ImageIO.read(IconCache.class.getResourceAsStream(root + res)));
				cache.put(res, icon);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return cache.get(res);
	}
}
