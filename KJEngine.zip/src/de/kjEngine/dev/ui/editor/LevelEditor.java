package de.kjEngine.dev.ui.editor;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JButton;

import de.kjEngine.dev.ui.View;
import de.kjEngine.dev.ui.icons.IconCache;

public class LevelEditor extends View {
	private static final long serialVersionUID = 1L;
	
	private Canvas scene;
	private JButton run, stop;

	public LevelEditor() {
		run = new JButton(IconCache.get("play_20.png"));
		header.add(run);
		stop = new JButton(IconCache.get("stop_20.png"));
		header.add(stop);
		scene = new Canvas();
		scene.setBackground(Color.red);
		scene.setMinimumSize(new Dimension());
		scene.setPreferredSize(new Dimension(400, 250));
		scene.setLocation(0, 0);
		content.add(scene);
	}

	public Canvas getScene() {
		return scene;
	}

	public JButton getRun() {
		return run;
	}

	public JButton getStop() {
		return stop;
	}
}
