package de.kjEngine.dev.ui.editor;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import javax.swing.text.DefaultStyledDocument;
import javax.swing.text.StyledDocument;

import de.kjEngine.dev.ui.editor.syntax.AutoSuggestor;
import de.kjEngine.dev.ui.editor.syntax.SyntaxManager;

public class FileEditWindow extends JFrame {
	private static final long serialVersionUID = 1L;

	private JPanel contentPane;
	private final JSplitPane splitPane = new JSplitPane();
	private JTextField fileField;
	private JTextPane editor;
	private StyledDocument doc;
	private String ext;

	public FileEditWindow(String files) {

		File filef = new File(files);

		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		splitPane.setOrientation(JSplitPane.VERTICAL_SPLIT);
		contentPane.add(splitPane, BorderLayout.CENTER);

		JPanel header = new JPanel();
		header.setBackground(Color.GRAY);
		splitPane.setLeftComponent(header);
		header.setLayout(new GridLayout(2, 2, 0, 0));

		JLabel file = new JLabel("file: ");
		file.setForeground(Color.WHITE);
		header.add(file);

		fileField = new JTextField(filef.getName());
		header.add(fileField);
		fileField.setColumns(10);

		JLabel path = new JLabel("path: " + filef.getParent());
		path.setForeground(Color.WHITE);
		header.add(path);

		JTabbedPane views = new JTabbedPane(JTabbedPane.TOP);
		splitPane.setRightComponent(views);

		JScrollPane teditorContainer = new JScrollPane();
		views.addTab("code", null, teditorContainer, null);

		{
			String[] pts = filef.getName().split("\\.");
			ext = pts[pts.length - 1];
		}

		doc = new DefaultStyledDocument();
		editor = new JTextPane(doc);
		SyntaxManager.setStyle(ext, editor);
		editor.setText(read(filef));

		editor.addCaretListener(new CaretListener() {

			@Override
			public void caretUpdate(CaretEvent e) {
				updateHighlights();

			}
		});
		updateHighlights();

		new AutoSuggestor(editor, this, SyntaxManager.get(ext), Color.WHITE.brighter(), Color.BLUE, Color.RED, 0.75f) {

			@Override
			protected boolean wordTyped(String typedWord) {
				System.out.println(typedWord);
				return super.wordTyped(typedWord);
			}
		};

		teditorContainer.setViewportView(editor);

		views.setSelectedIndex(0);
	}

	private void updateHighlights() {
		SwingUtilities.invokeLater(() -> {
			String text = editor.getText();
			List<String> keyWords = SyntaxManager.get(ext);
			for (int off = 0; off < text.length(); off++) {
				for (String s2 : keyWords) {
					String current = text.substring(off);
					if (current.startsWith(s2)) {
						doc.setCharacterAttributes(off, s2.length(), editor.getStyle(s2), true);
					}
				}
			}
		});
	}

	private String read(File filef) {
		StringBuilder sb = new StringBuilder();
		String line;

		try (BufferedReader reader = new BufferedReader(new FileReader(filef))) {
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return sb.toString();
	}

	public JTextField getFileField() {
		return fileField;
	}

	public JTextPane getEditor() {
		return editor;
	}

	public String getExt() {
		return ext;
	}
}
