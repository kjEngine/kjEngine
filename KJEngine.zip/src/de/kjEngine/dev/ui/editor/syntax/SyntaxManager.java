package de.kjEngine.dev.ui.editor.syntax;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JTextPane;
import javax.swing.text.StyleConstants;

import de.kjEngine.core.io.PropertiesFile;

public class SyntaxManager {

	public static void setStyle(String ext, JTextPane p) {
		PropertiesFile lang = LanguageCache.get(ext + ".properties");
		for (String key : lang.getData().keySet()) {
			StyleConstants.setForeground(p.addStyle(key, null), Color.decode(lang.getString(key)));
		}
	}

	public static List<String> get(String ext) {
		return new ArrayList<>(LanguageCache.get(ext + ".properties").getData().keySet());
	}
}
