package de.kjEngine.dev.ui.editor.syntax;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

import de.kjEngine.core.io.PropertiesFile;
import de.kjEngine.core.io.PropertiesReader;

public class LanguageCache {

	private static Map<String, PropertiesFile> data = new HashMap<>();
	
	public static PropertiesFile get(String key) {
		key = "/de/kjEngine/dev/ui/editor/syntax/langs/" + key;
		if (!data.containsKey(key)) {
			InputStream in = LanguageCache.class.getResourceAsStream(key);
			if (in == null) {
				return new PropertiesFile(new HashMap<>());
			}
			PropertiesReader r = new PropertiesReader(new InputStreamReader(in));
			try {
				data.put(key, r.read());
				r.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return data.get(key);
	}
}
