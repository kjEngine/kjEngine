package de.kjEngine.core.model;

import static org.lwjgl.opengl.GL20.*;
import static org.lwjgl.opengl.GL30.*;

import org.lwjgl.opengl.GL15;

import de.kjEngine.core.api.Cleanable;
import de.kjEngine.core.api.Triggerable;
import de.kjEngine.core.light.Material;
import de.kjEngine.core.util.KTexture;

public class Model implements Cleanable, Triggerable {

	private int indexCount, vao;
	private KTexture texture;
	private Material material;
	private int[] vbos;
	private boolean cullingEnabled = true;
	private String name;
	private Mesh mesh;
	
	public Model(int vao, int indexCount, KTexture texture, int[] vbos, String name, Mesh m) {
		this(vao, indexCount, texture, Material.STONE.copy(), vbos, name, m);
	}

	public Model(int vao, int indexCount, KTexture texture, int[] vbos, String name) {
		this(vao, indexCount, texture, Material.STONE.copy(), vbos, name);
	}
	
	public Model(int vao, int indexCount, KTexture texture, Material material, int[] vbos, String name, Mesh m) {
		this(vao, indexCount, texture, material, vbos, name);
		mesh = m;
	}

	public Model(int vao, int indexCount, KTexture texture, Material material, int[] vbos, String name) {
		this.indexCount = indexCount;
		this.vao = vao;
		this.texture = texture;
		this.material = material;
		this.vbos = vbos;
		this.name = name;
	}

	public Material getMaterial() {
		return material;
	}

	public void setMaterial(Material material) {
		this.material = material;
	}

	public int getIndexCount() {
		return indexCount;
	}

	public int getVao() {
		return vao;
	}

	public KTexture getTexture() {
		return texture;
	}

	public void setTexture(KTexture texture) {
		this.texture = texture;
	}

	@Override
	public void cleanUp() {
		for (int id : vbos) {
			GL15.glDeleteBuffers(id);
		}
		glDeleteVertexArrays(vao);
	}

	@Override
	public void enable() {
		glBindVertexArray(vao);
		glEnableVertexAttribArray(0);
		glEnableVertexAttribArray(1);
		glEnableVertexAttribArray(2);
	}

	@Override
	public void disable() {
		glDisableVertexAttribArray(0);
		glDisableVertexAttribArray(1);
		glDisableVertexAttribArray(2);
		glBindVertexArray(0);
	}

	/**
	 * @return the cullingEnabled
	 */
	public boolean isCullingEnabled() {
		return cullingEnabled;
	}

	/**
	 * @param cullingEnabled
	 *            the cullingEnabled to set
	 */
	public void setCullingEnabled(boolean cullingEnabled) {
		this.cullingEnabled = cullingEnabled;
	}

	public String getName() {
		return name;
	}

	public Mesh getMesh() {
		return mesh;
	}
}
