package de.kjEngine.core.model;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL40;

import de.kjEngine.core.api.Cleanable;

public class Patch implements Cleanable {
	
	private int size;
	private Model model;

	public Patch(Model model) {
		this.model = model;
		size = model.getIndexCount();
	}
	
	public void render() {
		model.enable();
		GL40.glPatchParameteri(GL40.GL_PATCH_VERTICES, size);
		GL11.glDrawArrays(GL40.GL_PATCHES, 0, size);
		model.disable();
	}

	/**
	 * @return the size
	 */
	public int getSize() {
		return size;
	}

	/**
	 * @return the model
	 */
	public Model getModel() {
		return model;
	}

	@Override
	public void cleanUp() {
		model.cleanUp();
	}
}
