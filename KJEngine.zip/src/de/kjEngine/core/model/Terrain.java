package de.kjEngine.core.model;

import java.util.Arrays;

import org.lwjgl.util.vector.*;

import de.kjEngine.core.*;
import de.kjEngine.core.util.Loader;

public class Terrain {

	private Model model;
	private float[][] heights;
	private float width, height, scale;

	public Terrain(int width, int height, float scale, float amplitude, float steepness, int texture, float tiling,
			long seed, String name) {
		heights = new float[width][height];
		model = Loader.genTerrain(width, height, scale, amplitude, steepness, texture, tiling, heights, seed, name);
		this.width = width;
		this.height = height;
		this.scale = scale;
	}

	public Terrain(int width, int height, float scale, float[][] heights, float tiling, int texture, String name) {
		model = Loader.genTerrainFromHeightmap(width, height, scale, texture, tiling, heights, name);
		this.heights = heights;
		this.width = width;
		this.height = height;
		this.scale = scale;
	}

	public Vector3f getNormal(float x, float z) {
		int gx = (int) (x / scale);
		int gz = (int) (z / scale);

		if (gx < 0 || gz < 0 || gx >= width - 1 || gz >= height - 1)
			return new Vector3f();

		float gxts = gx * scale;
		float gzts = gz * scale;

		float h0 = getHeightAt(gxts, gzts);
		float h1 = getHeightAt(gxts + scale, gzts);
		float h2 = getHeightAt(gxts, gzts + scale);

		Vector3f v0 = new Vector3f(1f, h0 - h1, 0f);
		Vector3f v1 = new Vector3f(0f, h0 - h2, 1f);

		Vector3f result = Vector3f.cross(v0, v1, null);
		result.normalise();

		return result;
	}

	public float getHeightAt(float x, float z) {
		int gx = (int) (x / scale);
		int gz = (int) (z / scale);

		if (gx < 0 || gz < 0 || gx >= width - 1 || gz >= height - 1)
			return 0f;

		float xc = (x % scale) / scale;
		float zc = (z % scale) / scale;

		float result;

		if (xc <= (1f - zc)) {
			result = barryCentric(new Vector3f(0, heights[gx][gz], 0), new Vector3f(1, heights[gx + 1][gz], 0),
					new Vector3f(0, heights[gx][gz + 1], 1), new Vector2f(xc, zc));

		} else {
			result = barryCentric(new Vector3f(1, heights[gx + 1][gz], 0), new Vector3f(1, heights[gx + 1][gz + 1], 1),
					new Vector3f(0, heights[gx][gz + 1], 1), new Vector2f(xc, zc));
		}
		return result;
	}

	private float barryCentric(Vector3f p1, Vector3f p2, Vector3f p3, Vector2f pos) {
		float det = (p2.z - p3.z) * (p1.x - p3.x) + (p3.x - p2.x) * (p1.z - p3.z);
		float l1 = ((p2.z - p3.z) * (pos.x - p3.x) + (p3.x - p2.x) * (pos.y - p3.z)) / det;
		float l2 = ((p3.z - p1.z) * (pos.x - p3.x) + (p1.x - p3.x) * (pos.y - p3.z)) / det;
		float l3 = 1.0f - l1 - l2;
		return l1 * p1.y + l2 * p2.y + l3 * p3.y;
	}

	public Model getModel() {
		return model;
	}

	public void setModel(Model model) {
		this.model = model;
	}

	public float[][] getHeights() {
		return heights;
	}

	public void setHeights(float[][] heights) {
		this.heights = heights;
	}

	public float getWidth() {
		return width;
	}

	public float getHeight() {
		return height;
	}

	public float getScale() {
		return scale;
	}

	@Override
	public String toString() {
		StringBuilder hms = new StringBuilder();
		for (int x = 0; x < height; x++)
			if (x < height - 1)
				hms.append("x(" + x + "):" + Arrays.toString(heights[x]) + "\n");
			else
				hms.append("x(" + x + "):" + Arrays.toString(heights[x]));
		return "Terrain [width=" + width + ", height=" + height + ", scale=" + scale + ", heights=\n" + hms + "]\n";
	}
}
