package de.kjEngine.core.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.lwjgl.util.vector.Vector3f;

public class Mesh {

	private float[] vertices;
	private int[] indices;
	private float[] texCoords;
	private float[] normals;
	private Triangle[] triangles;

	public Mesh(float[] vertices, int[] indices, float[] texCoords, float[] normals) {
		create(vertices, indices, texCoords, normals);
	}

	private void create(float[] vertices, int[] indices, float[] texCoords, float[] normals) {
		this.vertices = vertices;
		this.indices = indices;
		this.texCoords = texCoords;
		this.normals = normals;

		createTriangles();
	}

	private void createTriangles() {
		try {
			List<Triangle> ts = new ArrayList<>();

			for (int tri = 0; tri < indices.length; tri += 9) {
				Vector3f p0 = new Vector3f(vertices[tri + 0], vertices[tri + 1], vertices[tri + 2]);
				Vector3f p1 = new Vector3f(vertices[tri + 3], vertices[tri + 4], vertices[tri + 5]);
				Vector3f p2 = new Vector3f(vertices[tri + 6], vertices[tri + 7], vertices[tri + 8]);
				ts.add(new Triangle(p0, p1, p2));
			}

			triangles = ts.toArray(new Triangle[ts.size()]);
		} catch (ArrayIndexOutOfBoundsException e) {
		}
	}

	public float[] getVertices() {
		return vertices;
	}

	public void setVertices(float[] vertices) {
		create(vertices, indices, texCoords, normals);
	}

	public int[] getIndices() {
		return indices;
	}

	public void setIndices(int[] indices) {
		create(vertices, indices, texCoords, normals);
	}

	public float[] getTexCoords() {
		return texCoords;
	}

	public void setTexCoords(float[] texCoords) {
		create(vertices, indices, texCoords, normals);
	}

	public float[] getNormals() {
		return normals;
	}

	public void setNormals(float[] normals) {
		create(vertices, indices, texCoords, normals);
	}

	public Triangle[] getTriangles() {
		return triangles;
	}

	public void setTriangles(Triangle[] triangles) {
		create(vertices, indices, texCoords, normals);
	}

	@Override
	public String toString() {
		return "Mesh [vertices=" + Arrays.toString(vertices) + ", indices=" + Arrays.toString(indices) + ", texCoords="
				+ Arrays.toString(texCoords) + ", normals=" + Arrays.toString(normals) + ", triangles="
				+ Arrays.toString(triangles) + "]";
	}
}
