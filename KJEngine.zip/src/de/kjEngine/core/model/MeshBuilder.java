package de.kjEngine.core.model;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.List;

import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;

import de.kjEngine.core.util.KTexture;
import de.kjEngine.core.util.Loader;

public class MeshBuilder {
	
	private List<Vector3f> positions = new ArrayList<>();
	private List<Vector2f> texCoords = new ArrayList<>();
	private List<Vector3f> normals = new ArrayList<>();
	private List<Integer> indices = new ArrayList<>();
	private int insertLocation;
	
	public static enum BuildType {
		TRIANGLES, TRIANGLE_STRIP, QUADS, TRIANGLE_FAN
	}

	public MeshBuilder() {
	}
	
	public void clear() {
		positions.clear();
		texCoords.clear();
		normals.clear();
	}
	
	public void append(float px, float py, float pz, float u, float v, float nx, float ny, float nz) {
		append(new Vector3f(px, py, pz), new Vector2f(u, v), new Vector3f(nx, ny, nz));
	}
	
	public void append(Vector3f pos, Vector2f texCoord, Vector3f normal) {
		positions.add(insertLocation, pos);
		texCoords.add(insertLocation, texCoord);
		normals.add(insertLocation, normal);
		insertLocation++;
	}
	
	public void build(BuildType type) {
		if (!indices.isEmpty()) {
			indices.clear();
		}
		switch (type) {
		case TRIANGLES:
			for (int i = 0; i < positions.size(); i++) {
				indices.add(i);
			}
			break;
		case TRIANGLE_STRIP:
			for (int i = 2; i < positions.size(); i++) {
				indices.add(i - 2);
				indices.add(i - 1);
				indices.add(i);
			}
			break;
		case TRIANGLE_FAN:
			for (int i = 2; i < positions.size(); i++) {
				indices.add(i - 2);
				indices.add(i - 1);
				indices.add(0);
			}
			break;
		case QUADS:
			for (int i = 3; i < positions.size(); i++) {
				indices.add(i - 2);
				indices.add(i - 1);
				indices.add(i);
				indices.add(i - 2);
				indices.add(i - 1);
				indices.add(i - 3);
			}
			break;
		}
	}

	/**
	 * @return the insertLocation
	 */
	public int getInsertLocation() {
		return insertLocation;
	}

	/**
	 * @param insertLocation the insertLocation to set
	 */
	public void setInsertLocation(int insertLocation) {
		if (insertLocation < 0 || insertLocation >= positions.size())
			throw new IndexOutOfBoundsException("Out of bounds: " + insertLocation);
		this.insertLocation = insertLocation;
	}
	
	public Model toModel() {
		return toModel(BuildType.TRIANGLES);
	}
	
	public Model toModel(BuildType type) {
		return Loader.loadModel(toMesh(type), new KTexture(0), "");
	}
	
	public Mesh toMesh() {
		return toMesh(BuildType.TRIANGLES);
	}
	
	public Mesh toMesh(BuildType type) {
		if (indices.isEmpty()) {
			build(type);
		}
		FloatBuffer posb = FloatBuffer.allocate(positions.size() * 3);
		FloatBuffer texb = FloatBuffer.allocate(texCoords.size() * 2);
		FloatBuffer normb = FloatBuffer.allocate(normals.size() * 3);
		IntBuffer indb = IntBuffer.allocate(indices.size());
		for (int i = 0; i < positions.size(); i++) {
			Vector3f pos = positions.get(i);
			posb.put(new float[] {pos.x, pos.y, pos.z});
			Vector2f tc = texCoords.get(i);
			texb.put(new float[] {tc.x, tc.y});
			Vector3f norm = normals.get(i);
			normb.put(new float[] {norm.x, norm.y, norm.z});
		}
		posb.flip();
		texb.flip();
		normb.flip();
		indb.flip();
		return new Mesh(posb.array(), indb.array(), texb.array(), normb.array());
	}
}
