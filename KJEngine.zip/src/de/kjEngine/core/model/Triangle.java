package de.kjEngine.core.model;

import org.lwjgl.util.vector.Vector3f;

public class Triangle {
	
	public Vector3f p0, p1, p2;

	public Triangle() {
		this(new Vector3f(), new Vector3f(), new Vector3f());
	}
	
	public Triangle(Vector3f p0, Vector3f p1, Vector3f p2) {
		this.p0 = p0;
		this.p1 = p1;
		this.p2 = p2;
	}
}
