package de.kjEngine.core.postProcessing;

import de.kjEngine.core.api.Shader;
import de.kjEngine.core.uniforms.UniformFloat;
import de.kjEngine.core.uniforms.UniformVec2;

public class BowingShader extends Shader {
	
	public UniformFloat amount;
	public UniformVec2 pos, r;

	public BowingShader() {
		super("/de/kjEngine/core/postProcessing/simpleVertex.glsl",
				"/de/kjEngine/core/postProcessing/bowingFragment.glsl");
	}

	@Override
	protected void loadUniformLocations() {
		amount = new UniformFloat(id, "amount");
		pos = new UniformVec2(id, "pos");
		r = new UniformVec2(id, "r");
	}
}
