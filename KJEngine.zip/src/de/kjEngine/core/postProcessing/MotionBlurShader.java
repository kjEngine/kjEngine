package de.kjEngine.core.postProcessing;

import de.kjEngine.core.api.Shader;
import de.kjEngine.core.uniforms.UniformInt;;

public class MotionBlurShader extends Shader {
	
	public UniformInt textureCount;

	public MotionBlurShader() {
		super("/de/kjEngine/core/postProcessing/simpleVertex.glsl",
				"/de/kjEngine/core/postProcessing/motionBlurFragment.glsl");
	}

	@Override
	protected void loadUniformLocations() {
		textureCount = new UniformInt(id, "textureCount");
	}
}
