package de.kjEngine.core.postProcessing;

import org.lwjgl.opengl.*;

import de.kjEngine.core.*;
import de.kjEngine.core.api.Cleanable;

public class HorizontalBlur implements Cleanable, Stage {
	
	private ImageRenderer renderer;
	private HorizontalBlurShader shader;
	
	public HorizontalBlur(int targetFboWidth, int targetFboHeight){
		shader = new HorizontalBlurShader();
		shader.enable();
		shader.loadTargetWidth(targetFboWidth);
		shader.disable();
		renderer = new ImageRenderer(targetFboWidth, targetFboHeight);
	}
	
	public HorizontalBlur(){
		shader = new HorizontalBlurShader();
		shader.enable();
		shader.loadTargetWidth(Display.getWidth());
		shader.disable();
		renderer = new ImageRenderer();
	}
	
	public void render(int texture, int depthTexture){
		shader.enable();
		
		GL13.glActiveTexture(GL13.GL_TEXTURE0);
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, texture);
		
		GL13.glActiveTexture(GL13.GL_TEXTURE1);
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, depthTexture);
		
		renderer.renderQuad();
		shader.disable();
	}
	
	public int getOutputTexture(){
		return renderer.getOutputTexture();
	}
	
	@Override
	public void cleanUp(){
		renderer.cleanUp();
		shader.cleanUp();
	}
}
