package de.kjEngine.core.postProcessing;

import org.lwjgl.opengl.GL13;
import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;
import org.lwjgl.util.vector.Vector4f;

import de.kjEngine.core.GameEngine;
import de.kjEngine.core.api.GenericShader;
import de.kjEngine.core.util.OpenGlUtils;

public class PlasmaFilter extends AbstractStage {
	
	private static GenericShader loadShader() {
		return new GenericShader("/de/kjEngine/core/postProcessing/simpleVertex.glsl",
				"/de/kjEngine/core/postProcessing/plasmaFragment.glsl");
	}

	public PlasmaFilter() {
		super(loadShader());
	}

	public PlasmaFilter(int width, int height) {
		super(loadShader(), width, height);
	}
	
	public void render(int image, int heat, Vector3f dir) {
		shader.enable();
		OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE0, image);
		OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE1, heat);
		shader.set("dir", (Vector2f) (projectOrigin(dir).scale(100f)));
		shader.set("a", dir.length());
		renderer.renderQuad();
		shader.disable();
	}

	private Vector2f projectOrigin(Vector3f dir) {
		Matrix4f vMat = GameEngine.getCam().getLocation();
		Matrix4f pMat = GameEngine.getRenderer().getpMat();
		Matrix4f vpMat = Matrix4f.mul(pMat, vMat, null);
		Vector4f dir4 = new Vector4f(dir.x, dir.y, dir.z, 1f);
		Matrix4f.transform(vpMat, dir4, dir4);
		return new Vector2f(dir4.x / dir4.w, dir4.y / dir4.w);
	}
}
