package de.kjEngine.core.postProcessing;

import org.lwjgl.opengl.GL13;

import de.kjEngine.core.api.Cleanable;
import de.kjEngine.core.util.OpenGlUtils;

public class NoFilter implements Stage, Cleanable {
	
	private ImageRenderer renderer;
	private NoFilterShader shader;

	public NoFilter() {
		renderer = new ImageRenderer();
		shader = new NoFilterShader();
	}
	
	public void render(int src) {
		shader.enable();
		OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE0, src);
		renderer.renderQuad();
		shader.disable();
	}

	@Override
	public void cleanUp() {
		shader.cleanUp();
	}

	@Override
	public int getOutputTexture() {
		return renderer.getOutputTexture();
	}
}
