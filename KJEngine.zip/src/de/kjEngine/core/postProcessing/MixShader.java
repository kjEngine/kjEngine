package de.kjEngine.core.postProcessing;

import de.kjEngine.core.api.Shader;
import de.kjEngine.core.uniforms.UniformFloat;
import de.kjEngine.core.uniforms.UniformVec4;

public class MixShader extends Shader {
	
	public UniformVec4 color;
	public UniformFloat a;

	public MixShader() {
		super("/de/kjEngine/core/postProcessing/simpleVertex.glsl",
				"/de/kjEngine/core/postProcessing/mixFragment.glsl");
	}

	@Override
	protected void loadUniformLocations() {
		color = new UniformVec4(id, "color");
		a = new UniformFloat(id, "a");
	}
}
