package de.kjEngine.core.postProcessing;

import de.kjEngine.core.api.Shader;
import de.kjEngine.core.uniforms.UniformMat4;

public class SSRShader extends Shader {
	
	public UniformMat4 invView, projection, invprojection, view;

	public SSRShader() {
		super("/de/kjEngine/core/postProcessing/simpleVertex.glsl", "/de/kjEngine/core/postProcessing/ssrFragment.glsl");
	}

	@Override
	protected void loadUniformLocations() {
		invView = new UniformMat4(id, "invView");
		projection = new UniformMat4(id, "projection");
		invprojection = new UniformMat4(id, "invprojection");
		view = new UniformMat4(id, "view");
	}
}
