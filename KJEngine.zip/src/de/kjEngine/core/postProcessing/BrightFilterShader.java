package de.kjEngine.core.postProcessing;

import static org.lwjgl.opengl.GL20.*;

import de.kjEngine.core.*;
import de.kjEngine.core.api.Shader;

public class BrightFilterShader extends Shader{
	
	private static final String VERTEX_FILE = "/de/kjEngine/core/postProcessing/simpleVertex.glsl";
	private static final String FRAGMENT_FILE = "/de/kjEngine/core/postProcessing/brightFilterFragment.glsl";
	
	public BrightFilterShader() {
		super(VERTEX_FILE, FRAGMENT_FILE);
	}

	@Override
	protected void loadUniformLocations() {	
	}

	@Override
	public void cleanUp() {		
		glDeleteProgram(id);
	}
}
