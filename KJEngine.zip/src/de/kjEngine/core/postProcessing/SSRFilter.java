package de.kjEngine.core.postProcessing;

import org.lwjgl.opengl.GL13;
import org.lwjgl.util.vector.Matrix4f;

import de.kjEngine.core.GameEngine;
import de.kjEngine.core.util.OpenGlUtils;

public class SSRFilter implements Stage {

	private ImageRenderer renderer;
	private SSRShader shader;

	public SSRFilter(int width, int height) {
		renderer = new ImageRenderer(width, height);
		shader = new SSRShader();
	}

	public SSRFilter() {
		renderer = new ImageRenderer();
		shader = new SSRShader();
	}

	public void render(int prev, int depth, int norm, int metallic, int rough) {
		shader.enable();

		OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE0, prev);
		OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE1, depth);
		OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE2, norm);
		OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE3, metallic);
		OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE4, rough);

		shader.projection.loadMatrix(GameEngine.getRenderer().getpMat());
		shader.invprojection.loadMatrix((Matrix4f) GameEngine.getRenderer().getpMat().invert());
		shader.view.loadMatrix(GameEngine.getCam().getLocation());
		shader.invView.loadMatrix((Matrix4f) GameEngine.getCam().getLocation().invert());
		
		renderer.renderQuad();

		shader.disable();
	}

	@Override
	public void cleanUp() {
		shader.cleanUp();
	}

	@Override
	public int getOutputTexture() {
		return renderer.getOutputTexture();
	}
}
