package de.kjEngine.core.postProcessing;

import de.kjEngine.core.*;
import de.kjEngine.core.api.Shader;

import static org.lwjgl.opengl.GL20.*;

public class VerticalBlurShader extends Shader {

	private static final String VERTEX_FILE = "/de/kjEngine/core/postProcessing/verticalBlurVertex.glsl";
	private static final String FRAGMENT_FILE = "/de/kjEngine/core/postProcessing/blurFragment.glsl";
	
	private int location_targetHeight;
	
	protected VerticalBlurShader() {
		super(VERTEX_FILE, FRAGMENT_FILE);
	}
	
	protected void loadTargetHeight(float height){
		super.loadFloat(location_targetHeight, height);
	}

	@Override
	protected void loadUniformLocations() {	
		location_targetHeight = glGetUniformLocation(id, "height");
	}

	@Override
	public void cleanUp() {	
		glDeleteProgram(id);
	}
}
