package de.kjEngine.core.postProcessing;

import de.kjEngine.core.api.GenericShader;

public abstract class AbstractStage implements Stage {
	
	protected GenericShader shader;
	protected ImageRenderer renderer;

	public AbstractStage(GenericShader shader) {
		this.shader = shader;
		renderer = new ImageRenderer();
	}
	
	public AbstractStage(GenericShader shader, int width, int height) {
		this.shader = shader;
		renderer = new ImageRenderer(width, height);
	}

	@Override
	public void cleanUp() {
		shader.cleanUp();
		renderer.cleanUp();
	}

	@Override
	public int getOutputTexture() {
		return renderer.getOutputTexture();
	}
}
