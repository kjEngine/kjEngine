package de.kjEngine.core.postProcessing;

import de.kjEngine.core.*;
import de.kjEngine.core.api.Shader;

import static org.lwjgl.opengl.GL20.*;

public class HorizontalBlurShader extends Shader {

	private static final String VERTEX_FILE = "/de/kjEngine/core/postProcessing/horizontalBlurVertex.glsl";
	private static final String FRAGMENT_FILE = "/de/kjEngine/core/postProcessing/blurFragment.glsl";
	
	private int location_targetWidth;
	
	protected HorizontalBlurShader() {
		super(VERTEX_FILE, FRAGMENT_FILE);
	}

	protected void loadTargetWidth(float width){
		super.loadFloat(location_targetWidth, width);
	}
	
	@Override
	protected void loadUniformLocations() {
		location_targetWidth = glGetUniformLocation(id, "width");
	}

	@Override
	public void cleanUp() {	
		glDeleteProgram(id);
	}
}
