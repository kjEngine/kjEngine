package de.kjEngine.core.postProcessing.pipeline;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

class PipelineReaderImpl {

	BufferedReader r;
	String line;
	State state;
	List<Instruction> instructions = new ArrayList<>();

	PipelineReaderImpl(BufferedReader r) {
		this.r = r;
	}

	Pipeline read() throws IOException {
		while ((line = r.readLine()) != null) {
			line = line.trim();
			if (line.startsWith("//")) {
				continue;
			}
			updateState();
			processLine();
		}
		return new Pipeline(instructions.toArray(new Instruction[instructions.size()]));
	}

	private void processLine() {
		if (state == null) {
			return;
		}
		String[] parts = line.split(":");
		for (String s : parts) {
			s = s.trim();
		}
		Instruction i = null;
		switch (parts[0]) {
		case "render":
			i = new RenderInstruction(state);
			break;
		case "create":
			i = new CreateInstruction(state, parts[3]);
			break;
		}
		if (i != null) {
			instructions.add(i);
		}
	}

	private void updateState() {
		if (line.startsWith("init")) {
			state = State.INIT;
		} else if (line.startsWith("end")) {
			state = null;
		} else if (line.startsWith("render") && state == null) {
			state = State.RENDER;
		}
	}
}
