package de.kjEngine.core.postProcessing.pipeline;

public class Pipeline {
	
	private Instruction[] instructions;
	private int output;

	public Pipeline(Instruction[] instructions) {
		this.instructions = instructions;
		for (Instruction i : instructions) {
			i.setParent(this);
			if (i.getState().equals(State.INIT)) {
				i.run();
			}
		}
	}
	
	public int render() {
		for (Instruction i : instructions) {
			if (i.getState().equals(State.RENDER)) {
				i.run();
			}
		}
		return output;
	}

	public int getOutput() {
		return output;
	}

	public void setOutput(int output) {
		this.output = output;
	}
}