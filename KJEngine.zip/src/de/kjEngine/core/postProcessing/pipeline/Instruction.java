package de.kjEngine.core.postProcessing.pipeline;

public abstract class Instruction implements Runnable {
	
	private State state;
	private Pipeline parent;

	public Instruction(State state) {
		this.state = state;
	}

	public State getState() {
		return state;
	}

	public Pipeline getParent() {
		return parent;
	}

	public void setParent(Pipeline parent) {
		this.parent = parent;
	}
}
