package de.kjEngine.core.postProcessing.pipeline;

public class RenderInstruction extends Instruction {

	public RenderInstruction(State state) {
		super(state);
	}

	@Override
	public void run() {
	}
}
