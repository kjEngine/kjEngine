package de.kjEngine.core.postProcessing.pipeline;

public class CreateInstruction extends Instruction {
	
	private String var_name;

	public CreateInstruction(State state, String var_name) {
		super(state);
		this.var_name = var_name;
	}

	@Override
	public void run() {
	}

	public String getVar_name() {
		return var_name;
	}
}
