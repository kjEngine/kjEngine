package de.kjEngine.core.postProcessing.pipeline;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

public class PipelineReader implements AutoCloseable {

	private BufferedReader r;

	public PipelineReader(String file) throws FileNotFoundException {
		r = new BufferedReader(new FileReader(new File(file)));
	}

	public PipelineReader(File file) throws FileNotFoundException {
		r = new BufferedReader(new FileReader(file));
	}

	public PipelineReader(InputStream s) {
		r = new BufferedReader(new InputStreamReader(s));
	}

	public PipelineReader(Reader r) {
		r = new BufferedReader(r);
	}
	
	public Pipeline read() throws IOException {
		PipelineReaderImpl impl = new PipelineReaderImpl(r);
		return impl.read();
	}

	@Override
	public void close() throws IOException {
		r.close();
	}
}
