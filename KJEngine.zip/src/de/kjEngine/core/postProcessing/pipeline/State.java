package de.kjEngine.core.postProcessing.pipeline;

public enum State {
	INIT, RENDER
}
