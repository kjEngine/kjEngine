package de.kjEngine.core.postProcessing;

import org.lwjgl.opengl.GL13;
import org.lwjgl.util.vector.Vector2f;

import de.kjEngine.core.api.Cleanable;
import de.kjEngine.core.awt.DisplayManager;
import de.kjEngine.core.util.OpenGlUtils;

public class BownigFilter implements Stage, Cleanable {
	
	private ImageRenderer renderer;
	private BowingShader shader;

	public BownigFilter() {
		renderer = new ImageRenderer();
		shader = new BowingShader();
	}
	
	public void render(int tex, Vector2f pos, float amount, float r) {
		shader.enable();
		shader.amount.loadFloat(amount);
		shader.pos.loadVec2(pos);
		shader.r.loadVec2(r / DisplayManager.getAspect(), r);
		OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE0, tex);
		renderer.renderQuad();
		shader.disable();
	}
	
	public BownigFilter(int width, int height) {
		renderer = new ImageRenderer(width, height);
	}

	@Override
	public int getOutputTexture() {
		return renderer.getOutputTexture();
	}

	@Override
	public void cleanUp() {
	}
}
