package de.kjEngine.core.postProcessing;

import de.kjEngine.core.api.Shader;

public class NoFilterShader extends Shader {

	public NoFilterShader() {
		super("/de/kjEngine/core/postProcessing/simpleVertex.glsl",
				"/de/kjEngine/core/postProcessing/noFilterFragment.glsl");
	}

	@Override
	protected void loadUniformLocations() {
	}
}
