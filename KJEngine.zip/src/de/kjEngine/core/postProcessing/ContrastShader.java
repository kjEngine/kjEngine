package de.kjEngine.core.postProcessing;

import de.kjEngine.core.*;
import de.kjEngine.core.api.Shader;

import static org.lwjgl.opengl.GL20.*;

public class ContrastShader extends Shader {

	private static final String VERTEX_FILE = "/de/kjEngine/core/postProcessing/contrastVertex.glsl";
	private static final String FRAGMENT_FILE = "/de/kjEngine/core/postProcessing/contrastFragment.glsl";
	
	public ContrastShader() {
		super(VERTEX_FILE, FRAGMENT_FILE);
	}

	@Override
	protected void loadUniformLocations() {	
	}

	@Override
	public void cleanUp() {
		glDeleteProgram(id);
	}
}
