package de.kjEngine.core.postProcessing;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.util.vector.Vector4f;

import de.kjEngine.core.api.Cleanable;

public class MixFilter implements Cleanable, Stage {
	
	private ImageRenderer renderer;
	private MixShader shader;
	
	public MixFilter(int targetFboWidth, int targetFboHeight){
		renderer = new ImageRenderer(targetFboWidth, targetFboHeight);
		init();
	}
	
	public MixFilter(){
		renderer = new ImageRenderer();
		init();
	}
	
	private void init() {
		shader = new MixShader();
	}

	public void render(int texture, Vector4f color, float a){
		shader.enable();
		
		GL13.glActiveTexture(GL13.GL_TEXTURE0);
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, texture);
		
		shader.color.loadVec4(color);
		shader.a.loadFloat(a);
		
		renderer.renderQuad();
		
		shader.disable();
	}
	
	public int getOutputTexture(){
		return renderer.getOutputTexture();
	}
	
	@Override
	public void cleanUp(){
		renderer.cleanUp();
		shader.cleanUp();
	}
}
