package de.kjEngine.core.postProcessing;

import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;
import org.lwjgl.util.vector.Vector4f;

import de.kjEngine.core.light.PositionalLight;
import de.kjEngine.core.model.Model;
import de.kjEngine.core.util.KTexture;

public class PostProcessing {

	private static final float[] POSITIONS = { -1f, 1f, 0f, -1f, -1f, 0f, 1f, 1f, 0f, 1f, -1f, 0f };
	private static Model quad;

//	private static SSRFilter ssr;
	private static DeferredFilter df;
	private static HeatFilter hf;
	private static PlasmaFilter pf;

	public static void init() {
		quad = de.kjEngine.core.util.Loader.loadModel3D(POSITIONS, null, null, new int[] { 0, 1, 2 }, new KTexture(0),
				"quad");
//		ssr = new SSRFilter();
		df = new DeferredFilter(Display.getWidth(), Display.getHeight());
		hf = new HeatFilter(Display.getWidth(), Display.getHeight());
		pf = new PlasmaFilter();
	}

	public static void doPostProcessing(int diff, int norm, int rough, int metallic, int pos, int speed,
			Vector2f sunPos) {
		start();
		// ssr.render(diff, depth, norm, metallic, rough);
		df.render(diff, norm, pos, new PositionalLight(new Vector4f(), new Vector4f(1f, 0.9f, 0.7f, 1f),
				new Vector4f(1f, 1f, 1f, 0f), new Vector3f(0f, 10f, -10f), 50f, true));
		hf.render(norm, speed, new Vector3f(1f, 0f, 0f));
		pf.render(df.getOutputTexture(), hf.getOutputTexture(), new Vector3f(1f, 0f, 0f));
		end();
	}

	public static void cleanUp() {
//		ssr.cleanUp();
		df.cleanUp();
		hf.cleanUp();
		pf.cleanUp();
	}

	public static void start() {
		quad.enable();
		GL11.glDisable(GL11.GL_DEPTH_TEST);
	}

	public static void end() {
		GL11.glEnable(GL11.GL_DEPTH_TEST);
		quad.disable();
	}
}
