package de.kjEngine.core.postProcessing;

import org.lwjgl.opengl.*;

import de.kjEngine.core.api.Cleanable;

public class CombineFilter implements Cleanable, Stage {
	
	private ImageRenderer renderer;
	private CombineShader shader;
	
	public CombineFilter(int width, int height){
		shader = new CombineShader();
		renderer = new ImageRenderer(width, height);
	}
	
	public CombineFilter(){
		shader = new CombineShader();
		renderer = new ImageRenderer();
	}
	
	public void render(int colourTexture, int highlightTexture){
		shader.enable();
		GL13.glActiveTexture(GL13.GL_TEXTURE0);
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, colourTexture);
		GL13.glActiveTexture(GL13.GL_TEXTURE1);
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, highlightTexture);
		renderer.renderQuad();
		shader.disable();
	}
	
	public int getOutputTexture() {
		return renderer.getOutputTexture();
	}
	
	public void cleanUp(){
		renderer.cleanUp();
		shader.cleanUp();
	}
}
