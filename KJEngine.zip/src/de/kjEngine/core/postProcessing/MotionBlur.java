package de.kjEngine.core.postProcessing;

import org.lwjgl.opengl.GL13;

import de.kjEngine.core.api.Cleanable;
import de.kjEngine.core.util.OpenGlUtils;

public class MotionBlur implements Cleanable, Stage {
	
	private ImageRenderer renderer;
	private MotionBlurShader shader;
	
	public MotionBlur(int targetFboWidth, int targetFboHeight) {
		renderer = new ImageRenderer(targetFboWidth, targetFboHeight);
		shader = new MotionBlurShader();
	}
	
	public MotionBlur() {
		renderer = new ImageRenderer();
		shader = new MotionBlurShader();
	}
	
	public void render(int... textures) {
		shader.enable();
		for (int i = 0; i < textures.length; i++) {
			OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE0 + i, textures[i]);
		}
		shader.textureCount.loadInt(textures.length);
		renderer.renderQuad();
		shader.disable();
	}
	
	public int getOutputTexture() {
		return renderer.getOutputTexture();
	}

	@Override
	public void cleanUp() {
		shader.cleanUp();
	}
}
