package de.kjEngine.core.postProcessing;

import org.lwjgl.opengl.GL13;

import de.kjEngine.core.GameEngine;
import de.kjEngine.core.api.GenericShader;
import de.kjEngine.core.light.PositionalLight;
import de.kjEngine.core.util.OpenGlUtils;

public class DeferredFilter implements Stage {

	private ImageRenderer renderer;
	private GenericShader shader;

	public DeferredFilter() {
		renderer = new ImageRenderer();
		initShader();
	}

	public DeferredFilter(int width, int height) {
		renderer = new ImageRenderer(width, height);
		initShader();
	}

	private void initShader() {
		shader = new GenericShader("/de/kjEngine/core/postProcessing/simpleVertex.glsl",
				"/de/kjEngine/core/postProcessing/deferredFragment.glsl");
	}

	public void render(int diff, int normal, int pos, PositionalLight... lights) {
		shader.enable();
		OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE0, diff);
		OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE1, normal);
		OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE2, pos);
		for (int i = 0; i < lights.length; i++) {
			shader.set("lights[" + i + "].pos", lights[i].getPosition());
			shader.set("lights[" + i + "].strength", lights[i].getStrength());
			shader.set("lights[" + i + "].color", lights[i].getDiffuse());
			shader.set("lights[" + i + "].spec", lights[i].getSpecular());
		}
		shader.set("camPos", GameEngine.getCam().getPos());
		renderer.renderQuad();
		shader.disable();
	}

	@Override
	public void cleanUp() {
		shader.cleanUp();
		renderer.cleanUp();
	}

	@Override
	public int getOutputTexture() {
		return renderer.getOutputTexture();
	}
}
