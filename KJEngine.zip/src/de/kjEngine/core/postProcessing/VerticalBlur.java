package de.kjEngine.core.postProcessing;

import org.lwjgl.opengl.*;

import de.kjEngine.core.*;
import de.kjEngine.core.api.Cleanable;

public class VerticalBlur implements Cleanable, Stage {
	
	private ImageRenderer renderer;
	private VerticalBlurShader shader;
	
	public VerticalBlur(int targetFboWidth, int targetFboHeight){
		shader = new VerticalBlurShader();
		renderer = new ImageRenderer(targetFboWidth, targetFboHeight);
		shader.enable();
		shader.loadTargetHeight(targetFboHeight);
		shader.disable();
	}
	
	public VerticalBlur(){
		shader = new VerticalBlurShader();
		renderer = new ImageRenderer();
		shader.enable();
		shader.loadTargetHeight(Display.getHeight());
		shader.disable();
	}

	
	public void render(int texture, int depthTexture){
		shader.enable();
		
		GL13.glActiveTexture(GL13.GL_TEXTURE0);
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, texture);
		
		GL13.glActiveTexture(GL13.GL_TEXTURE1);
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, depthTexture);
		
		renderer.renderQuad();
		shader.disable();
	}
	
	public int getOutputTexture(){
		return renderer.getOutputTexture();
	}
	
	@Override
	public void cleanUp(){
		renderer.cleanUp();
		shader.cleanUp();
	}
}
