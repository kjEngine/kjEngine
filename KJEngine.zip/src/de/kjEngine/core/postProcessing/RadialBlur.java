package de.kjEngine.core.postProcessing;

import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.util.vector.Vector2f;

import de.kjEngine.core.api.Cleanable;

public class RadialBlur implements Cleanable, Stage {
	
	private ImageRenderer renderer;
	private RadialBlurShader shader;
	
	private float amount;

	public RadialBlur(int targetFboWidth, int targetFboHeight, float amount){
		shader = new RadialBlurShader();
		renderer = new ImageRenderer(targetFboWidth, targetFboHeight);
		this.amount = amount;
	}
	
	public void render(int texture, int depthTexture, Vector2f src){
		shader.enable();
		
		GL13.glActiveTexture(GL13.GL_TEXTURE0);
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, texture);
		
		GL13.glActiveTexture(GL13.GL_TEXTURE1);
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, depthTexture);
		if (src == null) {
			return;
		}
		loadUniforms(new Vector2f(src.x * 0.5f + 0.5f, src.y * 0.5f + 0.5f));
		
		renderer.renderQuad();
		shader.disable();
	}
	
	private void loadUniforms(Vector2f src) {
		shader.blurFactor.loadFloat(amount);
		shader.blurPower.loadFloat(1f);
		shader.width.loadInt(Display.getWidth());
		shader.height.loadInt(Display.getHeight());
		shader.src.loadVec2(src);
	}

	public int getOutputTexture(){
		return renderer.getOutputTexture();
	}
	
	@Override
	public void cleanUp(){
		renderer.cleanUp();
		shader.cleanUp();
	}
}
