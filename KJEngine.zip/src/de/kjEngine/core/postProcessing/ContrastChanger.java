package de.kjEngine.core.postProcessing;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL13.*;

import de.kjEngine.core.*;
import de.kjEngine.core.api.Cleanable;

public class ContrastChanger implements Cleanable {
	
	private ImageRenderer renderer;
	private ContrastShader shader;

	public ContrastChanger() {
		renderer = new ImageRenderer();
		shader = new ContrastShader();
	}
	
	public void render(int texture) {
		shader.enable();
		
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture);
		
		renderer.renderQuad();
		
		shader.disable();
	}

	@Override
	public void cleanUp() {
		renderer.cleanUp();
		shader.cleanUp();
	}
}
