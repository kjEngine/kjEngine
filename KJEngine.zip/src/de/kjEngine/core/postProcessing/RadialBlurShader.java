package de.kjEngine.core.postProcessing;

import de.kjEngine.core.api.Shader;
import de.kjEngine.core.uniforms.UniformFloat;
import de.kjEngine.core.uniforms.UniformInt;
import de.kjEngine.core.uniforms.UniformVec2;

public class RadialBlurShader extends Shader {
	
	private static final String VERTEX_FILE = "/de/kjEngine/core/postProcessing/simpleVertex.glsl";
	private static final String FRAGMENT_FILE = "/de/kjEngine/core/postProcessing/radialBlurFragment.glsl";
	
	public UniformInt width, height;
	public UniformFloat blurPower, blurFactor;
	public UniformVec2 src;

	public RadialBlurShader() {
		super(VERTEX_FILE, FRAGMENT_FILE);
	}

	@Override
	protected void loadUniformLocations() {
		width = new UniformInt(id, "width");
		height = new UniformInt(id, "height");
		blurPower = new UniformFloat(id, "blurPower");
		blurFactor = new UniformFloat(id, "blurFactor");
		src = new UniformVec2(id, "radial_origin");
	}
}
