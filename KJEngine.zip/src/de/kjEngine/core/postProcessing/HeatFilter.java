package de.kjEngine.core.postProcessing;

import org.lwjgl.opengl.GL13;
import org.lwjgl.util.vector.Vector3f;

import de.kjEngine.core.api.GenericShader;
import de.kjEngine.core.util.OpenGlUtils;

public class HeatFilter extends AbstractStage {

	private static GenericShader loadHShader() {
		return new GenericShader("/de/kjEngine/core/postProcessing/simpleVertex.glsl",
				"/de/kjEngine/core/postProcessing/heatFragment.glsl");
	}

	public HeatFilter() {
		super(loadHShader());
	}

	public HeatFilter(int width, int height) {
		super(loadHShader(), width, height);
	}
	
	public void render(int norm, int speed, Vector3f dir) {
		shader.enable();
		OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE0, norm);
		OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE1, speed);
		shader.set("dir", dir.normalise(null));
		shader.set("a", dir.length());
		renderer.renderQuad();
		shader.disable();
	}
}
