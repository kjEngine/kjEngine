package de.kjEngine.core.postProcessing;

import de.kjEngine.core.api.Cleanable;

public interface Stage extends Cleanable {
	
	int getOutputTexture();
}
