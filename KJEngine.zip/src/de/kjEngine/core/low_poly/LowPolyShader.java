package de.kjEngine.core.low_poly;

import de.kjEngine.core.api.Shader;
import de.kjEngine.core.uniforms.UniformMat4;

public class LowPolyShader extends Shader {
	
	public UniformMat4 vpMat;

	public LowPolyShader(String vFile, String fFile) {
		super(vFile, fFile);
	}

	@Override
	protected void loadUniformLocations() {
		vpMat = new UniformMat4(id, "vpMat");
	}
}
