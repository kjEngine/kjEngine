package de.kjEngine.core.low_poly;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL20.*;
import static org.lwjgl.opengl.GL31.*;

import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL13;
import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector3f;

import de.kjEngine.core.api.Cleanable;
import de.kjEngine.core.api.Entity;
import de.kjEngine.core.model.Model;
import de.kjEngine.core.util.Loader;
import de.kjEngine.core.util.OpenGlUtils;

public class LowPolyRenderer implements Cleanable {

	private LowPolyShader shader;
	
	private int vbo;
	private int pointer = 0;
	
	private Matrix4f matrix_buffer = new Matrix4f();
	
	private static final int MAX_INSTANCES = 10000;
	private static final int INSTANCE_DATA_LENGTH = 16;

	private static final FloatBuffer buffer = BufferUtils.createFloatBuffer(MAX_INSTANCES * INSTANCE_DATA_LENGTH);

	public LowPolyRenderer() {
		shader = new LowPolyShader("/de/kjEngine/core/low_poly/vertexShader.glsl",
				"/de/kjEngine/core/low_poly/fragmentShader.glsl");
		vbo = Loader.createEmptyVbo(INSTANCE_DATA_LENGTH * MAX_INSTANCES);
	}
	
	public void render(Matrix4f vMat, Vector3f camPos, Matrix4f pMat, Map<Model, List<Entity>> entities) {
		prepare(vMat, pMat);
		_render(entities);
		end();
	}

	private void _render(Map<Model, List<Entity>> entities) {
		glClear(GL_DEPTH_BUFFER_BIT);

		OpenGlUtils.enableDepthTesting(true);

		OpenGlUtils.enableAlphaBlending();

		for (Model m : entities.keySet()) {
			Loader.addInstanceAttribute(m.getVao(), vbo, 3, 4, INSTANCE_DATA_LENGTH, 0);
			Loader.addInstanceAttribute(m.getVao(), vbo, 4, 4, INSTANCE_DATA_LENGTH, 4);
			Loader.addInstanceAttribute(m.getVao(), vbo, 5, 4, INSTANCE_DATA_LENGTH, 8);
			Loader.addInstanceAttribute(m.getVao(), vbo, 6, 4, INSTANCE_DATA_LENGTH, 12);

			m.enable();
			glEnableVertexAttribArray(3);
			glEnableVertexAttribArray(4);
			glEnableVertexAttribArray(5);
			glEnableVertexAttribArray(6);

			OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE0, m.getTexture().getID());

			List<Entity> el = new ArrayList<>();
			el = entities.get(m);

			pointer = 0;
			float[] vboData = new float[el.size() * INSTANCE_DATA_LENGTH];

			for (Entity e : el) {
				storeMatrix(e.getLocation(), vboData);
			}

			Loader.updateVbo(vbo, vboData, buffer);

			// GL40.glPatchParameteri(GL40.GL_PATCH_VERTICES, 3);
			OpenGlUtils.cullBackFaces(m.isCullingEnabled());
			glDrawElementsInstanced(GL_TRIANGLES, m.getIndexCount(), GL_UNSIGNED_INT, 0, el.size());

			glDisableVertexAttribArray(3);
			glDisableVertexAttribArray(4);
			glDisableVertexAttribArray(5);
			glDisableVertexAttribArray(6);
			m.disable();
		}

		OpenGlUtils.disableBlending();
	}
	
	private void storeMatrix(Matrix4f m, float[] f) {
		f[pointer++] = m.m00;
		f[pointer++] = m.m01;
		f[pointer++] = m.m02;
		f[pointer++] = m.m03;

		f[pointer++] = m.m10;
		f[pointer++] = m.m11;
		f[pointer++] = m.m12;
		f[pointer++] = m.m13;

		f[pointer++] = m.m20;
		f[pointer++] = m.m21;
		f[pointer++] = m.m22;
		f[pointer++] = m.m23;

		f[pointer++] = m.m30;
		f[pointer++] = m.m31;
		f[pointer++] = m.m32;
		f[pointer++] = m.m33;
	}

	private void prepare(Matrix4f vMat, Matrix4f pMat) {
		shader.enable();
		shader.vpMat.loadMatrix(Matrix4f.mul(pMat, vMat, matrix_buffer));
	}

	private void end() {
		shader.disable();
	}

	@Override
	public void cleanUp() {
		shader.cleanUp();
	}
}
