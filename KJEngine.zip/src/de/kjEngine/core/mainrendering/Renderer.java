package de.kjEngine.core.mainrendering;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL13.*;
import static org.lwjgl.opengl.GL20.*;
import static org.lwjgl.opengl.GL31.*;

import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector3f;
import org.lwjgl.util.vector.Vector4f;

import de.kjEngine.core.animations.AnimatedModelRenderer;
import de.kjEngine.core.api.Camera;
import de.kjEngine.core.api.Cleanable;
import de.kjEngine.core.api.ClipPlane;
import de.kjEngine.core.api.Entity;
import de.kjEngine.core.api.FogData;
import de.kjEngine.core.api.ViewPortSetting;
import de.kjEngine.core.awt.rendering.GuiRenderer;
import de.kjEngine.core.light.DirectionalLight;
import de.kjEngine.core.low_poly.LowPolyRenderer;
import de.kjEngine.core.model.Model;
import de.kjEngine.core.nmgeneration.NormalMapRenderer;
import de.kjEngine.core.particles.ParticleRenderer;
import de.kjEngine.core.plants.rock.RockRenderer;
import de.kjEngine.core.raytracing.RayTracer;
import de.kjEngine.core.raytracing.hybrit.HybritRayTracer;
import de.kjEngine.core.shadows.ShadowMapMasterRenderer;
import de.kjEngine.core.sky.box.SkyboxRenderer;
import de.kjEngine.core.sky.dome.SkyDomeRenderer;
import de.kjEngine.core.sun.SunRenderer;
import de.kjEngine.core.terrain.quadtree_oriented.QuadtreeTerrainRenderer;
import de.kjEngine.core.terrain.simple.TerrainRenderer;
import de.kjEngine.core.util.Loader;
import de.kjEngine.core.util.OpenGlUtils;
import de.kjEngine.core.water.WaterRenderer;

public class Renderer implements Cleanable {

	private Vector4f clearColor = new Vector4f();
	private MainShader shader;
	private Matrix4f pMat;
	private Map<Model, List<Entity>> entitys = new HashMap<>();
	private boolean removingEntitysAfterRendering = true;
	private DirectionalLight sun;
	private ViewPortSetting viewPortSetting;

	private SkyboxRenderer skyboxRenderer;
	private ShadowMapMasterRenderer shadowMapMasterRenderer;
	private WaterRenderer waterRenderer;
	private GuiRenderer guiRenderer;
	private ParticleRenderer particleRenderer;
	private AnimatedModelRenderer animatedModelRenderer;
	private SunRenderer sunRenderer;
	private RayTracer rayTracer;
	private TerrainRenderer terrainRenderer;
	private SkyDomeRenderer skyDomeRenderer;
	private QuadtreeTerrainRenderer quadtreeTerrainRenderer;
	private NormalMapRenderer normalMapRenderer;
	private RockRenderer rockRenderer;
	private LowPolyRenderer lowPolyRenderer;
	private HybritRayTracer hybritRayTracer;

	private float renderDistance;
	private FogData fog;

	private ClipPlane clipPlane0;

	private int vbo;
	private int pointer = 0;

	private static final int MAX_INSTANCES = 10000;
	private static final int INSTANCE_DATA_LENGTH = 16;

	private static final FloatBuffer buffer = BufferUtils.createFloatBuffer(MAX_INSTANCES * INSTANCE_DATA_LENGTH);

	public Renderer(ViewPortSetting setting, Camera cam) {
		shader = new MainShader();
		pMat = Loader.genPerspectiveMatrix(setting);
		viewPortSetting = setting;
		sun = new DirectionalLight(new Vector4f(0.9f, 0.9f, 0.9f, 1f), new Vector4f(0.9f, 0.9f, 0.9f, 1f),
				new Vector4f(0.9f, 0.9f, 0.9f, 1f), new Vector3f(0f, -1f, 0f), false);
		fog = new FogData();

		initRenderers(cam);

		clipPlane0 = new ClipPlane(new Vector4f(), false);

		vbo = Loader.createEmptyVbo(INSTANCE_DATA_LENGTH * MAX_INSTANCES);
	}

	private void initRenderers(Camera cam) {
		skyboxRenderer = new SkyboxRenderer();
		shadowMapMasterRenderer = new ShadowMapMasterRenderer(cam, this);
		waterRenderer = new WaterRenderer();
		guiRenderer = new GuiRenderer();
		particleRenderer = new ParticleRenderer();
		animatedModelRenderer = new AnimatedModelRenderer(this);
		sunRenderer = new SunRenderer();
		rayTracer = new RayTracer();
		terrainRenderer = new TerrainRenderer();
		skyboxRenderer = new SkyboxRenderer();
		skyDomeRenderer = new SkyDomeRenderer();
		quadtreeTerrainRenderer = new QuadtreeTerrainRenderer();
		normalMapRenderer = new NormalMapRenderer();
		rockRenderer = new RockRenderer();
		lowPolyRenderer = new LowPolyRenderer();
		hybritRayTracer = new HybritRayTracer();
	}

	public void recalculatePMat() {
		pMat = Loader.genPerspectiveMatrix(viewPortSetting);
	}

	public void clear() {
		glClear(GL_COLOR_BUFFER_BIT);
		glClear(GL_DEPTH_BUFFER_BIT);
		glClearColor(clearColor.x, clearColor.y, clearColor.z, clearColor.w);
	}

	public void renderShadowmap() {
		shadowMapMasterRenderer.render(entitys, sun, this);
	}
	
	public void render(Matrix4f vMat, Vector3f camPos, boolean instaced) {
		if (instaced) {
			render(vMat, camPos);
		} else {
			shader.enable();

			shader.pMat.loadMatrix(pMat);
			shader.vMat.loadMatrix(vMat);
			shader.camPos.loadVec3(camPos);
			shader.fog.loadFog(fog);
			shader.sun.loadLight(sun);

			glClear(GL_DEPTH_BUFFER_BIT);

			OpenGlUtils.enableDepthTesting(true);

			OpenGlUtils.enableAlphaBlending();
			
			int shadows = 1;
			int[] samplers = new int[shadows];

			for (int i = 0; i < shadows; i++) {
				samplers[i] = i;
			}

			shader.shadows.loadInt(0);
			shader.shadowSamplers.loadIntArray(samplers);
			shader.shadowMapSizes.loadFloatArray(new float[] { ShadowMapMasterRenderer.SHADOW_MAP_SIZE });
			shader.shadowTransforms.loadMatrixArray(new Matrix4f[] { shadowMapMasterRenderer.getToShadowMapSpaceMatrix() });

			glActiveTexture(GL_TEXTURE0);
			glBindTexture(GL_TEXTURE_2D, shadowMapMasterRenderer.getShadowMap());
			
			for (Model m : entitys.keySet()) {
				m.enable();
				
				shader.mat.loadMaterial(m.getMaterial(), 0 + shadows, 1 + shadows, 2 + shadows, 3 + shadows);
				
				for (Entity e : entitys.get(m)) {
					shader.mMat.loadMatrix(e.getLocation());
					glDrawElements(GL11.GL_TRIANGLES, m.getIndexCount(), GL11.GL_UNSIGNED_INT, 0);
				}
				m.disable();
			}
			
			shader.disable();
		}
	}

	public void render(Matrix4f vMat, Vector3f camPos) {
		shader.enable();

		shader.pMat.loadMatrix(pMat);
		shader.vMat.loadMatrix(vMat);
		shader.camPos.loadVec3(camPos);
		shader.fog.loadFog(fog);
		shader.sun.loadLight(sun);

		glClear(GL_DEPTH_BUFFER_BIT);

		OpenGlUtils.enableDepthTesting(true);

		OpenGlUtils.enableAlphaBlending();

		int shadows = 1;
		int[] samplers = new int[shadows];

		for (int i = 0; i < shadows; i++) {
			samplers[i] = i;
		}

		shader.shadows.loadInt(0);
		shader.shadowSamplers.loadIntArray(samplers);
		shader.shadowMapSizes.loadFloatArray(new float[] { ShadowMapMasterRenderer.SHADOW_MAP_SIZE });
		shader.shadowTransforms.loadMatrixArray(new Matrix4f[] { shadowMapMasterRenderer.getToShadowMapSpaceMatrix() });

		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, shadowMapMasterRenderer.getShadowMap());

		for (Model m : entitys.keySet()) {
			Loader.addInstanceAttribute(m.getVao(), vbo, 3, 4, INSTANCE_DATA_LENGTH, 0);
			Loader.addInstanceAttribute(m.getVao(), vbo, 4, 4, INSTANCE_DATA_LENGTH, 4);
			Loader.addInstanceAttribute(m.getVao(), vbo, 5, 4, INSTANCE_DATA_LENGTH, 8);
			Loader.addInstanceAttribute(m.getVao(), vbo, 6, 4, INSTANCE_DATA_LENGTH, 12);

			m.enable();
			glEnableVertexAttribArray(3);
			glEnableVertexAttribArray(4);
			glEnableVertexAttribArray(5);
			glEnableVertexAttribArray(6);

			shader.mat.loadMaterial(m.getMaterial(), 0 + shadows, 1 + shadows, 2 + shadows, 3 + shadows);
			
			OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE24, m.getTexture().getID());

			List<Entity> el = new ArrayList<>();
			el = entitys.get(m);

			pointer = 0;
			float[] vboData = new float[el.size() * INSTANCE_DATA_LENGTH];

			for (Entity e : el) {
				storeMatrix(e.getLocation(), vboData);
			}

			Loader.updateVbo(vbo, vboData, buffer);

			// GL40.glPatchParameteri(GL40.GL_PATCH_VERTICES, 3);
			OpenGlUtils.cullBackFaces(m.isCullingEnabled());
			glDrawElementsInstanced(GL_TRIANGLES, m.getIndexCount(), GL_UNSIGNED_INT, 0, el.size());

			glDisableVertexAttribArray(3);
			glDisableVertexAttribArray(4);
			glDisableVertexAttribArray(5);
			glDisableVertexAttribArray(6);
			m.disable();
		}

		glDisable(GL_BLEND);

		shader.disable();

		if (removingEntitysAfterRendering)
			entitys.clear();
	}

	private void storeMatrix(Matrix4f m, float[] f) {
		f[pointer++] = m.m00;
		f[pointer++] = m.m01;
		f[pointer++] = m.m02;
		f[pointer++] = m.m03;

		f[pointer++] = m.m10;
		f[pointer++] = m.m11;
		f[pointer++] = m.m12;
		f[pointer++] = m.m13;

		f[pointer++] = m.m20;
		f[pointer++] = m.m21;
		f[pointer++] = m.m22;
		f[pointer++] = m.m23;

		f[pointer++] = m.m30;
		f[pointer++] = m.m31;
		f[pointer++] = m.m32;
		f[pointer++] = m.m33;
	}

	public void processEntity(Entity e) {
		Model[] models = e.getModels();
		for (Model m : models) {
			List<Entity> batch = entitys.get(m);
			if (batch == null)
				batch = new ArrayList<>();
			batch.add(e);
			entitys.put(m, batch);
		}
	}

	@Override
	public void cleanUp() {
		shader.cleanUp();
		skyboxRenderer.cleanUp();
		shadowMapMasterRenderer.cleanUp();
		waterRenderer.cleanUp();
		guiRenderer.cleanUp();
		particleRenderer.cleanUp();
		animatedModelRenderer.cleanUp();
		sunRenderer.cleanUp();
		rayTracer.cleanUp();
		skyDomeRenderer.cleanUp();
		normalMapRenderer.cleanUp();
		rockRenderer.cleanUp();
		lowPolyRenderer.cleanUp();
		hybritRayTracer.cleanUp();
	}

	public void clearEntitys() {
		entitys.clear();
	}

	public int getShadowTexture() {
		return shadowMapMasterRenderer.getShadowMap();
	}

	public ShadowMapMasterRenderer getShadowMapMasterRenderer() {
		return shadowMapMasterRenderer;
	}

	public Vector4f getClearColor() {
		return clearColor;
	}

	public void setClearColor(Vector4f clearColor) {
		this.clearColor = clearColor;
	}

	public Matrix4f getpMat() {
		return pMat;
	}

	public void setpMat(Matrix4f pMat) {
		this.pMat = pMat;
	}

	public boolean isRemovingEntitysAfterRendering() {
		return removingEntitysAfterRendering;
	}

	public void setRemovingEntitysAfterRendering(boolean removingEntitysAfterRendering) {
		this.removingEntitysAfterRendering = removingEntitysAfterRendering;
	}

	public DirectionalLight getSun() {
		return sun;
	}

	public void setSun(DirectionalLight sun) {
		this.sun = sun;
	}

	public float getRenderDistance() {
		return renderDistance;
	}

	public void setRenderDistance(float renderDistance) {
		this.renderDistance = renderDistance;
	}

	public FogData getFog() {
		return fog;
	}

	public void setFog(FogData fog) {
		this.fog = fog;
	}

	public SkyboxRenderer getSkyboxRenderer() {
		return skyboxRenderer;
	}

	public ViewPortSetting getViewPortSetting() {
		return viewPortSetting;
	}

	public void setViewPortSetting(ViewPortSetting viewPortSetting) {
		this.viewPortSetting = viewPortSetting;
		updatepMat();
	}

	public void updatepMat() {
		pMat = Loader.genPerspectiveMatrix(viewPortSetting);
	}

	public WaterRenderer getWaterRenderer() {
		return waterRenderer;
	}

	public GuiRenderer getGuiRenderer() {
		return guiRenderer;
	}

	public ParticleRenderer getParticleRenderer() {
		return particleRenderer;
	}

	public ClipPlane getClipPlane0() {
		return clipPlane0;
	}

	public void setClipPlane0(ClipPlane clipPlane0) {
		this.clipPlane0 = clipPlane0;
	}

	public void activateClipPlane0() {
		clipPlane0.setActive(true);
	}

	public void deactivateClipPlane0() {
		clipPlane0.setActive(false);
	}

	/**
	 * @return the animatedModelRenderer
	 */
	public AnimatedModelRenderer getAnimatedModelRenderer() {
		return animatedModelRenderer;
	}

	/**
	 * @return the sunRenderer
	 */
	public SunRenderer getSunRenderer() {
		return sunRenderer;
	}

	/**
	 * @return the rayTracer
	 */
	public RayTracer getRayTracer() {
		return rayTracer;
	}

	/**
	 * @return the terrainRenderer
	 */
	public TerrainRenderer getTerrainRenderer() {
		return terrainRenderer;
	}

	/**
	 * @return the skyDomeRenderer
	 */
	public SkyDomeRenderer getSkyDomeRenderer() {
		return skyDomeRenderer;
	}

	/**
	 * @return the quadtreeTerrainRenderer
	 */
	public QuadtreeTerrainRenderer getQuadtreeTerrainRenderer() {
		return quadtreeTerrainRenderer;
	}

	/**
	 * @return the normalMapRenderer
	 */
	public NormalMapRenderer getNormalMapRenderer() {
		return normalMapRenderer;
	}

	public RockRenderer getRockRenderer() {
		return rockRenderer;
	}

	public LowPolyRenderer getLowPolyRenderer() {
		return lowPolyRenderer;
	}

	public Map<Model, List<Entity>> getEntitys() {
		return entitys;
	}

	public HybritRayTracer getHybritRayTracer() {
		return hybritRayTracer;
	}
}
