package de.kjEngine.core.mainrendering;

import de.kjEngine.core.api.FogData;
import de.kjEngine.core.uniforms.Uniform;
import de.kjEngine.core.uniforms.UniformFloat;
import de.kjEngine.core.uniforms.UniformVec4;

public class UniformFog extends Uniform {
	
	private UniformFloat minDist, maxDist;
	private UniformVec4 col;

	public UniformFog(int program, String name) {
		super(program, name);
	}

	@Override
	protected void storeUniformLocation(int programID) {
		minDist = new UniformFloat(programID, name + ".minDist");
		maxDist = new UniformFloat(programID, name + ".maxDist");
		col = new UniformVec4(programID, name + ".col");
	}
	
	public void loadFog(FogData data) {
		minDist.loadFloat(data.getMinFog());
		maxDist.loadFloat(data.getMaxFog());
		col.loadVec4(data.getFogColor());
	}
}
