package de.kjEngine.core.mainrendering;

import de.kjEngine.core.api.Shader;
import de.kjEngine.core.uniforms.UniformDirectionalLight;
import de.kjEngine.core.uniforms.UniformFloatArray;
import de.kjEngine.core.uniforms.UniformInt;
import de.kjEngine.core.uniforms.UniformIntArray;
import de.kjEngine.core.uniforms.UniformMat4;
import de.kjEngine.core.uniforms.UniformMat4Array;
import de.kjEngine.core.uniforms.UniformMaterial;
import de.kjEngine.core.uniforms.UniformVec3;
import de.kjEngine.core.uniforms.UniformVec4;

public class MainShader extends Shader {

	public UniformMat4 mMat, vMat, pMat;
	public UniformMat4Array shadowTransforms;
	public UniformVec4 clipPlane;
	public UniformVec3 camPos;
	public UniformInt shadows;
	public UniformFloatArray shadowMapSizes;
	public UniformFog fog;
	public UniformIntArray shadowSamplers;
	public UniformDirectionalLight sun;
	public UniformMaterial mat;

	public MainShader() {
		super("/de/kjEngine/core/mainrendering/vertexShader.glsl",
				"/de/kjEngine/core/mainrendering/fragmentShader.glsl");
	}

	@Override
	protected void loadUniformLocations() {
		mMat = new UniformMat4(id, "mMat");
		vMat = new UniformMat4(id, "vMat");
		pMat = new UniformMat4(id, "pMat");
		shadowTransforms = new UniformMat4Array(id, "toShadowSpace", 8);
		clipPlane = new UniformVec4(id, "clipPlane0");
		camPos = new UniformVec3(id, "camPos");
		shadows = new UniformInt(id, "shadows");
		shadowMapSizes = new UniformFloatArray(id, "shadowMapSize", 8);
		fog = new UniformFog(id, "fog");
		shadowSamplers = new UniformIntArray(id, "shadow", 8);
		sun = new UniformDirectionalLight(id, "sun");
		mat = new UniformMaterial(id, "mat");
	}
}
