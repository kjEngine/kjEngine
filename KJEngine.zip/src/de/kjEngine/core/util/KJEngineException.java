package de.kjEngine.core.util;

public class KJEngineException extends Exception {
	
	private static final long serialVersionUID = -7652404090296184860L;

	public KJEngineException() {
	}

	public KJEngineException(String message) {
		super(message);
	}

	public KJEngineException(Throwable cause) {
		super(cause);
	}

	public KJEngineException(String message, Throwable cause) {
		super(message, cause);
	}

	public KJEngineException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
}
