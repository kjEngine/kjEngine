package de.kjEngine.core.util;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL13.*;
import static org.lwjgl.opengl.GL15.*;
import static org.lwjgl.opengl.GL20.*;
import static org.lwjgl.opengl.GL30.*;
import static org.lwjgl.opengl.GL33.*;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;

import org.lwjgl.opengl.GL33;
import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;
import org.lwjgl.util.vector.Vector4f;
import org.newdawn.slick.opengl.Texture;
import org.newdawn.slick.util.BufferedImageUtil;

import de.kjEngine.core.api.TextureData;
import de.kjEngine.core.api.ViewPortSetting;
import de.kjEngine.core.awt.font.FontType;
import de.kjEngine.core.awt.font.GUIText;
import de.kjEngine.core.awt.font.Text;
import de.kjEngine.core.awt.font.TextMeshData;
import de.kjEngine.core.model.Mesh;
import de.kjEngine.core.model.MeshBuilder;
import de.kjEngine.core.model.MeshBuilder.BuildType;
import de.kjEngine.core.model.Model;
import de.matthiasmann.twl.utils.PNGDecoder.Format;

public class Loader {

	public static String loadFile(String path) {

		StringBuilder sb = new StringBuilder();

		try (InputStream in = Loader.class.getResourceAsStream(path);
				BufferedReader br = new BufferedReader(new InputStreamReader(in));) {

			String line = "";

			while ((line = br.readLine()) != null) {
				sb.append(line + "\n");
			}
			br.close();
		} catch (IOException e) {

			System.err.println("Could not load file: " + path);
			return "";
		}
		return sb.toString();
	}

	public static Text loadText(GUIText text) {
		FontType font = text.getFont();
		TextMeshData data = font.loadText(text);
		int vao = loadModel2D(data.getVertexPositions(), data.getTextureCoords());
		text.setMeshInfo(vao, data.getVertexCount());
		return new Text(font, text);
	}

	public static Model loadModel(Mesh mesh, KTexture texture, String name) {
		return loadModel3D(mesh.getVertices(), mesh.getTexCoords(), mesh.getNormals(), mesh.getIndices(), texture,
				name);
	}

	public static int createEmptyVbo(int floatCount) {
		int vbo = glGenBuffers();
		glBindBuffer(GL_ARRAY_BUFFER, vbo);
		glBufferData(GL_ARRAY_BUFFER, floatCount * 4, GL_STREAM_DRAW);
		glBindBuffer(GL_ARRAY_BUFFER, 0);
		return vbo;
	}

	public static void addInstanceAttribute(int vao, int vbo, int attribute, int dataSize, int instancedDataLength,
			int offset) {
		glBindBuffer(GL_ARRAY_BUFFER, vbo);
		glBindVertexArray(vao);
		glVertexAttribPointer(attribute, dataSize, GL_FLOAT, false, instancedDataLength * 4, offset * 4);
		glVertexAttribDivisor(attribute, 1);
		glBindBuffer(GL_ARRAY_BUFFER, 0);
		glBindVertexArray(0);
	}

	public static void updateVbo(int vbo, float[] data, FloatBuffer buffer) {
		buffer.clear();
		buffer.put(data);
		buffer.flip();
		glBindBuffer(GL_ARRAY_BUFFER, vbo);
		glBufferData(GL_ARRAY_BUFFER, buffer.capacity() * 4, GL_STREAM_DRAW);
		glBufferSubData(GL_ARRAY_BUFFER, 0, buffer);
		glBindBuffer(GL_ARRAY_BUFFER, 0);
	}

	public static Model loadPatch2D(float[] vertices) {
		int vao = genVao();
		if (vertices == null)
			vertices = new float[] {};
		int vbo = storeData(vertices, 2, 0);
		glBindVertexArray(0);
		return new Model(vao, vertices.length / 2, new KTexture(0), new int[] { vbo }, "patch");
	}

	public static int loadModel2D(float[] vertices, float[] texCoords) {
		int vao = genVao();
		if (vertices == null)
			vertices = new float[] {};
		storeData(vertices, 2, 0);
		if (texCoords == null)
			texCoords = new float[] {};
		storeData(texCoords, 2, 1);
		glBindVertexArray(0);
		return vao;
	}

	public static Model loadModel3D(float[] vertices, float[] texCoords, float[] normals, int[] indices,
			KTexture texture, String name) {
		int vao = genVao();
		int[] vbos = new int[3];
		if (vertices == null)
			vertices = new float[] {};
		vbos[0] = storeData(vertices, 3, 0);
		if (texCoords == null)
			texCoords = new float[] {};
		vbos[1] = storeData(texCoords, 2, 1);
		if (normals == null)
			normals = new float[] {};
		vbos[2] = storeData(normals, 3, 2);
		if (indices == null)
			indices = new int[] {};
		storeIndices(indices);
		glBindVertexArray(0);
		return new Model(vao, indices.length, texture, vbos, name, new Mesh(vertices, indices, texCoords, normals));
	}

	public static int genVao() {
		int id = glGenVertexArrays();
		glBindVertexArray(id);
		return id;
	}

	public static int storeData(float[] data, int dimensions, int index) {
		int id = glGenBuffers();
		glBindBuffer(GL_ARRAY_BUFFER, id);
		glBufferData(GL_ARRAY_BUFFER, Buffers.newFloatBuffer(data), GL_STATIC_DRAW);
		glVertexAttribPointer(index, dimensions, GL_FLOAT, false, 0, 0);
		glBindBuffer(GL_ARRAY_BUFFER, 0);
		return id;
	}

	public static int storeData(int[] data, int dimensions, int index) {
		int id = glGenBuffers();
		glBindBuffer(GL_ARRAY_BUFFER, id);
		glBufferData(GL_ARRAY_BUFFER, Buffers.newIntBuffer(data), GL_STATIC_DRAW);
		glVertexAttribPointer(index, dimensions, GL_INT, false, 0, 0);
		glBindBuffer(GL_ARRAY_BUFFER, 0);
		return id;
	}

	public static void storeIndices(int[] data) {
		int id = glGenBuffers();
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, id);
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, Buffers.newIntBuffer(data), GL_STATIC_DRAW);
	}

	public static int loadEmptyTexture(int width, int height, int format) {
		int id = glGenTextures();
		FloatBuffer buffer = null;
		glBindTexture(GL_TEXTURE_2D, id);
		glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_FLOAT, buffer);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		return id;
	}

	public static int loadTexturei(String path) {
		Texture tex = null;
		try {
//			if (path.endsWith(".png")) {
//				tex = TextureLoader.getTexture("PNG", new FileInputStream(new File(path)));
//			} else if (path.endsWith(".jpg")) {
//				tex = TextureLoader.getTexture("JPG", new FileInputStream(new File(path)));
//			} else if (path.endsWith(".bmp")) {
//				tex = TextureLoader.getTexture("BMP", new FileInputStream(new File(path)));
//			}
			BufferedImage img;
			if (path.startsWith("/")) {
				img = ImageIO.read(Loader.class.getResourceAsStream(path));
			} else {
				img = ImageIO.read(new File(path));
			}
			tex = BufferedImageUtil.getTexture("", img);
		} catch (IOException e) {
			System.err.println("Could not load texture: " + path);
			return 0;
		}
		int id = tex.getTextureID();

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

//		if (GLContext.getCapabilities().GL_EXT_texture_filter_anisotropic) {
//			float amount = Math.min(4f, EXTTextureFilterAnisotropic.GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT);
//			glTexParameterf(GL_TEXTURE_2D, EXTTextureFilterAnisotropic.GL_TEXTURE_MAX_ANISOTROPY_EXT, amount);
//		}

		return id;
	}

	public static Matrix4f genPerspectiveMatrix(ViewPortSetting setting) {
		return genPerspectiveMatrix(setting.getFovy(), setting.getAspect(), setting.getNear(), setting.getFar());
	}

	public static Matrix4f genPerspectiveMatrix(float fovy, float aspect, float n, float f) {
		Matrix4f result = Matrix4f.setIdentity(new Matrix4f());

		float q = 1.0f / ((float) Math.tan(Math.toRadians(0.5f * fovy)));
		float A = q / aspect;
		float B = (n + f) / (n - f);
		float C = (2.0f * n * f) / (n - f);

		result.m00 = A;
		result.m11 = q;
		result.m22 = B;
		result.m23 = -1f;
		result.m32 = C;

		return result;
	}

	public static Model loadObjModel(String path, KTexture texture, boolean relative, String name) {
		if (!relative) {
			try {
				Mesh m = loadObjMesh(new FileInputStream(new File(path)));
				return loadModel(m, texture, name);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
				return null;
			}
		} else {
			return loadRelativeObjModel(path, texture, name, Loader.class);
		}
	}

	public static Model loadRelativeObjModel(String path, KTexture texture, String name, Class<?> c) {
		Mesh m = loadObjMesh(c.getResourceAsStream(path));
		return loadModel(m, texture, name);
	}

	public static Model loadObjModel(String path, KTexture texture, String name) {
		return loadObjModel(path, texture, false, name);
	}

	public static Mesh loadObjMesh(InputStream in) {
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(in));

			List<Vector3f> vertices = new ArrayList<>();
			List<Vector2f> texCoords = new ArrayList<>();
			List<Vector3f> normals = new ArrayList<>();
			List<Integer> indices = new ArrayList<>();

			float[] verticesArray = null;
			float[] texCoordsArray = null;
			float[] normalsArray = null;
			int[] indicesArray = null;

			String line = "";

			while (true) {

				line = br.readLine();
				String[] currentLine = line.split(" ");

				if (line.startsWith("v ")) {
					Vector3f vec = new Vector3f(Float.parseFloat(currentLine[1]), Float.parseFloat(currentLine[2]),
							Float.parseFloat(currentLine[3]));
					vertices.add(vec);
				} else if (line.startsWith("vt ")) {
					Vector2f vec = new Vector2f(Float.parseFloat(currentLine[1]), Float.parseFloat(currentLine[2]));
					texCoords.add(vec);
				} else if (line.startsWith("vn ")) {
					Vector3f vec = new Vector3f(Float.parseFloat(currentLine[1]), Float.parseFloat(currentLine[2]),
							Float.parseFloat(currentLine[3]));
					normals.add(vec);
				} else if (line.startsWith("f ")) {
					texCoordsArray = new float[vertices.size() * 2];
					normalsArray = new float[vertices.size() * 3];
					break;
				}
			}

			while (line != null) {

				if (!line.startsWith("f ")) {
					line = br.readLine();
					continue;
				}
				String[] currentLine = line.split(" ");
				String[] vertex1 = currentLine[1].split("/");
				String[] vertex2 = currentLine[2].split("/");
				String[] vertex3 = currentLine[3].split("/");

				processVertex(vertex1, indices, texCoords, normals, texCoordsArray, normalsArray);
				processVertex(vertex2, indices, texCoords, normals, texCoordsArray, normalsArray);
				processVertex(vertex3, indices, texCoords, normals, texCoordsArray, normalsArray);

				line = br.readLine();
			}

			verticesArray = new float[vertices.size() * 3];
			indicesArray = new int[indices.size()];

			int vertexPointer = 0;

			for (Vector3f vec : vertices) {
				verticesArray[vertexPointer++] = vec.x;
				verticesArray[vertexPointer++] = vec.y;
				verticesArray[vertexPointer++] = vec.z;
			}

			for (int i = 0; i < indices.size(); i++) {
				indicesArray[i] = indices.get(i);
			}

			br.close();

			return new Mesh(verticesArray, indicesArray, texCoordsArray, normalsArray);

		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}

	private static void processVertex(String[] vertexData, List<Integer> indices, List<Vector2f> texCoords,
			List<Vector3f> normals, float[] texCoordArray, float[] normalArray) {

		try {
			int currentVertexPointer = Integer.parseInt(vertexData[0]) - 1;
			indices.add(currentVertexPointer);

			String tcs = vertexData[1];
			Vector2f currentTex = new Vector2f();
			if (!tcs.equals(""))
				currentTex = texCoords.get(Integer.parseInt(tcs) - 1);

			texCoordArray[currentVertexPointer * 2] = currentTex.x;
			texCoordArray[currentVertexPointer * 2 + 1] = 1f - currentTex.y;

			Vector3f currentNorm = normals.get(Integer.parseInt(vertexData[2]) - 1);
			normalArray[currentVertexPointer * 3] = currentNorm.x;
			normalArray[currentVertexPointer * 3 + 1] = currentNorm.y;
			normalArray[currentVertexPointer * 3 + 2] = currentNorm.z;
		} catch (Exception e) {
		}
	}

	private static final float ONE_D_255 = 1f / 255f;

	public static int loadColorToTexture(int color) {
		int r = (color >> 24) & 0xff;
		int g = (color >> 16) & 0xff;
		int b = (color >> 8) & 0xff;
		int a = (color) & 0xff;

		return loadColorToTexture(new Vector4f(r * ONE_D_255, g * ONE_D_255, b * ONE_D_255, a * ONE_D_255));
	}

	public static int loadColorToTexture(Vector4f color) {
		int id = glGenTextures();
		glBindTexture(GL_TEXTURE_2D, id);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 1, 1, 0, GL_RGBA, GL_FLOAT,
				Buffers.newFloatBuffer(new float[] { color.x, color.y, color.z, color.w }));
		glBindTexture(GL_TEXTURE_2D, 0);
		return id;
	}

	public static Model genTerrain(int width, int height, float scale, float amplitude, float steepness, int texture,
			float tiling, String name) {
		return genTerrain(width, height, scale, amplitude, steepness, texture, tiling, null, -1, name);
	}

	public static Model genTerrain(int width, int height, float scale, float amplitude, float steepness, int texture,
			float tiling, float[][] heights, long seed, String name) {
		Noise noise;
		if (seed == -1)
			noise = new Noise(amplitude);
		else
			noise = new Noise(amplitude, seed);

		Vector3f[] positions = new Vector3f[width * height];
		Vector2f[] texCoords = new Vector2f[width * height];
		Vector3f[] normals = new Vector3f[width * height];

		for (int i = 0; i < positions.length; i++) {
			positions[i] = new Vector3f();
			texCoords[i] = new Vector2f();
			normals[i] = new Vector3f();
		}
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {

				float h = noise.getNoise(x * steepness, y * steepness);

				if (heights != null)
					heights[x][y] = h;

				positions[x + y * width].x = (float) x * scale;
				positions[x + y * width].y = h;
				positions[x + y * width].z = (float) y * scale;

				float tx = ((float) x / (float) width) * tiling;
				float ty = ((float) y / (float) height) * tiling;

				texCoords[x + y * width].x = (tx - (int) tx);
				texCoords[x + y * width].y = (ty - (int) ty);

				if (x > 0 && y > 0) {

					Vector3f a = new Vector3f(-1f, positions[x + y * width].y - positions[(x - 1) + y * width].y, 0);
					Vector3f b = new Vector3f(0, positions[x + y * width].y - positions[x + (y - 1) * width].y, -1f);

					a.normalise();
					b.normalise();

					Vector3f c = Vector3f.cross(b, a, null);
					c.normalise();

					normals[x + y * width].x = (float) c.getX();
					normals[x + y * width].y = (float) c.getY();
					normals[x + y * width].z = (float) c.getZ();
				} else {
					normals[x + y * width].x = (float) 0;
					normals[x + y * width].y = (float) 1f;
					normals[x + y * width].z = (float) 0;
				}
			}
		}
		float[] posa = new float[positions.length * 3];
		float[] texa = new float[positions.length * 2];
		float[] norma = new float[positions.length * 3];

		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {

				posa[(x + y * width) * 3 + 0] = positions[x + y * width].x;
				posa[(x + y * width) * 3 + 1] = positions[x + y * width].y;
				posa[(x + y * width) * 3 + 2] = positions[x + y * width].z;

				texa[(x + y * width) * 2 + 0] = texCoords[x + y * width].x;
				texa[(x + y * width) * 2 + 1] = texCoords[x + y * width].y;

				norma[(x + y * width) * 3 + 0] = normals[x + y * width].x;
				norma[(x + y * width) * 3 + 1] = normals[x + y * width].y;
				norma[(x + y * width) * 3 + 2] = normals[x + y * width].z;
			}
		}
		int[] indices = new int[(width - 1) * (height - 1) * 6];

		for (int y = 0; y < height - 1; y++) {
			for (int x = 0; x < width - 1; x++) {

				indices[(x + y * (width - 1)) * 6 + 0] = ((x + 0) + (y + 0) * width);
				indices[(x + y * (width - 1)) * 6 + 1] = ((x + 0) + (y + 1) * width);
				indices[(x + y * (width - 1)) * 6 + 2] = ((x + 1) + (y + 1) * width);
				indices[(x + y * (width - 1)) * 6 + 3] = ((x + 1) + (y + 1) * width);
				indices[(x + y * (width - 1)) * 6 + 4] = ((x + 1) + (y + 0) * width);
				indices[(x + y * (width - 1)) * 6 + 5] = ((x + 0) + (y + 0) * width);
			}
		}
		return loadModel3D(posa, texa, norma, indices, new KTexture(texture), name);
	}

	public static Model genTerrainFromHeightmap(int width, int height, float scale, int texture, float tiling,
			float[][] heights, String name) {
		Vector3f[] positions = new Vector3f[width * height];
		Vector2f[] texCoords = new Vector2f[width * height];
		Vector3f[] normals = new Vector3f[width * height];

		for (int i = 0; i < positions.length; i++) {
			positions[i] = new Vector3f();
			texCoords[i] = new Vector2f();
			normals[i] = new Vector3f();
		}
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {

				float h = heights[x][y];

				if (heights != null)
					heights[x][y] = h;

				positions[x + y * width].x = (float) x * scale;
				positions[x + y * width].y = h;
				positions[x + y * width].z = (float) y * scale;

				float tx = ((float) x / (float) width) * tiling;
				float ty = ((float) y / (float) height) * tiling;

				texCoords[x + y * width].x = (tx - (int) tx);
				texCoords[x + y * width].y = (ty - (int) ty);

				if (x > 0 && y > 0) {

					Vector3f a = new Vector3f(-1f, positions[x + y * width].y - positions[(x - 1) + y * width].y, 0);
					Vector3f b = new Vector3f(0, positions[x + y * width].y - positions[x + (y - 1) * width].y, -1f);

					a.normalise();
					b.normalise();

					Vector3f c = Vector3f.cross(b, a, null);
					c.normalise();

					normals[x + y * width].x = (float) c.getX();
					normals[x + y * width].y = (float) c.getY();
					normals[x + y * width].z = (float) c.getZ();
				} else {
					normals[x + y * width].x = (float) 0;
					normals[x + y * width].y = (float) 1f;
					normals[x + y * width].z = (float) 0;
				}
			}
		}
		float[] posa = new float[positions.length * 3];
		float[] texa = new float[positions.length * 2];
		float[] norma = new float[positions.length * 3];

		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {

				posa[(x + y * width) * 3 + 0] = positions[x + y * width].x;
				posa[(x + y * width) * 3 + 1] = positions[x + y * width].y;
				posa[(x + y * width) * 3 + 2] = positions[x + y * width].z;

				texa[(x + y * width) * 2 + 0] = texCoords[x + y * width].x;
				texa[(x + y * width) * 2 + 1] = texCoords[x + y * width].y;

				norma[(x + y * width) * 3 + 0] = normals[x + y * width].x;
				norma[(x + y * width) * 3 + 1] = normals[x + y * width].y;
				norma[(x + y * width) * 3 + 2] = normals[x + y * width].z;
			}
		}
		int[] indices = new int[(width - 1) * (height - 1) * 6];

		for (int y = 0; y < height - 1; y++) {
			for (int x = 0; x < width - 1; x++) {

				indices[(x + y * (width - 1)) * 6 + 0] = ((x + 0) + (y + 0) * width);
				indices[(x + y * (width - 1)) * 6 + 1] = ((x + 0) + (y + 1) * width);
				indices[(x + y * (width - 1)) * 6 + 2] = ((x + 1) + (y + 1) * width);
				indices[(x + y * (width - 1)) * 6 + 3] = ((x + 1) + (y + 1) * width);
				indices[(x + y * (width - 1)) * 6 + 4] = ((x + 1) + (y + 0) * width);
				indices[(x + y * (width - 1)) * 6 + 5] = ((x + 0) + (y + 0) * width);
			}
		}
		return loadModel3D(posa, texa, norma, indices, new KTexture(texture), name);
	}

	public static int loadCubemapi(String[] paths) {
		int id = glGenTextures();

		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_CUBE_MAP, id);

		for (int i = 0; i < paths.length; i++) {
			TextureData data = decodeTexture(paths[i]);
			glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_X + i, 0, GL_RGBA, data.getWidth(), data.getHeight(), 0, GL_RGBA,
					GL_UNSIGNED_BYTE, data.getBuffer());
		}

		glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		return id;
	}

	private static TextureData decodeTexture(String path) {
		int width = 0;
		int height = 0;
		ByteBuffer buffer = null;
		try {
			FileInputStream in = new FileInputStream(new File(path));
			de.matthiasmann.twl.utils.PNGDecoder decoder = new de.matthiasmann.twl.utils.PNGDecoder(in);
			width = decoder.getWidth();
			height = decoder.getHeight();
			buffer = ByteBuffer.allocateDirect(4 * width * height);
			decoder.decode(buffer, width * 4, Format.RGBA);
			buffer.flip();
			in.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Could not load texture: " + path);
			System.exit(1);
		}
		return new TextureData(buffer, width, height);
	}

	public static Model genSomeModel() {
		MeshBuilder mb = new MeshBuilder();
		for (int i = 0; i < 100; i++) {
			mb.append(
					new Vector3f((float) Math.random() * 10f, (float) Math.random() * 10f, (float) Math.random() * 10f),
					new Vector2f(), new Vector3f());
		}
		mb.build(BuildType.TRIANGLE_STRIP);
		return mb.toModel();
	}
}
