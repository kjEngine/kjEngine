package de.kjEngine.core.util;

import org.lwjgl.util.vector.Vector3f;

public class Axis {

	public static final Vector3f X = new Vector3f(1f, 0f, 0f), Y = new Vector3f(0f, 1f, 0f),
			Z = new Vector3f(0f, 0f, 1f);
}
