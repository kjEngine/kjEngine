package de.kjEngine.core.util;

public @interface Kj {
	
	String author();
	int version();
	String doc();
}
