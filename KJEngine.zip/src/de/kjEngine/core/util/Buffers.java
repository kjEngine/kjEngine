package de.kjEngine.core.util;

import java.nio.*;

import org.lwjgl.*;

public class Buffers {
	
	public static FloatBuffer newFloatBuffer(float[] data) {
		FloatBuffer result = BufferUtils.createFloatBuffer(data.length);
		result.put(data);
		result.flip();
		return result;
	}
	
	public static ByteBuffer newByteBuffer(byte[] data) {
		ByteBuffer result = BufferUtils.createByteBuffer(data.length);
		result.put(data);
		result.flip();
		return result;
	}
	
	public static IntBuffer newIntBuffer(int[] data) {
		IntBuffer result = BufferUtils.createIntBuffer(data.length);
		result.put(data);
		result.flip();
		return result;
	}
	
	public static LongBuffer newLongBuffer(long[] data) {
		LongBuffer result = BufferUtils.createLongBuffer(data.length);
		result.put(data);
		result.flip();
		return result;
	}
	
	public static DoubleBuffer newDoubleBuffer(double[] data) {
		DoubleBuffer result = BufferUtils.createDoubleBuffer(data.length);
		result.put(data);
		result.flip();
		return result;
	}
	
	public static ShortBuffer newShortBuffer(short[] data) {
		ShortBuffer result = BufferUtils.createShortBuffer(data.length);
		result.put(data);
		result.flip();
		return result;
	}
	
	public static CharBuffer newCharBuffer(char[] data) {
		CharBuffer result = BufferUtils.createCharBuffer(data.length);
		result.put(data);
		result.flip();
		return result;
	}
}
