package de.kjEngine.core.util;

import java.util.Random;

public class Noise {
	
	public final float AMPLITUDE;
	private Random random = new Random();
	private long seed;

	public Noise(float amplitude) {
		this(amplitude, (int) (Math.random() * 10000000.0));
	}
	
	public Noise(float amplitude, long seed) {
		AMPLITUDE = amplitude;
		this.seed = seed;
	}
	
	public float getNoise(float x, float y) {
		return getInterpolatedValue(x, y) * AMPLITUDE;
	}
	
	private float getInterpolatedValue(float x, float y) {
		int intX = (int) x;
		int intY = (int) y;
		float fracX = x - intX;
		float fracY = y - intY;
		
		float v1 = getSmoothValue(intX, intY);
		float v2 = getSmoothValue(intX + 1, intY);
		float v3 = getSmoothValue(intX, intY + 1);
		float v4 = getSmoothValue(intX + 1, intY + 1);
		float i1 = interpolate(v1, v2, fracX);
		float i2 = interpolate(v3, v4, fracX);
		return interpolate(i1, i2, fracY);
	}
	
	private float interpolate(float a, float b, float blend) {
		double tetha = blend * Math.PI;
		float f = (float) (1f - Math.cos(tetha)) * 0.5f;
		return a * (1f - f) + b * f;
	}
	
	private float getSmoothValue(int x, int y) {
		float corners = (getValue(x - 1, y - 1) + getValue(x + 1, y - 1) + getValue(x + 1, y + 1) + getValue(x - 1, y + 1)) / 16f;
		float sides = (getValue(x - 1, y) + getValue(x + 1, y) + getValue(x, y - 1) + getValue(x, y + 1)) / 8f;
		float center = getValue(x, y) / 4f;
		return corners + sides + center;
	}
	
	private float getValue(int x, int y) {
		random.setSeed(x * 99100 + y * 400370 + seed);
		return random.nextFloat();
	}
}
