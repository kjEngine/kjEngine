package de.kjEngine.core.util;

import org.newdawn.slick.opengl.*;

import de.kjEngine.core.api.TextureFeture;

public class KTexture {
	
	private int ID;
	private TextureFeture normalMap;
	
	public KTexture(Texture texture) {
		this(texture.getTextureID());
	}

	public KTexture(int ID) {
		this.ID = ID;
		normalMap = new TextureFeture(0, false);
	}

	public int getID() {
		return ID;
	}

	public KTexture setID(int iD) {
		ID = iD;
		return this;
	}

	/**
	 * @return the normalMap
	 */
	public TextureFeture getNormalMap() {
		return normalMap;
	}

	/**
	 * @param normalMap the normalMap to set
	 */
	public KTexture setNormalMap(TextureFeture normalMap) {
		this.normalMap = normalMap;
		return this;
	}
}
