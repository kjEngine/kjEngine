package de.kjEngine.core.sun;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.util.vector.Matrix4f;

import de.kjEngine.core.api.Cleanable;
import de.kjEngine.core.awt.DisplayManager;
import de.kjEngine.core.sun.lensFlare.Query;
import de.kjEngine.core.util.OpenGlUtils;

public class SunRenderer implements Cleanable {
	
	private SunShader shader;

	public SunRenderer() {
		shader = new SunShader();
	}
	
	public void render(Matrix4f vMat, Matrix4f pMat, Sun sun) {
		prepare(sun);
		loadUniforms(vMat, pMat, sun);
		doQuery(sun);
		render();
		sun.getQuery().end();
		end();
	}

	private void doQuery(Sun sun) {
		Query query = sun.getQuery();
		if (query.isResultReady()) {
			sun.setSamplesPassed(query.getResult());
		}
		if (!query.isInUse()) {
			query.start();
		}
	}

	private void prepare(Sun sun) {
		shader.enable();
		OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE0, sun.getTexture());
		OpenGlUtils.enableAdditiveBlending();
		OpenGlUtils.enableDepthTesting(true);
	}

	private void loadUniforms(Matrix4f vMat, Matrix4f pMat, Sun sun) {
		shader.vMat.loadMatrix(vMat);
		shader.pMat.loadMatrix(pMat);
		shader.pos.loadVec3(sun.getPos());
		shader.size.loadFloat(sun.getSize());
		shader.aspect.loadFloat(DisplayManager.getAspect());
	}

	private void render() {
		GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 6);
	}

	private void end() {
		shader.disable();
		OpenGlUtils.disableBlending();
	}

	@Override
	public void cleanUp() {
		shader.cleanUp();
	}
}
