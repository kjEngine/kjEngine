package de.kjEngine.core.sun;

import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL15;
import org.lwjgl.util.vector.Vector3f;

import de.kjEngine.core.api.Cleanable;
import de.kjEngine.core.awt.DisplayManager;
import de.kjEngine.core.sun.lensFlare.Query;

public class Sun implements Cleanable {

	private Vector3f pos;
	private int texture;
	private float size;
	private final Query query;
	private int samplesPassed = 0;
	private final int maxSamples;

	public Sun(Vector3f pos, int texture, float size) {
		setPos(pos);
		setTexture(texture);
		setSize(size);
		query = new Query(GL15.GL_SAMPLES_PASSED);
		maxSamples = (int) (((size * Display.getWidth() * 0.5f) / DisplayManager.getAspect())
				* (size * Display.getHeight() * 0.5f));
	}

	/**
	 * @return the pos
	 */
	public Vector3f getPos() {
		return pos;
	}

	/**
	 * @param pos
	 *            the pos to set
	 */
	public void setPos(Vector3f pos) {
		this.pos = pos;
	}

	/**
	 * @return the texture
	 */
	public int getTexture() {
		return texture;
	}

	/**
	 * @param texture
	 *            the texture to set
	 */
	public void setTexture(int texture) {
		this.texture = texture;
	}

	/**
	 * @return the size
	 */
	public float getSize() {
		return size;
	}

	/**
	 * @param size
	 *            the size to set
	 */
	public void setSize(float size) {
		this.size = size;
	}

	@Override
	public void cleanUp() {
		query.cleanUp();
	}

	/**
	 * @return the samplesPassed
	 */
	public int getSamplesPassed() {
		return samplesPassed;
	}

	/**
	 * @param samplesPassed
	 *            the samplesPassed to set
	 */
	public void setSamplesPassed(int samplesPassed) {
		this.samplesPassed = samplesPassed;
	}

	/**
	 * @return the query
	 */
	public Query getQuery() {
		return query;
	}

	/**
	 * @return the maxSamples
	 */
	public int getMaxSamples() {
		return maxSamples;
	}
}
