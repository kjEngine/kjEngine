package de.kjEngine.core.sun;

import de.kjEngine.core.api.Shader;
import de.kjEngine.core.uniforms.UniformFloat;
import de.kjEngine.core.uniforms.UniformMat4;
import de.kjEngine.core.uniforms.UniformVec3;

public class SunShader extends Shader {
	
	UniformMat4 vMat, pMat;
	UniformVec3 pos;
	UniformFloat size, aspect;

	public SunShader() {
		super("/de/kjEngine/core/sun/vertexShader.glsl", "/de/kjEngine/core/sun/fragmentShader.glsl");
	}

	@Override
	protected void loadUniformLocations() {
		vMat = new UniformMat4(id, "vMat");
		pMat = new UniformMat4(id, "pMat");
		pos = new UniformVec3(id, "pos");
		size = new UniformFloat(id, "size");
		aspect = new UniformFloat(id, "aspect");
	}
}
