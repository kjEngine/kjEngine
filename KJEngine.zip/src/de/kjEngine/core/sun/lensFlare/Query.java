package de.kjEngine.core.sun.lensFlare;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL15;

import de.kjEngine.core.api.Cleanable;

public class Query implements Cleanable {
	
	private final int id;
	private final int type;
	
	private boolean inUse = false;

	public Query(int type) {
		this.type = type;
		this.id = GL15.glGenQueries();
	}
	
	public void start() {
		GL15.glBeginQuery(type, id);
		inUse = true;
	}
	
	public void end() {
		GL15.glEndQuery(type);
	}
	
	/**
	 * @return the inUse
	 */
	public boolean isInUse() {
		return inUse;
	}

	public boolean isResultReady() {
		inUse = false;
		return GL15.glGetQueryObjecti(id, GL15.GL_QUERY_RESULT_AVAILABLE) == GL11.GL_TRUE;
	}
	
	public int getResult() {
		return GL15.glGetQueryObjecti(id, GL15.GL_QUERY_RESULT);
	}

	@Override
	public void cleanUp() {
		GL15.glDeleteQueries(id);
	}
}
