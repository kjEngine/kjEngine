package de.kjEngine.core.sun.lensFlare;

import org.lwjgl.util.vector.Vector2f;

public class FlareTexture {
	
	private final int texture;
	private final float scale;
	
	private Vector2f screenPos = new Vector2f();

	public FlareTexture(int texture, float scale){
		this.texture = texture;
		this.scale = scale * 2f;
	}
	
	public void setScreenPos(Vector2f newPos){
		this.screenPos.set(newPos);
	}
	
	public int getTexture() {
		return texture;
	}

	public float getScale() {
		return scale;
	}

	public Vector2f getScreenPos() {
		return screenPos;
	}
}
