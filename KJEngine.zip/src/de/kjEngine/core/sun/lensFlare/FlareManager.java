package de.kjEngine.core.sun.lensFlare;

import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;
import org.lwjgl.util.vector.Vector4f;

import de.kjEngine.core.api.Camera;
import de.kjEngine.core.awt.DisplayManager;
import de.kjEngine.core.awt.rendering.GuiRenderer;
import de.kjEngine.core.model.Rectangle;
import de.kjEngine.core.sun.Sun;

public class FlareManager {

	private static final Vector2f SCREEN_CENTER = new Vector2f();

	private final FlareTexture[] textures;
	private final float spacing;
	private Vector2f sunScreenPos;

	public FlareManager(float spacing, FlareTexture... textures) {
		this.spacing = spacing;
		this.textures = textures;
	}

	public void render(Camera cam, Matrix4f pMat, Vector3f sunWorldPos, GuiRenderer renderer, Sun sun) {
		Vector2f screenPos = calcScreenPos(cam, pMat, sunWorldPos);
		sunScreenPos = screenPos;
		if (screenPos == null || screenPos.x < -1 || screenPos.x > 1 || screenPos.y < -1 || screenPos.y > 1) {
			return;
		}
		Vector2f sunToCenter = Vector2f.sub(SCREEN_CENTER, screenPos, null);
		float brightness = Math.min(1f - (sunToCenter.length() / 0.9f),
				((float) sun.getSamplesPassed()) / (float) sun.getMaxSamples());
		if (brightness > 0) {
			calcFlarePositions(sunToCenter, screenPos);
			float oda = 1f / DisplayManager.getAspect();
			for (FlareTexture t : textures) {
				float width = t.getScale() * oda;
				float height = t.getScale();
				renderer.renderImageWithAdditiveBlending(t.getScreenPos().x - width * 0.5f,
						t.getScreenPos().y - height * 0.5f, width, height, t.getTexture(),
						new Rectangle(-1f, -1f, 2f, 2f), brightness);
			}
		}
	}

	private void calcFlarePositions(Vector2f sunToCenter, Vector2f screenPos) {
		for (int i = 0; i < textures.length; i++) {
			Vector2f dir = new Vector2f(sunToCenter);
			dir.scale(i * spacing);
			Vector2f flarePos = Vector2f.add(screenPos, dir, null);
			textures[i].setScreenPos(flarePos);
		}
	}

	private Vector2f calcScreenPos(Camera cam, Matrix4f pMat, Vector3f sunWorldPos) {
		Vector4f coords = new Vector4f(sunWorldPos.x, sunWorldPos.y, sunWorldPos.z, 1f);
		Matrix4f.transform(cam.getLocation(), coords, coords);
		Matrix4f.transform(pMat, coords, coords);
		if (coords.w <= 0) {
			return null;
		}
		float x = coords.x / coords.w;
		float y = coords.y / coords.w;
		return new Vector2f(x, y);
	}

	/**
	 * @return the sunScreenPos
	 */
	public Vector2f getSunScreenPos() {
		return sunScreenPos;
	}
}
