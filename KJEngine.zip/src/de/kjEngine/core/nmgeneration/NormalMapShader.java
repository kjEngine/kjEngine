package de.kjEngine.core.nmgeneration;

import de.kjEngine.core.api.Shader;
import de.kjEngine.core.uniforms.UniformFloat;
import de.kjEngine.core.uniforms.UniformInt;

public class NormalMapShader extends Shader {
	
	public UniformInt N;
	public UniformFloat strength;
	
	public NormalMapShader() {
		super("/de/kjEngine/core/nmgeneration/computeShader.glsl");
	}

	@Override
	protected void loadUniformLocations() {
		N = new UniformInt(id, "N");
		strength = new UniformFloat(id, "strength");
	}
}
