package de.kjEngine.core.nmgeneration;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GL42;
import org.lwjgl.opengl.GL43;

import de.kjEngine.core.api.Cleanable;
import de.kjEngine.core.util.OpenGlUtils;

public class NormalMapRenderer implements Cleanable {
	
	private NormalMapShader shader;

	public NormalMapRenderer() {
		shader = new NormalMapShader();
	}
	
	public void render(int target, int src, int N, float strength) {
		shader.enable();
		shader.N.loadInt(N);
		shader.strength.loadFloat(strength);
		OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE1, src);
		GL42.glBindImageTexture(0, target, 0, false, 0, GL15.GL_WRITE_ONLY, GL30.GL_RGBA32F);
		GL43.glDispatchCompute(N / 16, N / 16, 1);
		GL11.glFinish();
		shader.disable();
	}

	@Override
	public void cleanUp() {
		shader.cleanUp();
	}
}
