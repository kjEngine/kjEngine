package de.kjEngine.core.api;

public interface Cleanable {

	void cleanUp();
}
