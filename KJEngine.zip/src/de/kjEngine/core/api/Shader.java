package de.kjEngine.core.api;

import static org.lwjgl.opengl.GL11.GL_FALSE;
import static org.lwjgl.opengl.GL20.GL_COMPILE_STATUS;
import static org.lwjgl.opengl.GL20.GL_FRAGMENT_SHADER;
import static org.lwjgl.opengl.GL20.GL_LINK_STATUS;
import static org.lwjgl.opengl.GL20.GL_VERTEX_SHADER;
import static org.lwjgl.opengl.GL20.glAttachShader;
import static org.lwjgl.opengl.GL20.glCompileShader;
import static org.lwjgl.opengl.GL20.glCreateProgram;
import static org.lwjgl.opengl.GL20.glCreateShader;
import static org.lwjgl.opengl.GL20.glDeleteProgram;
import static org.lwjgl.opengl.GL20.glDeleteShader;
import static org.lwjgl.opengl.GL20.glGetProgramInfoLog;
import static org.lwjgl.opengl.GL20.glGetProgrami;
import static org.lwjgl.opengl.GL20.glGetShaderInfoLog;
import static org.lwjgl.opengl.GL20.glGetShaderi;
import static org.lwjgl.opengl.GL20.glLinkProgram;
import static org.lwjgl.opengl.GL20.glShaderSource;
import static org.lwjgl.opengl.GL20.glUniform1f;
import static org.lwjgl.opengl.GL20.glUniform1i;
import static org.lwjgl.opengl.GL20.glUniform2f;
import static org.lwjgl.opengl.GL20.glUniform3f;
import static org.lwjgl.opengl.GL20.glUniform4f;
import static org.lwjgl.opengl.GL20.glUniformMatrix4;
import static org.lwjgl.opengl.GL20.glUseProgram;

import java.nio.FloatBuffer;

import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL32;
import org.lwjgl.opengl.GL40;
import org.lwjgl.opengl.GL43;
import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;
import org.lwjgl.util.vector.Vector4f;

import de.kjEngine.core.glslextension.PreCompiler;
import de.kjEngine.core.util.Loader;

public abstract class Shader implements Cleanable {

	protected int id;

	public Shader(String compFile) {
		id = loadShaders(compFile);
		loadUniformLocations();
	}

	private int loadShaders(String compFile) {
		int program = glCreateProgram();
		int compShader = loadShader(compFile, GL43.GL_COMPUTE_SHADER);
		glAttachShader(program, compShader);
		glLinkProgram(program);
		glDeleteShader(compShader);
		return program;
	}

	public Shader(String vFile, String fFile) {
		id = loadShaders(vFile, fFile, null, null, null);
		loadUniformLocations();
	}

	public Shader(String vFile, String fFile, String tesscFile, String tesseFile) {
		id = loadShaders(vFile, fFile, tesscFile, tesseFile, null);
		loadUniformLocations();
	}

	public Shader(String vFile, String fFile, String tesscFile, String tesseFile, String geomFile) {
		id = loadShaders(vFile, fFile, tesscFile, tesseFile, geomFile);
		loadUniformLocations();
	}

	private int loadShaders(String vFile, String fFile, String tesscFile, String tesseFile, String geomFile) {
		int program = glCreateProgram();

		int vShader = loadShader(vFile, GL_VERTEX_SHADER);
		int fShader = loadShader(fFile, GL_FRAGMENT_SHADER);

		int tesscshader = 0;
		int tesseshader = 0;

		int geomshader = 0;

		if (tesscFile != null && tesseFile != null) {
			tesscshader = loadShader(tesscFile, GL40.GL_TESS_CONTROL_SHADER);
			tesseshader = loadShader(tesseFile, GL40.GL_TESS_EVALUATION_SHADER);
		}

		if (geomFile != null) {
			geomshader = loadShader(geomFile, GL32.GL_GEOMETRY_SHADER);
		}

		glAttachShader(program, vShader);

		if (tesscFile != null && tesseFile != null) {
			glAttachShader(program, tesscshader);
			glAttachShader(program, tesseshader);
		}

		if (geomFile != null) {
			glAttachShader(program, geomshader);
		}

		glAttachShader(program, fShader);

		glLinkProgram(program);

		if (glGetProgrami(program, GL_LINK_STATUS) == GL_FALSE) {
			System.out.println("programm (vs=" + vFile + "):");
			System.out.println(glGetProgramInfoLog(program, 1000));
		}

		glDeleteShader(vShader);
		if (tesscFile != null && tesseFile != null) {
			glDeleteShader(tesscshader);
			glDeleteShader(tesseshader);
		}
		if (geomFile != null) {
			glDeleteShader(geomshader);
		}
		glDeleteShader(fShader);

		return program;
	}

	private int loadShader(String file, int type) {
		String src = PreCompiler.compile(Loader.loadFile(file));

		int shader = glCreateShader(type);
		glShaderSource(shader, src);
		glCompileShader(shader);

		if (glGetShaderi(shader, GL_COMPILE_STATUS) == GL_FALSE) {
			System.err.println(file + ":");
			System.err.println(glGetShaderInfoLog(shader, 500));
			return 0;
		}
		return shader;
	}

	public void enable() {
		glUseProgram(id);
	}

	public void disable() {
		glUseProgram(0);
	}

	protected void loadMatrix(int location, Matrix4f mat) {
		FloatBuffer buf = BufferUtils.createFloatBuffer(16);
		mat.store(buf);
		buf.flip();
		glUniformMatrix4(location, false, buf);
	}

	protected void loadFloat(int location, float f) {
		glUniform1f(location, f);
	}

	protected void loadInt(int location, int i) {
		glUniform1i(location, i);
	}

	protected void loadVector(int location, Vector2f v) {
		glUniform2f(location, v.x, v.y);
	}

	protected void loadVector(int location, Vector3f v) {
		glUniform3f(location, v.x, v.y, v.z);
	}

	protected void loadVector(int location, Vector4f v) {
		glUniform4f(location, v.x, v.y, v.z, v.w);
	}

	protected abstract void loadUniformLocations();

	@Override
	public void cleanUp() {
		glDeleteProgram(id);
	}
}
