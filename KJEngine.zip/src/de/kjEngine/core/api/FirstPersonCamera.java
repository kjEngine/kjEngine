package de.kjEngine.core.api;

import org.lwjgl.input.*;
import org.lwjgl.util.vector.*;

import de.kjEngine.core.awt.DisplayManager;
import de.kjEngine.core.util.Axis;

public class FirstPersonCamera extends Camera {
	
	private final float hSpeed = 2f, rSpeed = 2f, ySpeed = hSpeed;

	public FirstPersonCamera() {
	}

	@Override
	public void update() {
		float delta = DisplayManager.getDelta();
		
		if(Keyboard.isKeyDown(Keyboard.KEY_W)) move(hSpeed * delta, 0f);
		if(Keyboard.isKeyDown(Keyboard.KEY_S)) move(-hSpeed * delta, 0f);
		
		if(Keyboard.isKeyDown(Keyboard.KEY_A)) {
			rotY -= Math.PI * 0.5;
			move(hSpeed * delta, 0f);
			rotY += Math.PI * 0.5;
		}
		if(Keyboard.isKeyDown(Keyboard.KEY_D)) {
			rotY += Math.PI * 0.5;
			move(hSpeed * delta, 0f);
			rotY -= Math.PI * 0.5;
		}
		
		if(Keyboard.isKeyDown(Keyboard.KEY_SPACE)) move(0f, -ySpeed * delta);
		if(Keyboard.isKeyDown(Keyboard.KEY_C)) move(0f, ySpeed * delta);
		
		if(Keyboard.isKeyDown(Keyboard.KEY_UP)) rotX += rSpeed * delta;
		if(Keyboard.isKeyDown(Keyboard.KEY_DOWN)) rotX -= rSpeed * delta;
		if(Keyboard.isKeyDown(Keyboard.KEY_LEFT)) rotY -= rSpeed * delta;
		if(Keyboard.isKeyDown(Keyboard.KEY_RIGHT)) rotY += rSpeed * delta;
	}
	
	private void move(float hs, float ys) {
		pos.y += ys;
		pos.x += hs * Math.sin(-rotY);
		pos.z += hs * Math.cos(-rotY);
	}

	@Override
	public Matrix4f getLocation() {
		Matrix4f result = Matrix4f.setIdentity(new Matrix4f());
		result.rotate(rotX, Axis.X);
		result.rotate(rotY, Axis.Y);
		result.translate(pos);
		return result;
	}
}
