package de.kjEngine.core.api;

import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector3f;

import de.kjEngine.core.audio.Source;
import de.kjEngine.core.model.Model;

public class Entity {
	
	protected Transform transform = new Transform();
	protected Model[] models;
	private Script skript;
	protected Source sound;
	protected boolean highlighted;
	protected Vector3f highlightColor;
	protected float highlightStrength;
	protected boolean dynamic;

	public Entity() {
		this(new Vector3f(), 0f, 0f, 0f, new Vector3f(1f, 1f, 1f));
	}

	public Entity(Vector3f position, float rotX, float rotY, float rotZ, Vector3f scale, Model... models) {
		transform.setTranslation(position);
		transform.setRotation(new Vector3f(rotX, rotY, rotZ));
		transform.setScale(scale);
		this.models = models;
	}

	public Model[] getModels() {
		return models;
	}

	public void setModels(Model... models) {
		this.models = models;
	}

	/**
	 * @return the transform
	 */
	public Transform getTransform() {
		return transform;
	}

	/**
	 * @param transform the transform to set
	 */
	public void setTransform(Transform transform) {
		this.transform = transform;
	}
	
	public Matrix4f getLocation() {
		return transform.getMatrix();
	}

	/**
	 * @return the skript
	 */
	public Script getSkript() {
		return skript;
	}

	/**
	 * @param skript the skript to set
	 */
	public void setSkript(Script skript) {
		this.skript = skript;
		skript.start();
	}

	public Source getSound() {
		return sound;
	}

	public void setSound(Source sound) {
		this.sound = sound;
	}

	public boolean isHighlighted() {
		return highlighted;
	}

	public void setHighlighted(boolean highlighted) {
		this.highlighted = highlighted;
	}

	public Vector3f getHighlightColor() {
		return highlightColor;
	}

	public void setHighlightColor(Vector3f highlightColor) {
		this.highlightColor = highlightColor;
	}

	public float getHighlightStrength() {
		return highlightStrength;
	}

	public void setHighlightStrength(float highlightStrength) {
		this.highlightStrength = highlightStrength;
	}

	public boolean isDynamic() {
		return dynamic;
	}

	public void setDynamic(boolean dynamic) {
		this.dynamic = dynamic;
	}
}
