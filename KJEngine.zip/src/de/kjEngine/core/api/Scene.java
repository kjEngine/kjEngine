package de.kjEngine.core.api;

import java.util.*;

public class Scene {
	
	private float gravity, airresistance;
	private List<Entity> entitys = new ArrayList<>();
	private Camera cam;
	private float cys;

	public Scene(Camera cam) {
		this.cam = cam;
	}
	
	public void update() {
		cys += gravity;
		cys *= airresistance;
		cam.getPos().y += cys;
	}

	public float getGravity() {
		return gravity;
	}

	public void setGravity(float gravity) {
		this.gravity = gravity;
	}

	public float getAirresistance() {
		return airresistance;
	}

	public void setAirresistance(float airresistance) {
		this.airresistance = airresistance;
	}

	public List<Entity> getEntitys() {
		return entitys;
	}

	public void setEntitys(List<Entity> entitys) {
		this.entitys = entitys;
	}
}
