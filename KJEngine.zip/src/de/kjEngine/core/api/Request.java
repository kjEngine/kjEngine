package de.kjEngine.core.api;

public interface Request {

	void handle();
}
