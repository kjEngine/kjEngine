package de.kjEngine.core.api;

import java.util.LinkedList;
import java.util.Queue;

public class RequestList {
	
	private Queue<Request> requests = new LinkedList<>();

	public RequestList() {
	}
	
	public void add(Request e) {
		requests.offer(e);
	}
	
	public void handle() {
		while (!requests.isEmpty()) {
			Request r = requests.poll();
			if (r != null) {
				r.handle();
			}
		}
	}
}
