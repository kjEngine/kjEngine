package de.kjEngine.core.api;

import java.io.PrintStream;

public class Debug {
	
	private static boolean debug = true;
	private static PrintStream output = null;
	
	public static void log(Exception e) {
		PrintStream out;
		if (output == null) {
			out = System.err;
		} else {
			out = output;
		}
		e.printStackTrace(out);
	}
	
	public static void log(String e) {
		PrintStream out;
		if (output == null) {
			out = System.out;
		} else {
			out = output;
		}
		out.println(e);
	}

	/**
	 * @return the debug
	 */
	public static boolean isDebug() {
		return debug;
	}

	/**
	 * @param debug the debug to set
	 */
	public static void setDebug(boolean debug) {
		Debug.debug = debug;
	}

	/**
	 * @return the output
	 */
	public static PrintStream getOutput() {
		return output;
	}

	/**
	 * @param output the output to set
	 */
	public static void setOutput(PrintStream output) {
		Debug.output = output;
	}
}
