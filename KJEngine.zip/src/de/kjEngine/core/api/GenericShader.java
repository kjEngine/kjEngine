package de.kjEngine.core.api;

import java.util.HashMap;
import java.util.Map;

import org.lwjgl.opengl.GL20;
import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;
import org.lwjgl.util.vector.Vector4f;

public class GenericShader extends Shader {

	private Map<String, Integer> uniforms = new HashMap<>();

	public GenericShader(String compFile) {
		super(compFile);
	}

	public GenericShader(String vFile, String fFile) {
		super(vFile, fFile);
	}

	public GenericShader(String vFile, String fFile, String tesscFile, String tesseFile) {
		super(vFile, fFile, tesscFile, tesseFile);
	}

	public GenericShader(String vFile, String fFile, String tesscFile, String tesseFile, String geomFile) {
		super(vFile, fFile, tesscFile, tesseFile, geomFile);
	}

	@Override
	protected void loadUniformLocations() {
	}

	private int getUniform(String name) {
		if (!uniforms.containsKey(name)) {
			int uniform = GL20.glGetUniformLocation(id, name);
			if (uniform == -1) {
				System.err.println("Could not find uniform: " + name);
				return -1;
			}
			uniforms.put(name, uniform);
		}
		return uniforms.get(name);
	}

	public void set(String name, int i0) {
		GL20.glUniform1i(getUniform(name), i0);
	}

	public void set(String name, int i0, int i1) {
		GL20.glUniform2i(getUniform(name), i0, i1);
	}

	public void set(String name, int i0, int i1, int i2) {
		GL20.glUniform3i(getUniform(name), i0, i1, i2);
	}

	public void set(String name, int i0, int i1, int i2, int i3) {
		GL20.glUniform4i(getUniform(name), i0, i1, i2, i3);
	}

	public void set(String name, float i0) {
		GL20.glUniform1f(getUniform(name), i0);
	}

	public void set(String name, float i0, float i1) {
		GL20.glUniform2f(getUniform(name), i0, i1);
	}

	public void set(String name, float i0, float i1, float i2) {
		GL20.glUniform3f(getUniform(name), i0, i1, i2);
	}

	public void set(String name, float i0, float i1, float i2, float i3) {
		GL20.glUniform4f(getUniform(name), i0, i1, i2, i3);
	}

	public void set(String name, Vector2f v) {
		GL20.glUniform2f(getUniform(name), v.x, v.y);
	}

	public void set(String name, Vector3f v) {
		GL20.glUniform3f(getUniform(name), v.x, v.y, v.z);
	}

	public void set(String name, Vector4f v) {
		GL20.glUniform4f(getUniform(name), v.x, v.y, v.z, v.w);
	}

	public void set(String name, Matrix4f m) {
		super.loadMatrix(getUniform(name), m);
	}
}
