package de.kjEngine.core.api;

import org.lwjgl.util.vector.*;

public class FogData {
	
	private float minFog, maxFog;
	private Vector4f fogColor;

	public FogData() {
		fogColor = new Vector4f();
	}

	public FogData(float minFog, float maxFog, Vector4f fogColor) {
		this.minFog = minFog;
		this.maxFog = maxFog;
		this.fogColor = fogColor;
	}

	public float getMinFog() {
		return minFog;
	}

	public void setMinFog(float minFog) {
		this.minFog = minFog;
	}

	public float getMaxFog() {
		return maxFog;
	}

	public void setMaxFog(float maxFog) {
		this.maxFog = maxFog;
	}

	public Vector4f getFogColor() {
		return fogColor;
	}

	public void setFogColor(Vector4f fogColor) {
		this.fogColor = fogColor;
	}
}
