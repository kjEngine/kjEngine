package de.kjEngine.core.api;

public interface GameMethods {
	
	void update();
	void render();
}
