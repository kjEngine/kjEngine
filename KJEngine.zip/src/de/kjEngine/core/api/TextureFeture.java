package de.kjEngine.core.api;

public class TextureFeture {

	private boolean enabled = false;
	private int id;

	public TextureFeture(int id, boolean enabled) {
		setId(id);
		setEnabled(enabled);
	}

	/**
	 * @return the enabled
	 */
	public boolean isEnabled() {
		return enabled;
	}

	/**
	 * @param enabled
	 *            the enabled to set
	 */
	public TextureFeture setEnabled(boolean enabled) {
		this.enabled = enabled;
		return this;
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public TextureFeture setId(int id) {
		this.id = id;
		return this;
	}

	public TextureFeture enable() {
		enabled = true;
		return this;
	}

	public TextureFeture disable() {
		enabled = false;
		return this;
	}
}
