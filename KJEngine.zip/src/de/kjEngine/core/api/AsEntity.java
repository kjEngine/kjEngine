package de.kjEngine.core.api;

public interface AsEntity {
	
	Entity getEntity();
}
