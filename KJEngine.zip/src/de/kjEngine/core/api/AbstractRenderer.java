package de.kjEngine.core.api;

public abstract class AbstractRenderer<T> implements Cleanable {
	
	protected Shader shader;

	public AbstractRenderer(Shader shader) {
		this.shader = shader;
	}
	
	public final void render(T e) {
		shader.enable();
		prepare(e);
		doRender(e);
		end(e);
		shader.disable();
	}

	protected abstract void prepare(T e);
	protected abstract void doRender(T e);
	protected abstract void end(T e);

	@Override
	public void cleanUp() {
		shader.cleanUp();
	}
}
