package de.kjEngine.core.api;

public interface Stoppable {
	
	void stop();
}
