package de.kjEngine.core.api;

public class TimingVerifier {
	
	private int delay;
	private long lastTime;

	public TimingVerifier(int delay) {
		setDelay(delay);
	}

	public int getDelay() {
		return delay;
	}

	public void setDelay(int delay) {
		this.delay = delay;
	}
	
	public void time(Runnable r) {
		if (time()) {
			r.run();
		}
	}
	
	public long getLastTimeToNow() {
		return System.currentTimeMillis() - lastTime;
	}
	
	public long getTimeToGo() {
		return delay - getLastTimeToNow();
	}
	
	public float getProgress() {
		return (float) getLastTimeToNow() / (float) delay;
	}
	
	public void reset() {
		lastTime = System.currentTimeMillis();
	}
	
	public boolean time() {
		if (getTimeToGo() < 0) {
			reset();
			return true;
		}
		return false;
	}
}
