package de.kjEngine.core.api;

import org.lwjgl.util.vector.*;

import de.kjEngine.core.water.*;

public abstract class Camera {
	
	protected Vector3f pos;
	protected float rotX, rotY;
	protected boolean reflection_pass = false;;
	
	protected Camera() {
		pos = new Vector3f();
	}
	
	public abstract void update();
	
	public abstract Matrix4f getLocation();
	
	public float getRotX() {
		return rotX;
	}
	
	public void setRotX(float rotX) {
		this.rotX = rotX;
	}
	
	public float getRotY() {
		return rotY;
	}
	
	public void setRotY(float rotY) {
		this.rotY = rotY;
	}
	
	public void setPos(Vector3f pos) {
		this.pos = pos;
	}
	
	public Vector3f getPos() {
		return pos;
	}
	
	public void prepareForReflectionPass(Water water) {
		float yd = water.getPos().y + getPos().y;
		getPos().y -= yd * 2f;
		setRotX(getRotX() * -1f);
		reflection_pass = true;
	}
	
	public void endReflectionPass(Water water) {
		float yd = water.getPos().y + getPos().y;
		getPos().y -= yd * 2f;
		setRotX(getRotX() * -1f);
		reflection_pass = false;
	}
}
