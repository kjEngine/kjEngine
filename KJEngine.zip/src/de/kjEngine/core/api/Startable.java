package de.kjEngine.core.api;

public interface Startable {
	
	void start();
}
