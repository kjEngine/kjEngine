package de.kjEngine.core.api;

import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector3f;

import de.kjEngine.core.util.Axis;

public class Transform {
	
	private Vector3f translation, rotation, scale;

	public Transform() {
		setTranslation(new Vector3f());
		setRotation(new Vector3f());
		setScale(new Vector3f(1f, 1f, 1f));
	}
	
	public Matrix4f getMatrix() {
		Matrix4f t = Matrix4f.setIdentity(new Matrix4f());
		t.translate(translation);
		Matrix4f r = Matrix4f.setIdentity(new Matrix4f());
		r.rotate(rotation.x, Axis.X);
		r.rotate(rotation.y, Axis.Y);
		r.rotate(rotation.z, Axis.Z);
		Matrix4f s = Matrix4f.setIdentity(new Matrix4f());
		s.scale(scale);
		return Matrix4f.mul(t, Matrix4f.mul(s, r, null), null);
	}

	/**
	 * @return the translation
	 */
	public Vector3f getTranslation() {
		return translation;
	}

	/**
	 * @param translation the translation to set
	 */
	public void setTranslation(Vector3f translation) {
		this.translation = translation;
	}

	/**
	 * @return the rotation
	 */
	public Vector3f getRotation() {
		return rotation;
	}

	/**
	 * @param rotation the rotation to set
	 */
	public void setRotation(Vector3f rotation) {
		this.rotation = rotation;
	}

	/**
	 * @return the scale
	 */
	public Vector3f getScale() {
		return scale;
	}

	/**
	 * @param scale the scale to set
	 */
	public void setScale(Vector3f scale) {
		this.scale = scale;
	}
	
	public void translate(Vector3f v) {
		Vector3f.add(translation, v, translation);
	}
	
	public void rotate(Vector3f v) {
		Vector3f.add(rotation, v, rotation);
	}
	
	public void scale(Vector3f s) {
		scale.x *= s.x;
		scale.y *= s.y;
		scale.z *= s.z;
	}

	@Override
	public String toString() {
		return "Transform [translation=" + translation + ", rotation=" + rotation + ", scale=" + scale + "]";
	}
}
