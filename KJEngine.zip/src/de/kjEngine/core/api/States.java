package de.kjEngine.core.api;

public interface States {
	
	void init();
	void action();
	void dispose();
}
