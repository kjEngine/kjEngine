package de.kjEngine.core.api;

import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector4f;

import de.kjEngine.core.awt.DisplayManager;
import de.kjEngine.core.awt.font.GUIText;
import de.kjEngine.core.awt.font.Text;
import de.kjEngine.core.awt.rendering.GuiRenderer;
import de.kjEngine.core.model.Rectangle;
import de.kjEngine.core.util.KJEngineException;
import de.kjEngine.core.util.Loader;

public class PGraphicsGLImpl extends PGraphics {
	
	private Rectangle clip = new Rectangle(-1f, -1f, 2f, 2f);

	public PGraphicsGLImpl() {
	}

	public PGraphicsGLImpl(GuiRenderer renderer) {
		super(renderer);
	}

	@Override
	public void size(int width, int height) {
		try {
			DisplayManager.create(width, height, "", false, false);
		} catch (KJEngineException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void background(int grayScale) {
		background(grayScale, 255);
	}

	@Override
	public void background(int grayScale, int alpha) {
		background(grayScale, grayScale, grayScale, alpha);
	}

	@Override
	public void background(int r, int g, int b) {
		background(r, g, b, 255);
	}

	@Override
	public void background(int r, int g, int b, int a) {
		renderer.renderImage(-1f, -1f, 2f, 2f,
				Loader.loadColorToTexture(new Vector4f(r / 255f, g / 255f, b / 255f, a / 255f)),
				new Rectangle(-1f, -1f, 2f, 2f), 1f);
	}

	@Override
	public void rect(float x, float y, float width, float height) {
		renderer.renderImage(x, y, width, height, fillID, new Rectangle(-1f, -1f, 2f, 2f), 1f);
	}

	@Override
	public void point(float x, float y) {
	}

	@Override
	public void ellipse(float x, float y, float r) {
	}

	@Override
	public void ellipse(float x, float y, float width, float height) {
	}

	@Override
	public void image(int image, float x, float y) {
	}

	@Override
	public void image(int image, float x, float y, float width, float height) {
	}

	@Override
	public void line(float sx, float sy, float ex, float ey) {
		renderer.drawLine(sx, sy, ex, ey, strokeID, matrixStack.peek());
	}

	@Override
	public void text(float x, float y, String text) {
		Text txt = new Text(font, new GUIText(text, textSize, font, new Vector2f(x, y), 2f, false, false));
		txt.getText().setColour(stroke.getRed() / 255f, stroke.getGreen() / 255f, stroke.getBlue() / 255f);
		renderer.getFontRenderer().render(txt, clip, matrixStack.peek());
		txt.getText().cleanUp();
	}
}
