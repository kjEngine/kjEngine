package de.kjEngine.core.api;

public class ViewPortSetting {
	
	private float fovy, aspect, near, far;

	public ViewPortSetting(float fovy, float aspect, float near, float far) {
		this.fovy = fovy;
		this.aspect = aspect;
		this.near = near;
		this.far = far;
	}

	public float getFovy() {
		return fovy;
	}

	public void setFovy(float fovy) {
		this.fovy = fovy;
	}

	public float getAspect() {
		return aspect;
	}

	public void setAspect(float aspect) {
		this.aspect = aspect;
	}

	public float getNear() {
		return near;
	}

	public void setNear(float near) {
		this.near = near;
	}

	public float getFar() {
		return far;
	}

	public void setFar(float far) {
		this.far = far;
	}
}
