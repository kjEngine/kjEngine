package de.kjEngine.core.api;

public interface Triggerable {
	
	void enable();
	void disable();
}
