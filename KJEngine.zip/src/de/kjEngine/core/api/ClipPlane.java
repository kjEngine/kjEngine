package de.kjEngine.core.api;

import org.lwjgl.util.vector.*;

public class ClipPlane {
	
	private Vector4f plane;
	private boolean active;
	
	public ClipPlane(Vector4f plane, boolean active) {
		this.plane = plane;
		this.active = active;
	}

	public Vector4f getPlane() {
		return plane;
	}

	public void setPlane(Vector4f plane) {
		this.plane = plane;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}
}
