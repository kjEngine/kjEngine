package de.kjEngine.core.api;

import java.awt.Color;
import java.util.Stack;

import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;
import org.lwjgl.util.vector.Vector4f;

import de.kjEngine.core.awt.font.FontType;
import de.kjEngine.core.awt.rendering.GuiRenderer;
import de.kjEngine.core.util.Axis;
import de.kjEngine.core.util.Loader;

public abstract class PGraphics {

	protected GuiRenderer renderer;
	protected Color stroke = Color.BLACK;
	protected int strokeID;
	protected boolean useStroke = true;
	protected Color fill = Color.BLACK;
	protected int fillID;
	protected boolean useFill = true;
	protected Stack<Matrix4f> matrixStack = new Stack<>();
	protected float strokeWeight = 1f;
	protected float textSize;
	protected FontType font;

	public PGraphics() {
		init();
	}

	public PGraphics(GuiRenderer renderer) {
		setRenderer(renderer);
		init();
	}

	private void init() {
		matrixStack.push(Matrix4f.setIdentity(new Matrix4f()));
	}

	public abstract void size(int width, int height);

	public abstract void background(int grayScale);

	public abstract void background(int grayScale, int alpha);

	public abstract void background(int r, int g, int b);

	public abstract void background(int r, int g, int b, int a);

	public void stroke(int grayScale) {
		stroke(grayScale, grayScale, grayScale);
	}

	public void stroke(int grayScale, int alpha) {
		stroke(grayScale, grayScale, grayScale, alpha);
	}

	public void stroke(int r, int g, int b) {
		stroke(r, g, b, 255);
	}

	public void stroke(int r, int g, int b, int a) {
		stroke();
		stroke = new Color(r, g, b, a);
		strokeID = Loader.loadColorToTexture(new Vector4f(r / 255f, g / 255f, b / 255f, a / 255f));
	}

	public void stroke() {
		useStroke = true;
	}

	public void noStroke() {
		useStroke = false;
	}

	public void fill(int grayScale) {
		fill(grayScale, grayScale, grayScale);
	}

	public void fill(int grayScale, int alpha) {
		fill(grayScale, grayScale, grayScale, alpha);
	}

	public void fill(int r, int g, int b) {
		fill(r, g, b, 255);
	}

	public void fill(int r, int g, int b, int a) {
		fill();
		fill = new Color(r, g, b, a);
		fillID = Loader.loadColorToTexture(new Vector4f(r / 255f, g / 255f, b / 255f, a / 255f));
	}

	public void fill() {
		useFill = true;
	}

	public void noFill() {
		useFill = false;
	}

	public void translate(float x, float y) {
		matrixStack.peek().translate(new Vector2f(x, y));
	}

	public void rotateX(float a) {
		matrixStack.peek().rotate(a, Axis.X);
	}

	public void rotateY(float a) {
		matrixStack.peek().rotate(a, Axis.Y);
	}

	public void rotateZ(float a) {
		matrixStack.peek().rotate(a, Axis.Z);
	}

	public void scale(float xyz) {
		matrixStack.peek().scale(new Vector3f(xyz, xyz, xyz));
	}

	public void scale(float x, float y) {
		matrixStack.peek().scale(new Vector3f(x, y, 1f));
	}

	public void scale(float x, float y, float z) {
		matrixStack.peek().scale(new Vector3f(x, y, z));
	}

	public void pushMatrix() {
		Matrix4f prev = matrixStack.peek();
		matrixStack.push(new Matrix4f(prev));
	}

	public void popMatrix() {
		if (matrixStack.size() > 1)
			matrixStack.pop();
	}
	
	public abstract void line(float sx, float sy, float ex, float ey);

	public abstract void rect(float x, float y, float width, float height);

	public abstract void point(float x, float y);

	public abstract void ellipse(float x, float y, float r);

	public abstract void ellipse(float x, float y, float width, float height);

	public abstract void image(int image, float x, float y);

	public abstract void image(int image, float x, float y, float width, float height);

	public void strokeWeight(float weight) {
		if (weight < 0)
			throw new IllegalArgumentException("StrokeWeight cannot be less than 0!");
		strokeWeight = weight;
	}

	public void textSize(float size) {
		textSize = size;
	}

	public void font(FontType font) {
		if (font == null) {
			font = FontType.ARIAL;
		}
		this.font = font;
	}

	public abstract void text(float x, float y, String text);

	public GuiRenderer getRenderer() {
		return renderer;
	}

	public void setRenderer(GuiRenderer renderer) {
		if (renderer == null)
			throw new NullPointerException();
		this.renderer = renderer;
	}
}
