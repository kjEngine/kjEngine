package de.kjEngine.core.api;

import org.lwjgl.util.vector.Matrix4f;

public class Instances {
	
	public static final Matrix4f IDENTITY_MATRIX = Matrix4f.setIdentity(new Matrix4f());
}
