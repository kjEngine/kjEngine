package de.kjEngine.core.api;

import static org.lwjgl.opengl.GL20.*;

import java.nio.FloatBuffer;

import org.lwjgl.BufferUtils;

import de.kjEngine.core.util.Loader;

public class InstancedVbo {

	private int id;
	private final int maxElements;
	private final int elementSize;
	private final FloatBuffer buffer;
	private int start, end;

	public InstancedVbo(int maxElements, int elementSize) {
		this.maxElements = maxElements;
		this.elementSize = elementSize;
		buffer = BufferUtils.createFloatBuffer(maxElements * elementSize);
		id = Loader.createEmptyVbo(maxElements * elementSize);
	}

	public int attachAttribs(int vao, int start) {
		this.start = start;
		int currentSizeToGo = elementSize;
		while (currentSizeToGo > 0) {
			Loader.addInstanceAttribute(vao, id, start++, Math.min(currentSizeToGo, 4), elementSize,
					elementSize - currentSizeToGo);
			currentSizeToGo -= Math.min(currentSizeToGo, 4);
		}
		end = start;
		return start;
	}

	public void enable() {
		for (int i = start; i < end; i++) {
			glEnableVertexAttribArray(i);
		}
	}
	
	public void disable() {
		for (int i = start; i < end; i++) {
			glDisableVertexAttribArray(i);
		}
	}
	
	public void put(float[] data) {
		Loader.updateVbo(id, data, buffer);
	}

	public int getId() {
		return id;
	}

	public int getMaxElements() {
		return maxElements;
	}

	public int getElementSize() {
		return elementSize;
	}

	public FloatBuffer getBuffer() {
		return buffer;
	}

	public int getEnd() {
		return end;
	}
}
