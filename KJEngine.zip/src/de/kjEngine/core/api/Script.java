package de.kjEngine.core.api;

public abstract class Script {

	public Script() {
	}
	
	public abstract void start();
	
	public abstract void updete(float delta);
}
