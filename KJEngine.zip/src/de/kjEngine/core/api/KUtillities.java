package de.kjEngine.core.api;

public class KUtillities {
	
	private static RequestList requestList = new RequestList();
	
	public static void invokeNext(Request e) {
		requestList.add(e);
	}
	
	public static void invokeAll() {
		requestList.handle();
	}
}
