package de.kjEngine.core.api;

import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.io.OutputStream;

import javax.swing.JFrame;
import javax.swing.JTextArea;

public class Console {
	
	private static JFrame frame;
	private static JTextArea area;
	
	private static OutputStream out;
	
	public static void init(int width, int height, String title, boolean resizable) {
		frame = new JFrame(title);
		frame.setSize(width, height);
		frame.setResizable(resizable);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
		
		area = new JTextArea(1, 1);
		area.setFont(new Font("Arial", Font.BOLD, 10));
		area.setForeground(Color.WHITE);
		area.setBackground(Color.BLACK);
		area.setEditable(false);
		frame.setContentPane(area);
		
		out = new OutputStream() {
			
			@Override
			public void write(int b) throws IOException {
				area.append(String.valueOf((char) b));
			}
		};
	}

	/**
	 * @return the out
	 */
	public static OutputStream getOut() {
		return out;
	}
}
