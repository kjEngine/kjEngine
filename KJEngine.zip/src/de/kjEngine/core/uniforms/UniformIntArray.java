package de.kjEngine.core.uniforms;

public class UniformIntArray extends Uniform {
	
	private UniformInt[] array;

	public UniformIntArray(int program, String name, int size) {
		super(program, name);
		array = new UniformInt[size];
		for (int i = 0; i < size; i++) {
			array[i] = new UniformInt(program, name + "[" + i + "]");
		}
	}

	@Override
	protected void storeUniformLocation(int programID) {
	}
	
	public void loadIntArray(int[] data) {
		if (data.length > array.length) {
			throw new IllegalArgumentException("data.length > size");
		}
		for (int i = 0; i < data.length; i++) {
			array[i].loadInt(data[i]);
		}
	}
}
