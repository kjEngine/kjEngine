package de.kjEngine.core.uniforms;

public class UniformFloatArray extends Uniform {
	
	private UniformFloat[] array;

	public UniformFloatArray(int program, String name, int size) {
		super(program, name);
		array = new UniformFloat[size];
		for (int i = 0; i < size; i++) {
			array[i] = new UniformFloat(program, name + "[" + i + "]");
		}
	}

	@Override
	protected void storeUniformLocation(int programID) {
	}
	
	public void loadFloatArray(float[] data) {
		for (int i = 0; i < data.length; i++) {
			array[i].loadFloat(data[i]);
		}
	}
}
