package de.kjEngine.core.uniforms;

import org.lwjgl.util.vector.Matrix4f;

public class UniformMat4Array extends Uniform {

	private UniformMat4[] matrixUniforms;

	public UniformMat4Array(int id, String name, int size) {
		super(id, name);
		matrixUniforms = new UniformMat4[size];
		for (int i = 0; i < size; i++) {
			matrixUniforms[i] = new UniformMat4(id, name + "[" + i + "]");
		}
	}

	@Override
	protected void storeUniformLocation(int programID) {
	}

	public void loadMatrixArray(Matrix4f[] matrices) {
		for (int i = 0; i < matrices.length; i++) {
			matrixUniforms[i].loadMatrix(matrices[i]);
		}
	}
}
