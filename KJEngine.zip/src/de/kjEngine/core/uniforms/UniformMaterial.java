package de.kjEngine.core.uniforms;

import org.lwjgl.opengl.GL13;
import org.lwjgl.util.vector.Vector4f;

import de.kjEngine.core.light.Material;
import de.kjEngine.core.util.Loader;
import de.kjEngine.core.util.OpenGlUtils;

public class UniformMaterial extends Uniform {

	private UniformVec4 ambient;
	private UniformInt diffMap, specMap, shyMap, nrm;

	public UniformMaterial(int program, String name) {
		super(program, name);
	}

	@Override
	protected void storeUniformLocation(int programID) {
		ambient = new UniformVec4(programID, name + ".ambient");
		diffMap = new UniformInt(programID, name + ".diffMap");
		specMap = new UniformInt(programID, name + ".specMap");
		nrm = new UniformInt(programID, name + ".nrm");
		shyMap = new UniformInt(programID, name + ".shyMap");
	}

	public void loadMaterial(Material mat, int diff_sampler, int spec_sampler, int shy_sampler, int nrm_sampler) {
		ambient.loadVec4(mat.getAmbient());
		diffMap.loadInt(diff_sampler);
		specMap.loadInt(spec_sampler);
		shyMap.loadInt(shy_sampler);
		nrm.loadInt(nrm_sampler);
		OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE0 + diff_sampler, Loader.loadColorToTexture(mat.getDiffuse()));
		OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE0 + spec_sampler, Loader.loadColorToTexture(mat.getSpecular()));
		OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE0 + shy_sampler, Loader.loadColorToTexture(
				new Vector4f(mat.getShinyness(), mat.getShinyness(), mat.getShinyness(), mat.getShinyness())));
	}
	
	public void loadMaterial(de.kjEngine.core.light.advanced.Material mat, int diff_sampler, int spec_sampler, int shy_sampler, int nrm_sampler) {
		ambient.loadVec4(new Vector4f(0.1f, 0.1f, 0.1f, 1f));
		diffMap.loadInt(diff_sampler);
		specMap.loadInt(spec_sampler);
		shyMap.loadInt(shy_sampler);
		nrm.loadInt(nrm_sampler);
		OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE0 + diff_sampler, mat.getDiffusemap());
		OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE0 + spec_sampler, mat.getSpecularmap());
		OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE0 + shy_sampler, Loader.loadColorToTexture(
				new Vector4f(mat.getShininess(), mat.getShininess(), mat.getShininess(), mat.getShininess())));
	}
}
