package de.kjEngine.core.uniforms;

import org.lwjgl.opengl.GL20;

public class UniformInt extends Uniform {

	public UniformInt(int program, String name) {
		super(program, name);
	}
	
	public void loadInt(int i) {
		GL20.glUniform1i(super.getLocation(), i);
	}
}
