package de.kjEngine.core.uniforms;

import de.kjEngine.core.light.DirectionalLight;

public class UniformDirectionalLight extends Uniform {
	
	private UniformVec4 ambient, diffuse, specular;
	private UniformVec3 direction;

	public UniformDirectionalLight(int program, String name) {
		super(program, name);
	}

	@Override
	protected void storeUniformLocation(int programID) {
		ambient = new UniformVec4(programID, name + ".ambient");
		diffuse = new UniformVec4(programID, name + ".diffuse");
		specular = new UniformVec4(programID, name + ".specular");
		direction = new UniformVec3(programID, name + ".direction");
	}
	
	 public void loadLight(DirectionalLight light) {
		 ambient.loadVec4(light.getAmbient());
		 diffuse.loadVec4(light.getDiffuse());
		 specular.loadVec4(light.getSpecular());
		 direction.loadVec3(light.getDirection());
	 }
}
