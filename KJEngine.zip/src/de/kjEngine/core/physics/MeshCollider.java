package de.kjEngine.core.physics;

import de.kjEngine.core.api.Entity;
import de.kjEngine.core.model.Mesh;

public class MeshCollider extends Collider {
	
	protected Mesh mesh;

	public MeshCollider(Material material, Entity parent) {
		super(material, parent);
	}

	public Mesh getMesh() {
		return mesh;
	}

	public void setMesh(Mesh mesh) {
		if (mesh == null)
			throw new NullPointerException();
		this.mesh = mesh;
	}

	@Override
	public void update() {
	}

	@Override
	public boolean collidesWith(Collider e) {
		return false;
	}
}
