package de.kjEngine.core.physics;

public class Material {
	
	private float mass, bouncyness;

	public Material() {
	}

	public Material(float mass, float bouncyness) {
		this.mass = mass;
		this.bouncyness = bouncyness;
	}

	public float getMass() {
		return mass;
	}

	public void setMass(float mass) {
		this.mass = mass;
	}

	public float getBouncyness() {
		return bouncyness;
	}

	public void setBouncyness(float bouncyness) {
		this.bouncyness = bouncyness;
	}
}
