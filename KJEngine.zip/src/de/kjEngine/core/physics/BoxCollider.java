package de.kjEngine.core.physics;

import org.lwjgl.util.vector.Vector3f;

import de.kjEngine.core.api.Entity;

public class BoxCollider extends Collider {

	protected Vector3f dimension;

	public BoxCollider(Material material, Entity parent, Vector3f dimension) {
		super(material, parent);
		setDimension(dimension);
	}

	public Vector3f getDimension() {
		return dimension;
	}

	public void setDimension(Vector3f dimension) {
		if (dimension == null)
			throw new NullPointerException();
		this.dimension = dimension;
	}

	@Override
	public void update() {
	}

	@Override
	public boolean collidesWith(Collider e) {
		if (e instanceof SphereCollider) {

		} else if (e instanceof BoxCollider) {
			float tx = getParent().getTransform().getTranslation().x;
			float ty = getParent().getTransform().getTranslation().y;
			float tz = getParent().getTransform().getTranslation().z;

			float ox = e.getParent().getTransform().getTranslation().x;
			float oy = e.getParent().getTransform().getTranslation().y;
			float oz = e.getParent().getTransform().getTranslation().z;

			float tw = dimension.x;
			float th = dimension.y;
			float tl = dimension.z;

			BoxCollider c = (BoxCollider) e;

			float ow = c.dimension.x;
			float oh = c.dimension.y;
			float ol = c.dimension.z;

			return !(tx + tw > ox || tx > ox + ow || ty + th > oy || ty > oy + oh || tz + tl > oz
					|| tz > oz + ol);
		}
		return false;
	}
}
