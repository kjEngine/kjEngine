package de.kjEngine.core.physics;

import java.util.*;

import org.lwjgl.util.vector.*;

public class PhysicsWorld {

	private List<Collider> objects = new ArrayList<>();
	private float gravity;

	public PhysicsWorld(float gravity) {
		this.gravity = gravity;
	}

	public synchronized void update() {
		for (int i = 0; i < objects.size(); i++) {
			for (int ii = 0; ii < objects.size(); ii++) {
				if (i != ii) {
					if (objects.get(i).collidesWith(objects.get(ii))) {
						Vector3f diff = Vector3f.sub(objects.get(i).getParent().getTransform().getTranslation(),
								objects.get(ii).getParent().getTransform().getTranslation(), null);
						Vector3f vel = Vector3f.sub(objects.get(i).getVelocity(), objects.get(ii).getVelocity(), null);
						float speed = vel.length();
						Vector3f axis = Vector3f.cross(diff, vel, null);
						float cos = Vector3f.dot(vel, diff);
						float a = -(float) Math.acos(cos);
						Matrix4f mat = Matrix4f.setIdentity(new Matrix4f());
						mat.rotate(a, axis);
						Vector4f nvel = Matrix4f.transform(mat, new Vector4f(vel.x, vel.y, vel.z, 1f), null);
						objects.get(i).setVelocity(new Vector3f(nvel.x * speed, nvel.y * speed, nvel.z * speed));
					}
				}
			}
			objects.get(i).velocity.y -= gravity;
			objects.get(i).getParent().getTransform().setTranslation(Vector3f.add(
					objects.get(i).getParent().getTransform().getTranslation(), objects.get(i).getVelocity(), null));
			if (objects.get(i).getParent().getTransform().getTranslation().y < 0) {
				objects.get(i).getParent().getTransform().getTranslation().y = 0f;
				objects.get(i).velocity.y *= -objects.get(i).material.getBouncyness();
				objects.get(i).getParent().getTransform()
						.setTranslation(Vector3f.add(objects.get(i).getParent().getTransform().getTranslation(),
								objects.get(i).getVelocity(), null));
			}
		}
	}

	public List<Collider> getObjects() {
		return objects;
	}

	public void setObjects(List<Collider> objects) {
		this.objects = objects;
	}

	public float getGravity() {
		return gravity;
	}

	public void setGravity(float gravity) {
		this.gravity = gravity;
	}
}
