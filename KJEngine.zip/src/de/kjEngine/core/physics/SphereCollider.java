package de.kjEngine.core.physics;

import org.lwjgl.util.vector.Vector3f;

import de.kjEngine.core.api.Entity;
import de.kjEngine.core.math.Vector;

public class SphereCollider extends Collider {

	protected Vector r;

	public SphereCollider(Material material, Entity parent, Vector r) {
		super(material, parent);
		setR(r);
	}

	public Vector getR() {
		return r;
	}

	public void setR(Vector r) {
		this.r = r;
	}

	@Override
	public void update() {
	}

	@Override
	public boolean collidesWith(Collider e) {
		if (e instanceof SphereCollider) {
			SphereCollider c = (SphereCollider) e;
			Vector3f diff = Vector3f.sub(e.getParent().getTransform().getTranslation(),
					getParent().getTransform().getTranslation(), null);
			float d2 = diff.lengthSquared();
			Vector v = new Vector(r.v.length);
			v.set(r);
			v.add(c.r);
			if (d2 < v.lengthSqared()) {
				return true;
			}
		} else if (e instanceof BoxCollider) {

		} else if (e instanceof MeshCollider) {
			
		}
		return false;
	}
}
