package de.kjEngine.core.physics;

import org.lwjgl.util.vector.*;

import de.kjEngine.core.*;
import de.kjEngine.core.api.Entity;

public abstract class Collider {
	
	protected Material material;
	protected Entity parent;
	protected Vector3f velocity;

	public Collider(Material material, Entity parent) {
		this.material = material;
		this.parent = parent;
		velocity = new Vector3f();
	}
	
	public abstract void update();
	public abstract boolean collidesWith(Collider e);
	
	public Material getMaterial() {
		return material;
	}

	public void setMaterial(Material material) {
		this.material = material;
	}

	public Entity getParent() {
		return parent;
	}

	public void setParent(Entity parent) {
		this.parent = parent;
	}

	public Vector3f getVelocity() {
		return velocity;
	}

	public void setVelocity(Vector3f velocity) {
		this.velocity = velocity;
	}
}
