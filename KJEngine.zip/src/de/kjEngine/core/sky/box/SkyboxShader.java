package de.kjEngine.core.sky.box;

import static org.lwjgl.opengl.GL20.*;

import org.lwjgl.util.vector.*;

import de.kjEngine.core.*;
import de.kjEngine.core.api.Shader;

public class SkyboxShader extends Shader {

	private static final String VERTEX_FILE = "/de/kjEngine/core/sky/box/vertexShader.glsl";
	private static final String FRAGMENT_FILE = "/de/kjEngine/core/sky/box/fragmentShader.glsl";
	
	private int location_projectionMatrix;
	private int location_viewMatrix;
	
	public SkyboxShader() {
		super(VERTEX_FILE, FRAGMENT_FILE);
	}
	
	public void loadProjectionMatrix(Matrix4f matrix){
		loadMatrix(location_projectionMatrix, matrix);
	}

	public void loadViewMatrix(Matrix4f mat){
		loadMatrix(location_viewMatrix, mat);
	}
	
	@Override
	public void cleanUp() {		
		glDeleteProgram(id);
	}

	@Override
	protected void loadUniformLocations() {
		location_projectionMatrix = glGetUniformLocation(id, "pMat");
		location_viewMatrix = glGetUniformLocation(id, "vMat");
	}
}
