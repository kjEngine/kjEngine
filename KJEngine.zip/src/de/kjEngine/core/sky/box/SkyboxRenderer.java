package de.kjEngine.core.sky.box;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL13.*;

import org.lwjgl.util.vector.*;

import de.kjEngine.core.*;
import de.kjEngine.core.api.Cleanable;
import de.kjEngine.core.model.*;
import de.kjEngine.core.util.KTexture;
import de.kjEngine.core.util.Loader;

public class SkyboxRenderer implements Cleanable {
	
	private SkyboxShader shader;
	private Model cube;

	public SkyboxRenderer() {
		shader = new SkyboxShader();
		cube = Loader.loadModel(SkyBox.MESH, new KTexture(0), "sky");
	}
	
	public void render(SkyBox sky, Matrix4f vMat, Matrix4f pMat) {		
		shader.enable();
		shader.loadProjectionMatrix(pMat);
		shader.loadViewMatrix(vMat);
		
		cube.enable();
		
		glDisable(GL_DEPTH_TEST);
		glDisable(GL_CULL_FACE);
		
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_CUBE_MAP, sky.getTexture());
		
		glDrawElements(GL_TRIANGLES, cube.getIndexCount(), GL_UNSIGNED_INT, 0);
		
		glEnable(GL_CULL_FACE);
		glEnable(GL_DEPTH_TEST);
		
		cube.disable();
		shader.disable();
	}

	@Override
	public void cleanUp() {
		shader.cleanUp();
	}
}
