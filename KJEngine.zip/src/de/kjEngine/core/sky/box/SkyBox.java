package de.kjEngine.core.sky.box;

import de.kjEngine.core.model.*;

public class SkyBox {
	
	public static final Mesh MESH = new Mesh(new float[] {
			-1f, 1f, 1f, 
			-1f, -1f, 1f,
			1f, -1f, 1f,
			1f, 1f, 1f,
			
			-1f, 1f, -1f, 
			-1f, -1f, -1f,
			1f, -1f, -1f,
			1f, 1f, -1f
	}, new int[] {
			0, 1, 2, 2, 3, 0,
			7, 6, 5, 5, 4, 7,
			4, 5, 1, 1, 0, 4,
			3, 2, 6, 6, 7, 3,
			4, 0, 3, 3, 7, 4,
			1, 5, 6, 6, 2, 1
	}, new float[] {}, new float[] {});
	private int texture;

	public SkyBox(int texture) {
		this.texture = texture;
	}

	public int getTexture() {
		return texture;
	}

	public void setTexture(int texture) {
		this.texture = texture;
	}
}
