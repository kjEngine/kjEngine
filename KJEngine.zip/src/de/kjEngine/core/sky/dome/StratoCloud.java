package de.kjEngine.core.sky.dome;

public class StratoCloud {
	
	public float factor;
	public float height;

	public StratoCloud() {
		this(0.3f, 1.5f);
	}
	
	public StratoCloud(float factor, float height) {
		this.factor = factor;
		this.height = height;
	}
}
