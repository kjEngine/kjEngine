package de.kjEngine.core.sky.dome;

import org.lwjgl.util.vector.Vector3f;

import de.kjEngine.core.io.PropertiesFile;
import de.kjEngine.core.model.Model;
import de.kjEngine.core.util.KTexture;
import de.kjEngine.core.util.Loader;

public class SkyDome {
	
	public static SkyDome of(PropertiesFile file) {
		SkyDome result = new SkyDome();
		
		int baseColor = file.getInt("base_color");
		
		int r = (baseColor >> 16) & 0xff;
		int g = (baseColor >> 8) & 0xff;
		int b = (baseColor) & 0xff;
		
		result.setBaseColor(new Vector3f(r / 255f, g / 255f, b / 255f));
		
		float size = file.getFloat("size");
		result.setSize(size);
		
		float height = file.getFloat("strato_cloud_height");
		result.getStratoCloud().height = height;
		
		float factor = file.getFloat("strato_cloud_factor");
		result.getStratoCloud().factor = factor;
		
		return result;
	}
	
	private static final String MODEL_FILE = "/de/kjEngine/core/sky/dome/model.obj";
	public static final Model MODEL = Loader.loadRelativeObjModel(MODEL_FILE, new KTexture(0), "sky", SkyDome.class);
	
	private Vector3f baseColor;
	private float size;
	private StratoCloud stratoCloud;
	private NormalClouds normalClouds;

	public SkyDome() {
		this(new Vector3f(0.18f, 0.27f, 0.47f), 50f);
	}
	
	public SkyDome(Vector3f baseColor, float size) {
		setBaseColor(baseColor);
		setSize(size);
		stratoCloud = new StratoCloud();
		normalClouds = new NormalClouds();
	}
	
	public void update() {
		normalClouds.update();
	}

	/**
	 * @return the baseColor
	 */
	public Vector3f getBaseColor() {
		return baseColor;
	}

	/**
	 * @param baseColor the baseColor to set
	 */
	public void setBaseColor(Vector3f baseColor) {
		this.baseColor = baseColor;
	}

	/**
	 * @return the size
	 */
	public float getSize() {
		return size;
	}

	/**
	 * @param size the size to set
	 */
	public void setSize(float size) {
		this.size = size;
	}

	public StratoCloud getStratoCloud() {
		return stratoCloud;
	}

	public void setStratoCloud(StratoCloud stratoCloud) {
		if (stratoCloud == null) {
			stratoCloud = new StratoCloud(0f, 0f);
		}
		this.stratoCloud = stratoCloud;
	}

	public NormalClouds getNormalClouds() {
		return normalClouds;
	}

	public void setNormalClouds(NormalClouds normalClouds) {
		if (normalClouds == null) {
			normalClouds = new NormalClouds(0f, new Vector3f(1f, 1f, 1f), 1f);
		}
		this.normalClouds = normalClouds;
	}
}
