package de.kjEngine.core.sky.dome;

import org.lwjgl.util.vector.Vector3f;

import de.kjEngine.core.awt.DisplayManager;

public class NormalClouds {
	
	public float factor;
	public Vector3f scale;
	public float hardness;
	Vector3f offset = new Vector3f();
	public Vector3f wind;

	public NormalClouds() {
		this(0.72f, new Vector3f(0.3f, 0.8f, 0.3f), 3f);
	}
	
	public NormalClouds(float factor, Vector3f scale, float hardness) {
		this.factor = factor;
		this.scale = scale;
		this.hardness = hardness;
	}
	
	public void update() {
		if (wind == null) {
			return;
		}
		
		float d = DisplayManager.getDelta();
		
		float x = wind.x * d;
		float y = wind.y * d;
		float z = wind.z * d;
		
		offset.x += x;
		offset.y += y;
		offset.z += z;
	}
}
