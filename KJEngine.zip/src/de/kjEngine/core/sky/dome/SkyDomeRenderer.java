package de.kjEngine.core.sky.dome;

import org.lwjgl.opengl.GL11;
import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector3f;

import de.kjEngine.core.api.Cleanable;
import de.kjEngine.core.util.OpenGlUtils;

public class SkyDomeRenderer implements Cleanable {

	private SkyDomeShader shader;
	private Matrix4f buffer = new Matrix4f();
	private Vector3f buffer2 = new Vector3f();

	public SkyDomeRenderer() {
		shader = new SkyDomeShader();
	}

	public void render(SkyDome sky, Matrix4f vMat, Matrix4f pMat) {
		shader.enable();
		SkyDome.MODEL.enable();

		Matrix4f mMat = Matrix4f.setIdentity(buffer);
		float size = sky.getSize();
		buffer2.set(size, size, size);
		mMat.scale(buffer2);
		shader.mMat.loadMatrix(mMat);

		shader.vMat.loadMatrix(vMat);
		shader.pMat.loadMatrix(pMat);

		shader.baseColor.loadVec3(sky.getBaseColor());

		shader.factor.loadFloat(sky.getStratoCloud().factor);
		shader.height.loadFloat(sky.getStratoCloud().height);

		shader.cloud_f.loadFloat(sky.getNormalClouds().factor);
		shader.cloud_scale.loadVec3(sky.getNormalClouds().scale);
		shader.cloud_hardness.loadFloat(sky.getNormalClouds().hardness);

		if (sky.getNormalClouds().offset != null) {
			shader.offset.loadVec3(sky.getNormalClouds().offset);
		}

		OpenGlUtils.cullBackFaces(false);
		OpenGlUtils.enableDepthTesting(false);

		GL11.glDrawElements(GL11.GL_TRIANGLES, SkyDome.MODEL.getIndexCount(), GL11.GL_UNSIGNED_INT, 0);

		OpenGlUtils.cullBackFaces(true);
		OpenGlUtils.enableDepthTesting(true);

		SkyDome.MODEL.disable();
		shader.disable();
	}

	@Override
	public void cleanUp() {
		shader.cleanUp();
	}
}
