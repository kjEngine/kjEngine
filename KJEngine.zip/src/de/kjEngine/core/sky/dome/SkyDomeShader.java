package de.kjEngine.core.sky.dome;

import de.kjEngine.core.api.Shader;
import de.kjEngine.core.uniforms.UniformFloat;
import de.kjEngine.core.uniforms.UniformMat4;
import de.kjEngine.core.uniforms.UniformVec3;

public class SkyDomeShader extends Shader {
	
	public UniformMat4 mMat, vMat, pMat;
	public UniformVec3 baseColor, cloud_scale, offset;
	public UniformFloat factor, height, cloud_f, cloud_hardness;;

	public SkyDomeShader() {
		super("/de/kjEngine/core/sky/dome/vertexShader.glsl", "/de/kjEngine/core/sky/dome/fragmentShader.glsl");
	}

	@Override
	protected void loadUniformLocations() {
		mMat = new UniformMat4(id, "mMat");
		vMat = new UniformMat4(id, "vMat");
		pMat = new UniformMat4(id, "pMat");
		baseColor = new UniformVec3(id, "baseColor");
		factor = new UniformFloat(id, "factor");
		height = new UniformFloat(id, "height");
		cloud_f = new UniformFloat(id, "cloud_f");
		cloud_scale = new UniformVec3(id, "cloud_scale");
		cloud_hardness = new UniformFloat(id, "cloud_hardness");
		offset = new UniformVec3(id, "offset");
	}
}
