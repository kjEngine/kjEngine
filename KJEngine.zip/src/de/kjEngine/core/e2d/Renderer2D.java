package de.kjEngine.core.e2d;

import java.util.List;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;

import de.kjEngine.core.GameEngine;
import de.kjEngine.core.api.AbstractRenderer;
import de.kjEngine.core.awt.DisplayManager;
import de.kjEngine.core.model.Model;
import de.kjEngine.core.util.Axis;
import de.kjEngine.core.util.KTexture;
import de.kjEngine.core.util.OpenGlUtils;

public class Renderer2D extends AbstractRenderer<List<Sprite>> {

	private static final float[] POSITIONS = { -1f, 1f, 0f, -1f, -1f, 0f, 1f, 1f, 0f, 1f, -1f, 0f };
	private static final Model QUAD = de.kjEngine.core.util.Loader.loadModel3D(POSITIONS, null, null, new int[] { 0, 1, 2 },
			new KTexture(0), "quad");

	public Renderer2D() {
		super(new Shader2D());
	}

	@Override
	protected void prepare(List<Sprite> e) {
		OpenGlUtils.enableDepthTesting(false);
		QUAD.enable();
	}

	@Override
	protected void doRender(List<Sprite> e) {
		int lastImg = 0;
		Matrix4f vMat = GameEngine.getCam().getLocation();
		for (Sprite s : e) {
			if (s.isVisible()) {
				if (s.additiveBlending()) {
					OpenGlUtils.enableAdditiveBlending();
				} else {
					OpenGlUtils.enableAlphaBlending();
				}
				Matrix4f mat = Matrix4f.setIdentity(new Matrix4f());
				mat.translate(new Vector2f(s.getX() - 1f, s.getY() - 1f));
				mat.scale(new Vector3f(s.getWidth() / DisplayManager.getAspect(), s.getHeight(), 1f));
				mat.rotate(s.getRot(), Axis.Z);
				if (s.isCentered()) {
					mat.translate(new Vector2f(-0.5f * s.getWidth(), -0.5f * s.getHeight()));
				}
				Matrix4f.mul(vMat, mat, mat);
				((Shader2D) shader).transform.loadMatrix(mat);
				for (int image : s.getImages()) {
					if (lastImg != image) {
						OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE0, image);
						lastImg = image;
					}
					GL11.glDrawArrays(GL11.GL_TRIANGLE_STRIP, 0, 4);
				}
			}
		}
	}

	@Override
	protected void end(List<Sprite> e) {
		OpenGlUtils.disableBlending();
		QUAD.disable();
	}
}
