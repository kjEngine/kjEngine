package de.kjEngine.core.e2d;

import java.util.List;

public interface Sprite {

	float getX();
	float getY();
	float getWidth();
	float getHeight();
	float getRot();
	boolean correctAspect();
	boolean isVisible();
	boolean additiveBlending();
	boolean isCentered();
	List<Integer> getImages();
}
