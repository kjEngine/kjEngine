package de.kjEngine.core.e2d;

import de.kjEngine.core.api.Shader;
import de.kjEngine.core.uniforms.UniformMat4;

public class Shader2D extends Shader {
	
	public UniformMat4 transform;

	public Shader2D() {
		super("/de/kjEngine/core/e2d/vertexShader.glsl", "/de/kjEngine/core/e2d/fragmentShader.glsl");
	}

	@Override
	protected void loadUniformLocations() {
		transform = new UniformMat4(id, "transform");
	}
}
