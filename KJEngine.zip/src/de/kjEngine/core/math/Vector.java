package de.kjEngine.core.math;

public class Vector extends VectorBase {
	
	public VectorBase space;

	public Vector(int dims) {
		super(dims);
		space = new VectorBase(dims);
	}

	public Vector(float... v) {
		super(v);
		space = new VectorBase(v.length);
	}
	
	public Vector(int dims, VectorBase space) {
		super(dims);
		this.space = space;
	}

	public Vector(VectorBase space, float... v) {
		super(v);
		this.space = space;
	}
	
	public Vector convert(VectorBase b) {
		if (b.v.length != v.length) {
			throw new IllegalArgumentException("false vector space");
		}
		for (int i = 0; i < v.length; i++) {
			b.v[i] /= space.v[i];
		}
		return this;
	}
}
