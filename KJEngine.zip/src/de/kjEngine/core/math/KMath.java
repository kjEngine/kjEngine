package de.kjEngine.core.math;

import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;
import org.lwjgl.util.vector.Vector4f;

public class KMath {

	private KMath() {
	}

	public static float interpolate(float a, float b, float factor) {
		return (1f - factor) * a + factor * b;
	}

	public static double interpolate(double a, double b, double factor) {
		return (1f - factor) * a + factor * b;
	}

	public static Vector2f interpolate(Vector2f a, Vector2f b, float factor) {
		return new Vector2f(interpolate(a.x, b.x, factor), interpolate(a.y, b.y, factor));
	}

	public static Vector3f interpolate(Vector3f a, Vector3f b, float factor) {
		return new Vector3f(interpolate(a.x, b.x, factor), interpolate(a.y, b.y, factor),
				interpolate(a.z, b.z, factor));
	}

	public static Vector4f interpolate(Vector4f a, Vector4f b, float factor) {
		return new Vector4f(interpolate(a.x, b.x, factor), interpolate(a.y, b.y, factor), interpolate(a.z, b.z, factor),
				interpolate(a.w, b.w, factor));
	}
	
	public static float dist(Vector2f a, Vector2f b) {
		Vector2f diff = Vector2f.sub(a, b, null);
		return (float) Math.sqrt(diff.x * diff.x + diff.y * diff.y);
	}
	
	public static float dist(Vector3f a, Vector3f b) {
		Vector3f diff = Vector3f.sub(a, b, null);
		return (float) Math.sqrt(diff.x * diff.x + diff.y * diff.y + diff.z * diff.z);
	}
	
	public static double log(double n, double d) {
		return Math.log(d) / Math.log(n);
	}
	
	public static float log(float n, float d) {
		return (float) (Math.log(d) / Math.log(n));
	}
	
	public static int log(int n, int d) {
		return (int) (Math.log(d) / Math.log(n));
	}
	
	public static double clamp(double v, double a, double b) {
		if (v < a) {
			return a;
		}
		if (v > b) {
			return b;
		}
		return v;
	}
	
	public static float clamp(float v, float a, float b) {
		if (v < a) {
			return a;
		}
		if (v > b) {
			return b;
		}
		return v;
	}
	
	public static int clamp(int v, int a, int b) {
		if (v < a) {
			return a;
		}
		if (v > b) {
			return b;
		}
		return v;
	}
	
	public static Vector4f transform(Vector4f vec, Matrix4f... mats) {
		Vector4f result = new Vector4f().set(vec);
		for (Matrix4f mat : mats) {
			Matrix4f.transform(mat, result, result);
		}
		return result;
	}
}
