package de.kjEngine.core.math;

import org.lwjgl.util.vector.Vector2f;

public class Complex {

	public float a, b;

	public Complex() {
		this(0f, 0f);
	}

	public Complex(float a, float b) {
		this.a = a;
		this.b = b;
	}

	public Vector2f asVector() {
		return new Vector2f(a, b);
	}

	public float[] asArray() {
		return new float[] { a, b };
	}

	public Complex add(Complex c) {
		return add(this, c, this);
	}
	
	public static Complex add(Complex a, Complex b, Complex dest) {
		if (dest == null) {
			dest = new Complex();
		}
		dest.a = a.a + b.a;
		dest.b = a.b + b.b;
		return dest;
	}
	
	public Complex sub(Complex c) {
		return sub(this, c, this);
	}
	
	public static Complex sub(Complex a, Complex b, Complex dest) {
		if (dest == null) {
			dest = new Complex();
		}
		dest.a = a.a - b.a;
		dest.b = a.b - b.b;
		return dest;
	}

	public Complex mult(Complex c) {
		return mult(this, c, this);
	}
	
	public static Complex mult(Complex a, Complex b, Complex dest) {
		if (dest == null) {
			dest = new Complex();
		}
		dest.a = a.a * b.a - a.b * b.b;
		dest.b = a.a * b.b + a.b * b.a;
		return dest;
	}
}
