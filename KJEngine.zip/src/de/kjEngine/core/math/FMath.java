package de.kjEngine.core.math;

public class FMath {

	private FMath() {
	}
	
	public static float cos(float a) {
		return (float) Math.cos(a);
	}
	
	public static float sin(float a) {
		return (float) Math.sin(a);
	}
}
