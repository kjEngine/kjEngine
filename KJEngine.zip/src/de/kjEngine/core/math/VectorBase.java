package de.kjEngine.core.math;

public class VectorBase {

	public float[] v;

	public VectorBase(int dims) {
		v = new float[dims];
	}

	public VectorBase(float... v) {
		this.v = v;
	}

	public VectorBase add(VectorBase b) {
		if (b.v.length != v.length) {
			throw new IllegalArgumentException("false vector space");
		}
		for (int i = 0; i < v.length; i++) {
			v[i] += b.v[i];
		}
		return this;
	}

	public VectorBase sub(VectorBase b) {
		if (b.v.length != v.length) {
			throw new IllegalArgumentException("false vector space");
		}
		for (int i = 0; i < v.length; i++) {
			v[i] -= b.v[i];
		}
		return this;
	}

	public VectorBase mul(VectorBase b) {
		if (b.v.length != v.length) {
			throw new IllegalArgumentException("false vector space");
		}
		for (int i = 0; i < v.length; i++) {
			v[i] *= b.v[i];
		}
		return this;
	}

	public VectorBase div(VectorBase b) {
		if (b.v.length != v.length) {
			throw new IllegalArgumentException("false vector space");
		}
		for (int i = 0; i < v.length; i++) {
			v[i] /= b.v[i];
		}
		return this;
	}

	public VectorBase add(float a) {
		for (int i = 0; i < v.length; i++) {
			v[i] += a;
		}
		return this;
	}

	public VectorBase sub(float a) {
		for (int i = 0; i < v.length; i++) {
			v[i] -= a;
		}
		return this;
	}

	public VectorBase mul(float a) {
		for (int i = 0; i < v.length; i++) {
			v[i] *= a;
		}
		return this;
	}

	public VectorBase div(float a) {
		for (int i = 0; i < v.length; i++) {
			v[i] /= a;
		}
		return this;
	}
	
	public float dot(VectorBase b) {
		if (b.v.length != v.length) {
			throw new IllegalArgumentException("false vector space");
		}
		float f = 0f;
		for (int i = 0; i < v.length; i++) {
			f += v[i] * b.v[i];
		}
		return f;
	}
	
	public float lengthSqared() {
		return dot(this);
	}
	
	public float length() {
		return (float) Math.sqrt(lengthSqared());
	}
	
	public VectorBase set(VectorBase b) {
		if (b.v.length != v.length) {
			throw new IllegalArgumentException("false vector space");
		}
		for (int i = 0; i < v.length; i++) {
			v[i] = b.v[i];
		}
		return this;
	}
}
