package de.kjEngine.core.audio;

import java.util.LinkedList;
import java.util.Queue;

import de.kjEngine.core.api.KUtillities;
import de.kjEngine.core.api.Startable;
import de.kjEngine.core.api.Stoppable;

public class MusicPlayer extends SoundComponent implements Startable, Stoppable {

	private Queue<Integer> tracks = new LinkedList<>();
	private Thread player;
	private boolean running;
	private boolean looping;

	public MusicPlayer() {
		this(1f);
	}

	public MusicPlayer(float volume) {
		super(0, volume);
	}

	public Queue<Integer> getTracks() {
		return tracks;
	}

	@Override
	public void stop() {
		if (!running) {
			return;
		}
		running = false;
	}

	@Override
	public void start() {
		if (running) {
			return;
		}
		running = true;
		if (player == null) {
			player = new Thread(new Runnable() {

				@Override
				public void run() {
					shedule();
				}
			}, "audio_sheduler");
			player.start();
		}
	}

	private void shedule() {
		while (running) {
			KUtillities.invokeNext(() -> update());
			try {
				Thread.sleep(20);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	private void update() {
		if (!getSource().isPlaying()) {
			Integer next = tracks.poll();
			if (next != null) {
				setCurrentSound(next);
				if (looping) {
					tracks.offer(next);
				}
				play();
			}
		}
	}

	public boolean isLooping() {
		return looping;
	}

	public void setLooping(boolean looping) {
		this.looping = looping;
	}
}
