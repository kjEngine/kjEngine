package de.kjEngine.core.audio;

import de.kjEngine.core.api.Cleanable;
import de.kjEngine.core.audio.Source;

public class SoundComponent implements Cleanable {

	private int currentSound;
	private Source source;
	private float volume;
	
	public SoundComponent() {
		this(0, 1f);
	}

	public SoundComponent(int sound, float volume) {
		source = new Source();
		setVolume(volume);
		currentSound = sound;
	}

	public int getCurrentSound() {
		return currentSound;
	}

	public void setCurrentSound(int currentSound) {
		this.currentSound = currentSound;
	}

	public float getVolume() {
		return volume;
	}

	public void setVolume(float volume) {
		this.volume = volume;
		source.setVolume(volume);
	}

	public Source getSource() {
		return source;
	}
	
	public void play(int sound) {
		setCurrentSound(sound);
		play();
	}

	public void play() {
		source.play(currentSound);
	}

	@Override
	public void cleanUp() {
		source.cleanUp();
	}
}
