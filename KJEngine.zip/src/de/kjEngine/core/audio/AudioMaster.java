package de.kjEngine.core.audio;

import static org.lwjgl.openal.AL10.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import org.lwjgl.LWJGLException;
import org.lwjgl.openal.AL;
import org.lwjgl.util.WaveData;
import org.lwjgl.util.vector.Vector3f;

public class AudioMaster {

	private static List<Integer> buffers = new ArrayList<>();

	public static void init() {
		try {
			AL.create();
		} catch (LWJGLException e) {
			e.printStackTrace();
		}
	}

	public static void setListenerData(Vector3f pos, Vector3f vel) {
		alListener3f(AL_POSITION, pos.x, pos.y, pos.z);
		alListener3f(AL_VELOCITY, vel.x, vel.y, vel.z);
	}

	public static int loadSound(String path) throws FileNotFoundException {
		if (!path.endsWith(".wav")) {
			throw new IllegalArgumentException("The file must be of the type \"wav\"!");
		}
		
		int buffer = alGenBuffers();
		buffers.add(buffer);
		
		WaveData data = null;
		
		if (path.startsWith("/")) {
			data = WaveData.create(AudioMaster.class.getResourceAsStream(path));
		} else {
			data = WaveData.create(new FileInputStream(new File(path)));
		}
		
		alBufferData(buffer, data.format, data.data, data.samplerate);
		data.dispose();
		
		return buffer;
	}
	
	public static int loadSound(WaveData data) {
		
		int buffer = alGenBuffers();
		buffers.add(buffer);
		
		alBufferData(buffer, data.format, data.data, data.samplerate);
		data.dispose();
		
		return buffer;
	}

	public static void cleanUp() {
		AL.destroy();
		for (int i : buffers) {
			alDeleteBuffers(i);
		}
	}
}
