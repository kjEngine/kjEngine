package de.kjEngine.core.audio;

import java.io.FileNotFoundException;

import org.lwjgl.util.vector.Vector3f;

public class Test {

	public static void main(String[] args) {
		System.setProperty("org.lwjgl.util.Debug", "false");

		AudioMaster.init();
		AudioMaster.setListenerData(new Vector3f(5f, 0f, 0f), new Vector3f(-50f, 0f, 0f));
		
		Vector3f pos = new Vector3f(10f, 2f, 0f);
		Vector3f vel = new Vector3f(-50f, 0f, 0f);

		int sound = 0;
		try {
			sound = AudioMaster.loadSound("/de/kjEngine/core/audio/bounce.wav");
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}

		Source s = new Source();
		s.setLooping(true);
		s.setPitch(0.4f);
		s.setVolume(1f);
		s.play(sound);
		
		while (pos.x > -10f) {
			pos.x -= 0.2f;
			AudioMaster.setListenerData(pos, vel);
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		AudioMaster.cleanUp();
	}
}
