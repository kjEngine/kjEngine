package de.kjEngine.core.audio;

import static org.lwjgl.openal.AL10.*;

import org.lwjgl.util.vector.Vector3f;

import de.kjEngine.core.api.Cleanable;
import de.kjEngine.core.api.Stoppable;

public class Source implements Cleanable, Stoppable {
	
	private int source;
	private boolean looping;
	
	public Source() {
		source = alGenSources();
		alSourcef(source, AL_GAIN, 1f);
		alSourcef(source, AL_PITCH, 1f);
		alSource3f(source, AL_POSITION, 0f, 0f, 0f);
	}
	
	public void play(int buffer) {
		stop();
		alSourcei(source, AL_BUFFER, buffer);
		continuePlaying();
	}
	
	public void pause() {
		alSourcePause(source);
	}
	
	public void continuePlaying() {
		alSourcePlay(source);
	}
	
	public void stop() {
		alSourceStop(source);
	}
	
	public void setVolume(float volume) {
		alSourcef(source, AL_GAIN, volume);
	}
	
	public void setPitch(float pitch) {
		alSourcef(source, AL_PITCH, pitch);
	}
	
	public void setPosition(Vector3f pos) {
		alSource3f(source, AL_POSITION, pos.x, pos.y, pos.z);
	}
	
	public void setLooping(boolean loop) {
		looping = loop;
		alSourcei(source, AL_LOOPING, loop ? AL_TRUE : AL_FALSE);
	}
	
	public boolean isLooping() {
		return looping;
	}
	
	public boolean isPlaying() {
		return alGetSourcei(source, AL_SOURCE_STATE) == AL_PLAYING;
	}

	public void setVelocity(Vector3f velocity) {
		alSource3f(source, AL_VELOCITY, velocity.x, velocity.y, velocity.z);
	}

	@Override
	public void cleanUp() {
		stop();
		alDeleteSources(source);
	}
}
