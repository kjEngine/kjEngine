package de.kjEngine.core.plants;

import de.kjEngine.core.api.Shader;
import de.kjEngine.core.uniforms.UniformMat4;

public class BaseShader extends Shader {
	
	public UniformMat4 mMat;

	public BaseShader(String geomFile) {
		super("/de/kjEngine/core/plants/vertexShader.glsl", "/de/kjEngine/core/plants/fragmentShader.glsl", null, null,
				geomFile);
	}

	@Override
	protected void loadUniformLocations() {
		mMat = new UniformMat4(id, "mMat");
	}
}
