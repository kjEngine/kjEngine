package de.kjEngine.core.plants.rock;

import de.kjEngine.core.plants.BaseShader;
import de.kjEngine.core.uniforms.UniformMat4;

public class RockShader extends BaseShader {
	
	public UniformMat4 vMat, pMat;

	public RockShader() {
		super("/de/kjEngine/core/plants/rock/geometryShader.glsl");
	}

	@Override
	protected void loadUniformLocations() {
		super.loadUniformLocations();
		vMat = new UniformMat4(id, "vMat");
		pMat = new UniformMat4(id, "pMat");
	}
}
