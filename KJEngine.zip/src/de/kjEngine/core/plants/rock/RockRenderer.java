package de.kjEngine.core.plants.rock;

import org.lwjgl.opengl.GL11;
import org.lwjgl.util.vector.Matrix4f;

import de.kjEngine.core.api.Cleanable;
import de.kjEngine.core.model.Model;

public class RockRenderer implements Cleanable {
	
	private RockShader shader;

	public RockRenderer() {
		shader = new RockShader();
	}
	
	public void render(Model formation, Matrix4f mMat, Matrix4f vMat, Matrix4f pMat) {
		shader.enable();
		formation.enable();
		
		shader.mMat.loadMatrix(mMat);
		shader.vMat.loadMatrix(vMat);
		shader.pMat.loadMatrix(pMat);
		
		GL11.glDrawElements(GL11.GL_POINTS, formation.getIndexCount(), GL11.GL_UNSIGNED_INT, 0);
		
		formation.disable();
		shader.disable();
	}

	@Override
	public void cleanUp() {
		shader.cleanUp();
	}
}
