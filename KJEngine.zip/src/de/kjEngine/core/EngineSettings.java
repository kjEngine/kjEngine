package de.kjEngine.core;

import java.awt.Canvas;

public class EngineSettings {
	
	public int width = 1280, height = 720;
	public String title;
	public boolean resizable;
	public boolean console = true;
	public Canvas parent;
	public int fps = 60;

	public EngineSettings() {
	}
}
