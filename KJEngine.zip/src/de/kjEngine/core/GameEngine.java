package de.kjEngine.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.lwjgl.LWJGLException;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL30;
import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector3f;
import org.lwjgl.util.vector.Vector4f;

import de.kjEngine.core.api.Camera;
import de.kjEngine.core.api.Debug;
import de.kjEngine.core.api.Entity;
import de.kjEngine.core.api.FirstPersonCamera;
import de.kjEngine.core.api.FogData;
import de.kjEngine.core.api.KUtillities;
import de.kjEngine.core.api.States;
import de.kjEngine.core.api.ViewPortSetting;
import de.kjEngine.core.awt.DisplayManager;
import de.kjEngine.core.awt.event.KButtonController;
import de.kjEngine.core.mainrendering.Renderer;
import de.kjEngine.core.postProcessing.Fbo;
import de.kjEngine.core.sky.box.SkyBox;
import de.kjEngine.core.sky.dome.SkyDome;
import de.kjEngine.core.util.KJEngineException;

public class GameEngine {

	public static enum Mode {
		MENU(false), GAME(true);

		private boolean b;

		Mode(boolean b) {
			this.b = b;
		}

		public boolean getBoolean() {
			return b;
		}
	}

	private static int fps = 60;
	private static Thread thread;
	private static boolean running = false;
	private static List<States> stateObjects = new ArrayList<>();
	private static Map<String, Entity> entities = new HashMap<>();
	private static List<Runnable> update_actions = new ArrayList<>(), render_actions = new ArrayList<>();
	private static Renderer renderer;
	private static Camera cam;
	private static SkyBox skyBox;
	private static SkyDome skyDome;
	private static Mode mode = Mode.MENU;
	private static boolean render = false;
	private static boolean showingFramerate;
	private static Fbo fbo;
	private static EngineSettings settings;

	public static void stop() {
		if (!running) {
			throw new IllegalStateException("already not running");
		}
		running = false;
	}

	public static void start(EngineSettings settings) {
		if (running) {
			throw new IllegalStateException("already running");
		}
		GameEngine.settings = settings;
		setFps(settings.fps);
		running = true;
		thread = new Thread(new Runnable() {

			@Override
			public void run() {
				init(settings);
				for (States s : stateObjects) {
					s.init();
				}
				KButtonController.callReset();

				long lastFrame = System.currentTimeMillis();

				while (running) {
					float frameTime = 1000f / fps;

					KUtillities.invokeAll();

					if (System.currentTimeMillis() - lastFrame > frameTime) {
						update();
						render();
						for (States s : stateObjects) {
							s.action();
						}
						updateDisplay();
						if (Display.isCloseRequested()) {
							stop();
						}

						lastFrame += (int) frameTime;
					}
				}
				for (States s : stateObjects) {
					s.dispose();
				}
				KUtillities.invokeAll();
				dispose();
			}
		});
		thread.start();
	}

	private static void dispose() {
		renderer.cleanUp();
		DisplayManager.destroy();
		System.exit(0);
	}

	private static void update() {
		if (cam != null && mode.getBoolean()) {
			cam.update();
		}
		for (Runnable r : update_actions) {
			r.run();
		}
	}

	private static void render() {
		if (render) {
			fbo.bindFrameBuffer();
			renderer.clear();
			if (cam != null && mode.getBoolean()) {
				Matrix4f vMat = cam.getLocation();
				if (skyBox != null) {
					renderer.getSkyboxRenderer().render(skyBox, vMat, renderer.getpMat());
				}
				if (skyDome != null) {
					renderer.getSkyDomeRenderer().render(skyDome, vMat, renderer.getpMat());
				}
				fbo.unbindFrameBuffer();
				for (Entity e : entities.values()) {
					renderer.processEntity(e);
				}
				renderer.renderShadowmap();
				fbo.bindFrameBuffer();
				renderer.render(vMat, cam.getPos());
				fbo.unbindFrameBuffer();
				renderer.clearEntitys();
			}
		}
		for (Runnable r : render_actions) {
			r.run();
		}
	}

	private static void updateDisplay() {
		if (render) {
			fbo.resolveToScreen();
		}
		DisplayManager.getRootPanel().render(getRenderer().getGuiRenderer());
		renderer.getGuiRenderer().pollRequests();
		try {
			DisplayManager.update();
		} catch (KJEngineException e) {
			e.printStackTrace();
		}
		if (showingFramerate)  {
			Display.setTitle(settings.title + " | " + DisplayManager.getFps() + " fps");
		}
	}

	private static void init(EngineSettings settings) {
		try {
			try {
				Display.setParent(settings.parent);
			} catch (LWJGLException e) {
				e.printStackTrace();
			}
			DisplayManager.create(settings.width, settings.height, settings.title, settings.resizable,
					settings.console);
		} catch (KJEngineException e) {
			Debug.log(e);
		}
		if (cam == null) {
			cam = new FirstPersonCamera();
		}
		renderer = new Renderer(new ViewPortSetting(60f, DisplayManager.getAspect(), 0.1f, 200f), cam);
		renderer.setRemovingEntitysAfterRendering(false);
		renderer.getSun().setDirection(new Vector3f(0f, -1f, 0f));
		renderer.getSun().setAmbient(new Vector4f(0.1f, 0.1f, 0.1f, 1f));
		renderer.getSun().setDiffuse(new Vector4f(0.8f, 0.8f, 0.8f, 1f));
		renderer.getSun().setSpecular(new Vector4f(0.8f, 0.8f, 0.8f, 0f));
		renderer.setRenderDistance(200f);
		renderer.setFog(new FogData(100f, 200f, new Vector4f(1f, 1f, 1f, 1f)));
		fbo = new Fbo(Display.getWidth(), Display.getHeight(), Fbo.DEPTH_RENDER_BUFFER,
				new int[] { GL30.GL_COLOR_ATTACHMENT0 });
	}

	/**
	 * @return the fps
	 */
	public static int getFps() {
		return fps;
	}

	/**
	 * @param fps the fps to set
	 */
	public static void setFps(int fps) {
		if (fps < 0) {
			throw new IllegalArgumentException("fps < 0");
		}
		GameEngine.fps = fps;
	}

	public static void addStatesObject(States e) {
		stateObjects.add(e);
	}

	public static void removeStatesObject(States e) {
		stateObjects.remove(e);
	}

	public static void addEntity(String name, Entity e) {
		entities.put(name, e);
	}

	public static void removeEntity(String name) {
		Entity v = entities.get(name);
		entities.remove(name, v);
	}

	/**
	 * @return the running
	 */
	public static boolean isRunning() {
		return running;
	}

	/**
	 * @return the renderer
	 */
	public static Renderer getRenderer() {
		return renderer;
	}

	/**
	 * @return the cam
	 */
	public static Camera getCam() {
		return cam;
	}

	/**
	 * @param cam the cam to set
	 */
	public static void setCam(Camera cam) {
		GameEngine.cam = cam;
	}

	public static void setFovy(float a) {
		renderer.getViewPortSetting().setFovy(a);
	}

	/**
	 * @return the skyBox
	 */
	public static SkyBox getSkyBox() {
		return skyBox;
	}

	/**
	 * @param skyBox the skyBox to set
	 */
	public static void setSkyBox(SkyBox skyBox) {
		GameEngine.skyBox = skyBox;
	}

	/**
	 * @return the skyDome
	 */
	public static SkyDome getSkyDome() {
		return skyDome;
	}

	/**
	 * @param skyDome the skyDome to set
	 */
	public static void setSkyDome(SkyDome skyDome) {
		GameEngine.skyDome = skyDome;
	}

	/**
	 * @return the mode
	 */
	public static Mode getMode() {
		return mode;
	}

	/**
	 * @param mode the mode to set
	 */
	public static void setMode(Mode mode) {
		GameEngine.mode = mode;
	}

	public static Matrix4f getVPMat() {
		return Matrix4f.mul(cam.getLocation(), renderer.getpMat(), null);
	}

	public static boolean isRender() {
		return render;
	}

	public static void setRender(boolean render) {
		GameEngine.render = render;
	}

	public static void setRenderer(Renderer renderer) {
		GameEngine.renderer = renderer;
	}

	public static void addUpdateAction(Runnable r) {
		update_actions.add(r);
	}

	public static void removeUpdateAction(Runnable r) {
		update_actions.remove(r);
	}

	public static void addRenderAction(Runnable r) {
		render_actions.add(r);
	}

	public static void removeRenderAction(Runnable r) {
		render_actions.remove(r);
	}

	public static EngineSettings getSettings() {
		return settings;
	}
	
	public static boolean isShowingFramerate() {
		return showingFramerate;
	}

	public static void setShowingFramerate(boolean showingFramerate) {
		GameEngine.showingFramerate = showingFramerate;
	}

	public static void clearDisplay(float r, float g, float b, float a) {
		Vector4f c = renderer.getClearColor();
		if (r != c.x || g != c.y || b != c.z || a != c.w) {
			renderer.setClearColor(new Vector4f(r, g, b, a));
		}
		renderer.clear();
	}
}
