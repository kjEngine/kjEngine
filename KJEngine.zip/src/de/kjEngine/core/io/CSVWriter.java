package de.kjEngine.core.io;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.List;

public class CSVWriter implements AutoCloseable {
	
	private BufferedWriter w;

	public CSVWriter(String file) throws IOException {
		w = new BufferedWriter(new FileWriter(new File(file)));
	}
	
	public CSVWriter(File file) throws IOException {
		w = new BufferedWriter(new FileWriter(file));
	}
	
	public CSVWriter(OutputStream s) {
		w = new BufferedWriter(new OutputStreamWriter(s));
	}
	
	public CSVWriter(Writer out) {
		w = new BufferedWriter(out);
	}
	
	public void write(CSVFile data) throws IOException {
		for (List<String> line : data.getValues()) {
			for (String value : line) {
				w.write(value + "; ");
			}
			w.write("\n");
		}
	}

	@Override
	public void close() throws IOException {
		w.close();
	}
}
