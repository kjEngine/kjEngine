package de.kjEngine.core.io;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public abstract class Cache<T> {
	
	public final Map<String, T> VALUES = new HashMap<>();
	
	public Cache(String rootFile) {
		File root = new File(rootFile);
		load(root);
	}
	
	private void load(File file) {
		if (file.isDirectory()) {
			File[] children = file.listFiles();
			for (File child : children) {
				load(child);
			}
		} else {
			put(file);
		}
	}

	protected abstract void put(File file);
}
