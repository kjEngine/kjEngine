package de.kjEngine.core.io;

import java.util.HashMap;
import java.util.Map;

public class PropertiesFile {
	
	private Map<String, String> data;

	public PropertiesFile(Map<String, String> data) {
		if (data == null) {
			data = new HashMap<>();
		}
		this.data = data;
	}
	
	public String getString(String key) {
		return data.get(key);
	}
	
	public byte getByte(String key) {
		return Byte.parseByte(data.get(key));
	}
	
	public short getShort(String key) {
		return Short.parseShort(data.get(key));
	}
	
	public char getChar(String key) {
		return data.get(key).charAt(0);
	}
	
	public int getInt(String key) {
		return Integer.decode(data.get(key));
	}
	
	public int[] getInts(String key) {
		String[] parts = getString(key).split(",");
		int[] result = new int[parts.length];
		for (int i = 0; i < parts.length; i++) {
			result[i] = Integer.decode(parts[i].trim());
		}
		return result;
	}
	
	public float getFloat(String key) {
		return Float.parseFloat(data.get(key));
	}
	
	public double getDouble(String key) {
		return Double.parseDouble(data.get(key));
	}
	
	public long getLong(String key) {
		return Long.parseLong(data.get(key));
	}

	public boolean getBoolean(String key) {
		return Boolean.parseBoolean(data.get(key));
	}

	public Map<String, String> getData() {
		return data;
	}

	public String[] getStrings(String key) {
		String[] parts = getString(key).split(",");
		for (int i = 0; i < parts.length; i++) {
			parts[i] = parts[i].trim();
		}
		return parts;
	}
}
