package de.kjEngine.core.io;

import java.io.File;
import java.io.IOException;

import de.kjEngine.core.model.Model;
import de.kjEngine.core.util.KTexture;
import de.kjEngine.core.util.Loader;

public class ModelCache extends Cache<Model> {

	public ModelCache(String rootFile) {
		super(rootFile);
	}

	@Override
	protected void put(File file) {
		try {
			Model m = Loader.loadObjModel(file.getCanonicalPath(), new KTexture(0), file.getName().split("\\.")[0]);
			VALUES.put(m.getName(), m);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}