package de.kjEngine.core.io;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

public class CSVReader implements AutoCloseable {

	private BufferedReader r;

	public CSVReader(String file) throws FileNotFoundException {
		r = new BufferedReader(new FileReader(new File(file)));
	}

	public CSVReader(File file) throws FileNotFoundException {
		r = new BufferedReader(new FileReader(file));
	}

	public CSVReader(InputStream s) {
		r = new BufferedReader(new InputStreamReader(s));
	}

	public CSVReader(Reader r) {
		r = new BufferedReader(r);
	}

	public CSVFile read() throws IOException {
		StringBuilder sb = new StringBuilder();
		String line;
		CSVFile result = new CSVFile();

		while ((line = r.readLine()) != null) {
			sb.append(line + "\n");
		}

		String content = sb.toString();

		String[] lines = content.split("\n");

		for (String l : lines) {
			List<String> vals = new ArrayList<>();
			String[] s_vals = l.split(";");
			for (String val : s_vals) {
				String v = val.trim();
				if (!v.isEmpty()) {
					vals.add(v);
				}
			}
			result.getValues().add(vals);
		}

		return result;
	}

	@Override
	public void close() throws IOException {
		r.close();
	}
}
