package de.kjEngine.core.io;

import java.util.ArrayList;
import java.util.List;

public class CSVFile {

	private List<List<String>> values;

	public CSVFile() {
		this(new ArrayList<>());
	}

	public CSVFile(List<List<String>> values) {
		this.values = values;
	}

	public List<List<String>> getValues() {
		return values;
	}

	public void insert(String value, int line, int col) {
		values.get(line).set(col, value);
	}

	@Override
	public String toString() {
		return "CSVFile [values=" + values + "]";
	}
}
