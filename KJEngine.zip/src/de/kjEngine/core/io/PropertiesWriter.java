package de.kjEngine.core.io;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.Map.Entry;

public class PropertiesWriter implements AutoCloseable {
	
	private BufferedWriter w;

	public PropertiesWriter(String file) throws IOException {
		w = new BufferedWriter(new FileWriter(new File(file)));
	}
	
	public PropertiesWriter(File file) throws IOException {
		w = new BufferedWriter(new FileWriter(file));
	}
	
	public PropertiesWriter(OutputStream s) {
		w = new BufferedWriter(new OutputStreamWriter(s));
	}
	
	public PropertiesWriter(Writer out) {
		w = new BufferedWriter(out);
	}
	
	public void write(PropertiesFile data) throws IOException {
		for (Entry<String, String> e : data.getData().entrySet()) {
			w.write(e.getKey() + " = " + e.getValue() + "\n");
		}
	}

	@Override
	public void close() throws IOException {
		w.close();
	}
}
