package de.kjEngine.core.io;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.HashMap;
import java.util.Map;

public class PropertiesReader implements AutoCloseable {
	
	private BufferedReader reader;

	public PropertiesReader(File file) throws FileNotFoundException {
		reader = new BufferedReader(new FileReader(file));
	}
	
	public PropertiesReader(Reader r) {
		reader = new BufferedReader(r);
	}
	
	public PropertiesFile read() throws IOException {
		StringBuilder sb = new StringBuilder();
		String line;
		
		while ((line = reader.readLine()) != null) {
			sb.append(line + "\n");
		}
		
		String[] lines = sb.toString().split("\n");
		Map<String, String> data = new HashMap<>();
		
		for (int i = 0; i < lines.length; i++) {
			String[] parts = lines[i].split("=");
			
			String key = parts[0].trim();
			String value = parts[1].trim();
			
			data.put(key, value);
		}
		
		return new PropertiesFile(data);
	}

	@Override
	public void close() throws IOException {
		reader.close();
	}
}
