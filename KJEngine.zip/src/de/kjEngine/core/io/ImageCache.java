package de.kjEngine.core.io;

import java.io.File;
import java.io.IOException;

import de.kjEngine.core.util.Loader;

public class ImageCache extends Cache<Integer> {

	public ImageCache(String rootFile) {
		super(rootFile);
	}

	@Override
	protected void put(File file) {
		try {
			String name = file.getName().split("\\.")[0];
			Integer id = Loader.loadTexturei(file.getCanonicalPath());
			VALUES.put(name, id);
		} catch (Throwable e) {
			e.printStackTrace();
			try {
				System.err.println("(Failed to load image:" + file.getCanonicalPath()+ ")");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
	}
}
