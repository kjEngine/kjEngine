package de.kjEngine.core.io.security;

public class CombinedCrypter implements Crypter {
	
	private Crypter[] crypters;

	public CombinedCrypter(Crypter[] crypters) {
		this.crypters = crypters;
	}

	@Override
	public byte[] encrypt(byte[] data) {
		for (int i = 0; i < crypters.length; i++) {
			data = crypters[i].encrypt(data);
		}
		return data;
	}

	@Override
	public byte[] decrypt(byte[] data) {
		for (int i = crypters.length - 1; i >= 0; i--) {
			data = crypters[i].decrypt(data);
		}
		return data;
	}
}
