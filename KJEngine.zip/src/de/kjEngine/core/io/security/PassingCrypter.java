package de.kjEngine.core.io.security;

public class PassingCrypter implements Crypter {

	public PassingCrypter() {
	}

	@Override
	public byte[] encrypt(byte[] data) {
		return data;
	}

	@Override
	public byte[] decrypt(byte[] data) {
		return data;
	}
}
