package de.kjEngine.core.io.security;

public class CBCrypter extends CombinedCrypter {

	public CBCrypter() {
		super(new Crypter[] {
				new AddCrypter(37),
				new IndexCrypter(),
				new RandomCrypter(279754357L),
				new AddCrypter(-3)
		});
	}
}
