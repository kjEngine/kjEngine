package de.kjEngine.core.io.security;

import java.util.Random;

public class RandomCrypter implements Crypter {
	
	private Random random;
	private long seed;

	public RandomCrypter(long seed) {
		this.seed = seed;
		random = new Random();
	}

	@Override
	public byte[] encrypt(byte[] data) {
		random.setSeed(seed);
		byte[] n = new byte[data.length];
		for (int i = 0; i < n.length; i++) {
			n[i] = (byte) (ModUtils.mod(data[i] + random.nextInt(), 0xFF));
		}
		return n;
	}

	@Override
	public byte[] decrypt(byte[] data) {
		random.setSeed(seed);
		byte[] n = new byte[data.length];
		for (int i = 0; i < n.length; i++) {
			n[i] = (byte) (ModUtils.mod(data[i] - random.nextInt(), 0xFF));
		}
		return n;
	}
}
