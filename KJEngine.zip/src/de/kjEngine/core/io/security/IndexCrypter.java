package de.kjEngine.core.io.security;

public class IndexCrypter implements Crypter {
	
	public IndexCrypter() {
	}

	@Override
	public byte[] encrypt(byte[] data) {
		byte[] n = new byte[data.length];
		for (int i = 0; i < n.length; i++) {
			n[i] = (byte) ModUtils.mod((data[i] + i), 0xFF);
		}
		return n;
	}

	@Override
	public byte[] decrypt(byte[] data) {
		byte[] n = new byte[data.length];
		for (int i = 0; i < n.length; i++) {
			n[i] = (byte) ModUtils.mod((data[i] - i), 0xFF);
		}
		return n;
	}
}
