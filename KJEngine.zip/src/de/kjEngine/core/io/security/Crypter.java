package de.kjEngine.core.io.security;

public interface Crypter {

	/**
	 * Encrypts a byte array
	 * @param data
	 * @return a new byte array
	 */
	byte[] encrypt(byte[] data);
	
	/**
	 * Decrypts a byte array
	 * @param data
	 * @return a new byte array
	 */
	byte[] decrypt(byte[] data);
}
