package de.kjEngine.core.io.security;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Writer;

public class CryptedWriter extends Writer {
	
	private OutputStream out;
	private Crypter crypter;

	public CryptedWriter(String file, Crypter crypter) throws IOException {
		out = new BufferedOutputStream(new FileOutputStream(new File(file)));
		setCrypter(crypter);
	}
	
	public CryptedWriter(File file, Crypter crypter) throws IOException {
		out = new BufferedOutputStream(new FileOutputStream(file));
		this.crypter = crypter;
	}
	
	public CryptedWriter(OutputStream out, Crypter crypter) throws IOException {
		this.out = new BufferedOutputStream(out);
		this.crypter = crypter;
	}
	
	private void setCrypter(Crypter crypter) {
		if (crypter == null) {
			throw new NullPointerException("crypter == null");
		}
		this.crypter = crypter;
	}
	
	@Override
	public void write(char[] cbuf, int off, int len) throws IOException {
		byte[] data = new byte[len];
		for (int i = 0; i < len; i++) {
			data[i] = (byte) cbuf[i + off];
		}
		data = crypter.encrypt(data);
		out.write(data, 0, data.length);
	}
	
	@Override
	public void flush() throws IOException {
		out.flush();
	}

	@Override
	public void close() throws IOException {
		out.close();
	}
}
