package de.kjEngine.core.io.security;

class ModUtils {

	static int mod(int i, int m) {
		m /= 2;
		i %= m;
		if (i < 0) {
			i += m;
		}
		return i;
	}
}
