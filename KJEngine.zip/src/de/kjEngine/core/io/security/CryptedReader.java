package de.kjEngine.core.io.security;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

public class CryptedReader extends Reader {
	
	private InputStream in;
	private byte[] data;
	private Crypter crypter;
	private int off;

	public CryptedReader(String file, Crypter crypter) throws IOException {
		in = new BufferedInputStream(new FileInputStream(new File(file)));
		setCrypter(crypter);
		init();
	}
	
	public CryptedReader(File file, Crypter crypter) throws IOException {
		in = new BufferedInputStream(new FileInputStream(file));
		this.crypter = crypter;
		init();
	}
	
	public CryptedReader(InputStream in, Crypter crypter) throws IOException {
		this.in = new BufferedInputStream(in);
		this.crypter = crypter;
		init();
	}
	
	private void setCrypter(Crypter crypter) {
		if (crypter == null) {
			throw new NullPointerException("crypter == null");
		}
		this.crypter = crypter;
	}

	private void init() throws IOException {
		synchronized (lock) {
			List<Byte> pre = new ArrayList<>();
			int len;
			byte[] buffer = new byte[1024];
			while ((len = in.read(buffer)) != -1) {
				for (int i = 0; i < len; i++) {
					pre.add(buffer[i]);
				}
			}
			data = new byte[pre.size()];
			for (int i = 0; i < data.length; i++) {
				data[i] = pre.get(i);
			}
			data = crypter.decrypt(data);
		}
	}

	@Override
	public int read(char[] cbuf, int off, int len) throws IOException {
		synchronized (lock) {
			int left = data.length - (this.off);
			if (left <= 0) {
				return -1;
			}
			int a = Math.min(left, len);
			for (int i = this.off; i < this.off + a; i++) {
				cbuf[i + off] = (char) data[i];
			}
			this.off += a;
			return a;
		}
	}

	@Override
	public void close() throws IOException {
		in.close();
	}
}
