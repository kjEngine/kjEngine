package de.kjEngine.core.io.security;

public class AddCrypter implements Crypter {
	
	private int a;

	public AddCrypter(int a) {
		setA(a);
	}

	@Override
	public byte[] encrypt(byte[] data) {
		byte[] n = new byte[data.length];
		for (int i = 0; i < n.length; i++) {
			n[i] = (byte) ModUtils.mod((data[i] + a), 0xff);
		}
		return n;
	}

	@Override
	public byte[] decrypt(byte[] data) {
		byte[] n = new byte[data.length];
		for (int i = 0; i < n.length; i++) {
			n[i] = (byte) ModUtils.mod((data[i] - a), 0xFF);
		}
		return n;
	}

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}
}
