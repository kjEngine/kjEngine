package de.kjEngine.core.io.security;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Test {

	public static void main(String[] args) {
		String file = "src/de/kj/citybuilder/res/security/test";
		try {
			BufferedWriter w = new BufferedWriter(new CryptedWriter(file + ".cpt", new CBCrypter()));
			BufferedReader r = new BufferedReader(new FileReader(new File(file + ".txt")));
			String line;
			while ((line = r.readLine()) != null) {
				w.write((line + "\n").toCharArray());
			}
			w.close();
			r.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			BufferedReader r = new BufferedReader(new CryptedReader(file + ".cpt", new CBCrypter()));
			String line;
			while ((line = r.readLine()) != null) {
				System.out.println(line);
			}
			r.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
