package de.kjEngine.core.io.va;

public class Set implements VirtualMethod<Object> {

	public Set() {
	}

	@Override
	public Object run(VirtualApplication a, String[] args) {
		if (args.length == 2) {
			String name = args[0].trim();
			String value = Caster.cast(a, args[1].trim()).value.toString();
			a.getMemory().put(name.trim(), value.trim());
		}
		return null;
	}
}
