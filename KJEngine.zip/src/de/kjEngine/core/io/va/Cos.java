package de.kjEngine.core.io.va;

public class Cos implements VirtualMethod<String> {

	public Cos() {
	}

	@Override
	public String run(VirtualApplication a, String[] args) {
		if (args.length == 1) {
			double na = Double.parseDouble(Caster.cast(a, args[0].trim()).value.toString());
			return String.valueOf(Math.cos(na));
		}
		return null;
	}
}
