package de.kjEngine.core.io.va;

public class Print implements VirtualMethod<Object> {

	public Print() {
	}

	@Override
	public Object run(VirtualApplication a, String[] args) {
		for (String s : args) {
			String data = Caster.cast(a, s).value.toString();
			System.out.print(data);
		}
		System.out.println();
		return null;
	}
}
