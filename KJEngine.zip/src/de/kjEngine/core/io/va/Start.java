package de.kjEngine.core.io.va;

public interface Start<T> extends VirtualMethod<T> {
}
