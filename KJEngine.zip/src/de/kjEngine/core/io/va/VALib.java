package de.kjEngine.core.io.va;

import java.util.HashMap;
import java.util.Map;

public class VALib extends HashMap<String, VirtualMethod<?>> {
	private static final long serialVersionUID = 1L;

	public VALib() {
	}

	public VALib(int initialCapacity) {
		super(initialCapacity);
	}

	public VALib(Map<? extends String, ? extends VirtualMethod<?>> m) {
		super(m);
	}

	public VALib(int initialCapacity, float loadFactor) {
		super(initialCapacity, loadFactor);
	}
}
