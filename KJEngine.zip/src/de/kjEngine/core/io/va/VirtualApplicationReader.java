package de.kjEngine.core.io.va;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class VirtualApplicationReader implements AutoCloseable {

	public static final Pattern METHOD = Pattern.compile("\\s*([#\\w]+)\\s*\\(\\s*((.+)\\s*\\,?\\s*)*\\s*\\)\\s*");
	public static final Pattern OPERATOR = Pattern.compile("\\s*(.+)\\s*([=+*\\-/<>!%])\\s*(.+)\\s*");
	public static final Pattern OPERATOR_CHAR = Pattern.compile("[=+*\\-/<>!%]");

	private BufferedReader r;

	public VirtualApplicationReader(String file) throws FileNotFoundException {
		r = new BufferedReader(new FileReader(new File(file)));
	}

	public VirtualApplicationReader(File file) throws FileNotFoundException {
		r = new BufferedReader(new FileReader(file));
	}

	public VirtualApplicationReader(Reader r) {
		this.r = new BufferedReader(r);
	}

	public VirtualApplicationReader(BufferedReader r) {
		this.r = r;
	}

	public VirtualApplication read(VALib... libs) throws IOException, Exception {
		String data = readFile();
		Map<String, VirtualMethod<?>> whole_lib = new HashMap<>();
		for (Map<String, VirtualMethod<?>> lib : libs) {
			whole_lib.putAll(lib);
		}
		return compile(data, whole_lib);
	}

	private VirtualApplication compile(String data, Map<String, VirtualMethod<?>> lib) throws Exception {
		String[] instructions = data.split(";");
		List<VirtualMethod<?>> methods = new ArrayList<>();
		List<String[]> final_params = new ArrayList<>();
		VirtualApplication appl = new VirtualApplication(methods, final_params, lib);

		for (String instruction : instructions) {
			instruction = instruction.trim();
			Matcher matcher = METHOD.matcher(instruction);
			Matcher o_matcher = OPERATOR.matcher(instruction);

			if (!matcher.matches() && !o_matcher.matches()) {
				throw new Exception("Error: " + instruction);
			}

			if (matcher.matches()) {
				String name = matcher.group(1);

				if (!name.startsWith("#")) {
					String[] params;
					if (matcher.groupCount() > 1) {
						String param_string = matcher.group(2);
						if (param_string != null) {
							params = CompilingUtills.split_params(matcher.group(2));
						} else {
							params = new String[0];
						}
					} else {
						params = new String[0];
					}

					methods.add(lib.get(name));
					final_params.add(params);
				} else {
					Caster.cast(appl, instruction.substring(1));
				}
			} else {
				String v0 = o_matcher.group(1);
				String operator = o_matcher.group(2);
				int i = instruction.lastIndexOf(operator);
				String oadd = String.valueOf(instruction.charAt(i - 1));
				Matcher oaddcm = OPERATOR_CHAR.matcher(oadd);
				if (oaddcm.matches()) {
					operator = oadd + operator;
					v0 = v0.substring(0, v0.length() - 1);
				}
				String v1 = o_matcher.group(3);

				methods.add(lib.get(operator));
				final_params.add(new String[] { v0, v1 });
			}
		}
		return appl;
	}

	private String readFile() throws IOException {
		StringBuilder sb = new StringBuilder();
		String line;
		while ((line = r.readLine()) != null) {
			sb.append(line);
		}
		return sb.toString();
	}

	@Override
	public void close() throws IOException {
		r.close();
	}
}
