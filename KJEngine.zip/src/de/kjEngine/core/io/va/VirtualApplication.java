package de.kjEngine.core.io.va;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class VirtualApplication {

	private Thread thread;
	private List<VirtualMethod<?>> program;
	private List<String[]> params;
	private boolean running = false;
	private int pointer;
	private final Map<String, String> memory = new HashMap<>();
	private final Map<String, VirtualMethod<?>> methods;

	public VirtualApplication(List<VirtualMethod<?>> program, List<String[]> params, Map<String, VirtualMethod<?>> methods) {
		this.program = program;
		this.params = params;
		this.methods = methods;
	}

	public void start() {
		running = true;
		thread = new Thread(() -> {
			while (running) {
				invokeNext();
			}
		}, "virtual_application");
		thread.start();
	}

	public void invokeNext() {
		invokeThis();
		pointer++;
		if (pointer >= program.size()) {
			stop();
		}
	}
	
	public void invokeThis() {
		VirtualMethod<?> m = program.get(pointer);
		if (m == null) {
			throw new RuntimeException("Method not found (at line " + (pointer + 1) + ")");
		}
		m.run(this, params.get(pointer));
	}

	public void stop() {
		running = false;
	}

	public int getPointer() {
		return pointer;
	}

	public void setPointer(int pointer) {
		this.pointer = pointer;
	}

	public Map<String, String> getMemory() {
		return memory;
	}

	public Map<String, VirtualMethod<?>> getMethods() {
		return methods;
	}

	public List<VirtualMethod<?>> getProgram() {
		return program;
	}

	public List<String[]> getParams() {
		return params;
	}
}
