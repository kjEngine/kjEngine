package de.kjEngine.core.io.va;

public class Equals implements VirtualMethod<Boolean> {

	public Equals() {
	}

	@Override
	public Boolean run(VirtualApplication a, String[] args) {
		String sa = Caster.cast(a, args[0].trim()).value.toString();
		String sb = Caster.cast(a, args[1].trim()).value.toString();
		if (args.length == 2) {
			try {
				double na = Double.parseDouble(sa);
				double nb = Double.parseDouble(sb);
				return na == nb;
			} catch (RuntimeException e) {
			}
			return sa.equals(sb);
		}
		return false;
	}
}
