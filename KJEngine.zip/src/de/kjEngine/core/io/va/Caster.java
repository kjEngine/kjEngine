package de.kjEngine.core.io.va;

import java.util.regex.Matcher;

public class Caster {

	public static Variable<?> cast(VirtualApplication a, String arg) {
		arg = arg.trim();
		if (arg.startsWith("\"") && arg.endsWith("\"")) {
			return new Variable<String>(arg.substring(1, arg.length() - 1), "string");
		}
		if (a.getMemory().containsKey(arg)) {
			return new Variable<String>(a.getMemory().get(arg), "string");
		}
		Matcher matcher = VirtualApplicationReader.METHOD.matcher(arg);
		Matcher o_matcher = VirtualApplicationReader.OPERATOR.matcher(arg);
		if (matcher.matches()) {
			String name = matcher.group(1);
			VirtualMethod<?> method = a.getMethods().get(name);
			if (method == null) {
				throw new RuntimeException("Could not find method: " + name);
			}
			String[] params;
			if (matcher.groupCount() > 1) {
				String param_string = matcher.group(2);
				if (param_string != null) {
					params = CompilingUtills.split_params(matcher.group(2));
				} else {
					params = new String[0];
				}
			} else {
				params = new String[0];
			}
			return new Variable<Object>(method.run(a, params), "return_type");
		}
		if (o_matcher.matches()) {
			String v0 = o_matcher.group(1).trim();
			String operator = o_matcher.group(2).trim();
			int i = arg.lastIndexOf(operator);
			String oadd = String.valueOf(arg.charAt(i - 1));
			Matcher oaddcm = VirtualApplicationReader.OPERATOR_CHAR.matcher(oadd);
			if (oaddcm.matches()) {
				operator = oadd + operator;
				v0 = v0.substring(0, v0.length() - 1);
			}
			String v1 = o_matcher.group(3).trim();
			
			VirtualMethod<?> method = a.getMethods().get(operator);
			return new Variable<Object>(method.run(a, new String[] {v0, v1}), "return_type");
		}
		return new Variable<String>(arg, "string");
	}
}
