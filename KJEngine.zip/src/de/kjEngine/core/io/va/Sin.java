package de.kjEngine.core.io.va;

public class Sin implements VirtualMethod<String> {

	public Sin() {
	}

	@Override
	public String run(VirtualApplication a, String[] args) {
		if (args.length == 1) {
			double na = Double.parseDouble(Caster.cast(a, args[0].trim()).value.toString());
			return String.valueOf(Math.sin(na));
		}
		return null;
	}
}
