package de.kjEngine.core.io.va;

public interface VirtualMethod<T> {

	T run(VirtualApplication a, String[] args);
}
