package de.kjEngine.core.io.va;

public class Div implements VirtualMethod<String> {

	public Div() {
	}

	@Override
	public String run(VirtualApplication a, String[] args) {
		if (args.length == 2) {
			double na = Double.parseDouble(Caster.cast(a, args[0].trim()).value.toString());
			double nb = Double.parseDouble(Caster.cast(a, args[1].trim()).value.toString());
			return String.valueOf(na * nb);
		}
		return null;
	}
}
