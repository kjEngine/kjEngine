package de.kjEngine.core.io.va;

import java.util.ArrayList;
import java.util.List;

public class CompilingUtills {

	public static String[] split_params(String group) {
		List<String> result = new ArrayList<>();
		int block_count = 0;
		StringBuilder sb = new StringBuilder();

		for (char c : group.toCharArray()) {
			if (c == '(') {
				block_count++;
			} else if (c == ')') {
				block_count--;
			}
			if (c == ',' && block_count == 0) {
				result.add(sb.toString().trim());
				sb = new StringBuilder();
			} else {
				sb.append(c);
			}
		}

		result.add(sb.toString());

		return result.toArray(new String[result.size()]);
	}
}
