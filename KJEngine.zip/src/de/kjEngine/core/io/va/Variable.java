package de.kjEngine.core.io.va;

public class Variable<T> {

	public T value;
	public String typeName;

	public Variable(T value, String typeName) {
		this.value = value;
		this.typeName = typeName;
	}
}
