package de.kjEngine.core.io.va;

import java.util.Map.Entry;

public class MemoryDump implements VirtualMethod<String> {

	public MemoryDump() {
	}

	@Override
	public String run(VirtualApplication a, String[] args) {
		StringBuilder sb = new StringBuilder();
		sb.append("memory = {\n");
		for (Entry<String, String> element : a.getMemory().entrySet()) {
			sb.append("\t" + element.getKey() + " = " + element.getValue() + "\n");
		}
		sb.append("}");
		return sb.toString();
	}
}
