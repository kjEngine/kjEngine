package de.kjEngine.core.io.va;

import java.io.IOException;

public class VATest {

	public static void main(String[] args) {
		try {
			VirtualApplicationReader r = new VirtualApplicationReader("test.va");
			try {
				VirtualApplication va = r.read(StdLibery.load());
				va.start();
			} catch (Exception e) {
				e.printStackTrace();
			}
			r.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
