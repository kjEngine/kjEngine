package de.kjEngine.core.io.va;

public class For implements Start<Object> {

	private While impl;
	private String increment;
	VirtualApplication a;

	public For() {
		impl = new While();
		impl.iterationListener = new Runnable() {
			
			@Override
			public void run() {
				Caster.cast(a, increment);
			}
		};
	}

	@Override
	public Object run(VirtualApplication a, String[] args) {
		if (args.length == 3) {
			this.a = a;
			
			normalize(args);
			
			String argument = "true";
			
			if (!args[0].isEmpty()) {
				Caster.cast(a, args[0]);
			}
			if (!args[1].isEmpty()) {
				argument = args[1];
			}
			if (!args[2].isEmpty()) {
				increment = args[2];
			}
			
			impl.run(a, new String[] {argument});
		}
		return null;
	}

	private void normalize(String[] args) {
		for (int i = 0; i < args.length; i++) {
			args[i] = args[i].trim();
		}
	}
}
