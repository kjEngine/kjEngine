package de.kjEngine.core.io.va;

import java.io.FileNotFoundException;
import java.io.IOException;

public class RunNew implements VirtualMethod<Object> {

	public RunNew() {
	}

	@Override
	public Object run(VirtualApplication a, String[] args) {
		if (args.length == 1) {
			try (VirtualApplicationReader r = new VirtualApplicationReader(Caster.cast(a, args[0]).value.toString())) {
				try {
					VirtualApplication ap = r.read(new VALib(a.getMethods()));
					ap.start();
				} catch (Exception e) {
					e.printStackTrace();
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return null;
	}
}
