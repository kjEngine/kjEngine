package de.kjEngine.core.io.va;

import java.util.List;
import java.util.Map;

public class CustomMethod implements VirtualMethod<Object> {
	
	private VirtualApplication me;

	public CustomMethod(List<VirtualMethod<?>> content, List<String[]> params, Map<String, VirtualMethod<?>> lib) {
		me = new VirtualApplication(content, params, lib);
	}

	@Override
	public Object run(VirtualApplication a, String[] args) {
		Object returnVal = null;
		while (me.getPointer() < me.getProgram().size()) {
			VirtualMethod<?> m = me.getProgram().get(me.getPointer());
			if (m instanceof Return) {
				returnVal = m.run(me, me.getParams().get(me.getPointer()));
				break;
			}
			m.run(me, me.getParams().get(me.getPointer()));
			me.setPointer(me.getPointer() + 1);
		}
		me.setPointer(0);
		return returnVal;
	}
}
