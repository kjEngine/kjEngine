package de.kjEngine.core.io.va;

public class Delete implements VirtualMethod<Object> {

	public Delete() {
	}

	@Override
	public Object run(VirtualApplication a, String[] args) {
		if (args.length == 1) {
			String name = Caster.cast(a, args[0]).value.toString();
			a.getMemory().remove(name);
		}
		return null;
	}
}
