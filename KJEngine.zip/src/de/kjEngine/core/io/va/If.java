package de.kjEngine.core.io.va;

public class If implements Start<Object> {

	public If() {
	}

	@Override
	public Object run(VirtualApplication a, String[] args) {
		boolean val = Boolean.parseBoolean(Caster.cast(a, args[0]).value.toString());
		if (!val) {
			RuntimeUtils.goToEnd(a);
		}
		return null;
	}
}
