package de.kjEngine.core.io.va;

public class RuntimeUtils {

	private RuntimeUtils() {
	}

	public static void goToEnd(VirtualApplication a) {
		int level = 1;
		while (level > 0) {
			a.setPointer(a.getPointer() + 1);
			if (a.getProgram().get(a.getPointer()) instanceof Start) {
				level++;
			} else if (a.getProgram().get(a.getPointer()) instanceof End) {
				level--;
			}
		}
		a.invokeThis();
	}
}
