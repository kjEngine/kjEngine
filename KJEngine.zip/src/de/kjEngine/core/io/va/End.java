package de.kjEngine.core.io.va;

public class End implements VirtualMethod<Object> {

	public End() {
	}

	@Override
	public Object run(VirtualApplication a, String[] args) {
		return null;
	}
}
