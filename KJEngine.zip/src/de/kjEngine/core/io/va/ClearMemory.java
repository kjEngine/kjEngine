package de.kjEngine.core.io.va;

public class ClearMemory implements VirtualMethod<Object> {

	public ClearMemory() {
	}

	@Override
	public Object run(VirtualApplication a, String[] args) {
		if (args.length == 0) {
			a.getMemory().clear();
		}
		return null;
	}
}
