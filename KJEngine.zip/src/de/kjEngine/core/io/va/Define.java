package de.kjEngine.core.io.va;

public class Define implements VirtualMethod<Object> {

	public Define() {
	}

	@Override
	public Object run(VirtualApplication a, String[] args) {
		if (args.length == 2) {
			args[0] = args[0].trim();
			args[1] = args[1].trim().replace('\n', ' ');
			if ("METHOD".equals(args[0])) {
				
			}
		}
		return null;
	}
}
