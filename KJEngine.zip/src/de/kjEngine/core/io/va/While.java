package de.kjEngine.core.io.va;

public class While implements Start<Object> {
	
	Runnable iterationListener;

	public While() {
	}

	@Override
	public Object run(VirtualApplication a, String[] args) {
		a.setPointer(a.getPointer() + 1);
		int position = a.getPointer();
		while (true) {
			boolean val = Boolean.parseBoolean(Caster.cast(a, args[0]).value.toString());
			if (!val) {
				RuntimeUtils.goToEnd(a);
				return null;
			} else {
				int level = 1;
				while (level > 0) {
					a.invokeThis();
					if (a.getProgram().get(a.getPointer()) instanceof Start) {
						level++;
					} else if (a.getProgram().get(a.getPointer()) instanceof End) {
						level--;
					}
					a.setPointer(a.getPointer() + 1);
				}
				if (iterationListener != null) {
					iterationListener.run();
				}
				a.setPointer(position);
			}
		}
	}
}
