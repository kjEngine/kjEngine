package de.kjEngine.core.io.va;

public class Wait implements VirtualMethod<Object> {

	public Wait() {
	}

	@Override
	public Object run(VirtualApplication a, String[] args) {
		if (args.length > 0) {
			try {
				Thread.sleep(Long.parseLong(Caster.cast(a, args[0].trim()).value.toString()));
			} catch (NumberFormatException e) {
				e.printStackTrace();
				throw new RuntimeException(e);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		return null;
	}
}
