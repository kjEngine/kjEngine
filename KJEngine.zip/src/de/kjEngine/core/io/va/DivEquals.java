package de.kjEngine.core.io.va;

public class DivEquals implements VirtualMethod<Object> {
	
	public DivEquals() {
	}

	@Override
	public Object run(VirtualApplication a, String[] args) {
		if (args.length == 2) {
			String var_s = a.getMemory().get(args[0].trim());
			double var = Double.parseDouble(var_s == null ? "0" : var_s);
			double value = Double.parseDouble(Caster.cast(a, args[1].trim()).value.toString());
			a.getMemory().put(args[0].trim(), String.valueOf(var / value));
		}
		return null;
	}
}
