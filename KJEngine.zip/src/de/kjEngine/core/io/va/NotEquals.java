package de.kjEngine.core.io.va;

public class NotEquals extends Equals {

	public NotEquals() {
	}

	@Override
	public Boolean run(VirtualApplication a, String[] args) {
		return !super.run(a, args);
	}
}
