package de.kjEngine.core.io.va;

public class StdLibery {

	public static VALib load() {
		VALib m = new VALib();
		m.put("wait", new Wait());
		m.put("print", new Print());
		m.put("set", new Set());
		m.put("delete", new Delete());
		m.put("clearMemory", new ClearMemory());
		m.put("memoryDump", new MemoryDump());
		m.put("add", new Add());
		m.put("sub", new Sub());
		m.put("mul", new Mul());
		m.put("div", new Div());
		m.put("sin", new Sin());
		m.put("cos", new Cos());
		m.put("add_equals", new AddEquals());
		m.put("sub_equals", new SubEquals());
		m.put("mul_equals", new MulEquals());
		m.put("div_equals", new DivEquals());
		m.put("modulo", new Modulo());
		m.put("equals", new Equals());
		m.put("if", new If());
		m.put("end", new End());
		m.put("while", new While());
		m.put("for", new For());
		m.put("return", new Return());
		m.put("define", new Define());
		m.put("runNew", new RunNew());
		// Overloaded operators
		m.put("=", new Set());
		m.put("+", new Add());
		m.put("-", new Sub());
		m.put("*", new Mul());
		m.put("/", new Div());
		m.put("<", new LessThan());
		m.put(">", new MoreThan());
		m.put("%", new Modulo());
		m.put("+=", new AddEquals());
		m.put("-=", new SubEquals());
		m.put("*=", new MulEquals());
		m.put("/=", new DivEquals());
		m.put("==", new Equals());
		m.put("!=", new NotEquals());
		return m;
	}
}
