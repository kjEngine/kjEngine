package de.kjEngine.core.io.va;

public class Return implements VirtualMethod<Object> {

	public Return() {
	}

	@Override
	public Object run(VirtualApplication a, String[] args) {
		return args[0];
	}
}
