package de.kjEngine.core.xvec;

public class Vector2i implements IVector {

	public int x, y;

	public Vector2i() {
		this(0, 0);
	}

	public Vector2i(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	public Vector2i(Vector2i src) {
		this(src.x, src.y);
	}

	@Override
	public int length() {
		return (int) Math.sqrt(lengthSqared());
	}

	@Override
	public int lengthSqared() {
		return x * x + y * y;
	}

	public Vector2i add(Vector2i b) {
		x += b.x;
		y += b.y;
		return this;
	}

	public Vector2i sub(Vector2i b) {
		x -= b.x;
		y -= b.y;
		return this;
	}

	public Vector2i mul(Vector2i b) {
		x *= b.x;
		y *= b.y;
		return this;
	}

	public Vector2i div(Vector2i b) {
		x /= b.x;
		y /= b.y;
		return this;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + x;
		result = prime * result + y;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Vector2i other = (Vector2i) obj;
		if (x != other.x)
			return false;
		if (y != other.y)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Vector2i [x=" + x + ", y=" + y + "]";
	}
}
