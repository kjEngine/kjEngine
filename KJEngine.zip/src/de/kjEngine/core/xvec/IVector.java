package de.kjEngine.core.xvec;

public interface IVector {
	
	int length();
	
	int lengthSqared();
}
