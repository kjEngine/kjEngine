package de.kjEngine.core.animations;

import static org.lwjgl.opengl.GL20.*;

import org.lwjgl.util.vector.Matrix4f;

import de.kjEngine.core.api.Shader;

public class AnimatedModelShader extends Shader {

	private static final int MAX_JOINTS = 50;// max number of joints in a
												// skeleton

	protected int projectionViewMatrix;
	protected int lightDirection;
	protected int[] jointTransforms;

	/**
	 * Creates the shader program for the {@link AnimatedModelRenderer} by
	 * loading up the vertex and fragment shader code files. It also gets the
	 * location of all the specified uniform variables, and also indicates that
	 * the diffuse texture will be sampled from texture unit 0.
	 */
	public AnimatedModelShader() {
		super("/de/kjEngine/core/animations/animatedEntityVertex.glsl",
				"/de/kjEngine/core/animations/animatedEntityFragment.glsl");
	}

	@Override
	protected void loadUniformLocations() {
		jointTransforms = new int[MAX_JOINTS];
		projectionViewMatrix = glGetUniformLocation(id, "projectionViewMatrix");
		for (int i = 0; i < MAX_JOINTS; i++) {
			jointTransforms[i] = glGetUniformLocation(id, "jointTransforms[" + i + "]");
		}
		lightDirection = glGetUniformLocation(id, "lightDirection");
	}

	public void loadPVMatrix(Matrix4f mat) {
		loadMatrix(projectionViewMatrix, mat);
	}
	
	public void loadJointTransforms(Matrix4f[] mats) {
		for (int i = 0; i < mats.length; i++) {
			loadMatrix(jointTransforms[i], mats[i]);
		}
	}
}
