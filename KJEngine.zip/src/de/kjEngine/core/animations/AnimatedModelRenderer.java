package de.kjEngine.core.animations;

import org.lwjgl.opengl.GL11;
import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector3f;

import de.kjEngine.core.api.Camera;
import de.kjEngine.core.mainrendering.Renderer;

/**
 * 
 * This class deals with rendering an animated entity. Nothing particularly new
 * here. The only exciting part is that the joint transforms get loaded up to
 * the shader in a uniform array.
 * 
 * @author Karl
 *
 */
public class AnimatedModelRenderer {

	private AnimatedModelShader shader;
	private Renderer parent;

	/**
	 * Initializes the shader program used for rendering animated models.
	 */
	public AnimatedModelRenderer(Renderer parent) {
		this.shader = new AnimatedModelShader();
		this.parent = parent;
	}

	/**
	 * Renders an animated entity. The main thing to note here is that all the
	 * joint transforms are loaded up to the shader to a uniform array. Also 5
	 * attributes of the VAO are enabled before rendering, to include joint
	 * indices and weights.
	 * 
	 * @param entity
	 *            - the animated entity to be rendered.
	 * @param camera
	 *            - the camera used to render the entity.
	 * @param lightDir
	 *            - the direction of the light in the scene.
	 */
	public void render(AnimatedModel entity, Camera camera, Vector3f lightDir) {
		prepare(camera, lightDir);
		entity.enable();
		shader.loadJointTransforms(entity.getJointTransforms());
		GL11.glDrawElements(GL11.GL_TRIANGLES, entity.getIndexCount(), GL11.GL_UNSIGNED_INT, 0);
		entity.disable();
		finish();
	}

	/**
	 * Deletes the shader program when the game closes.
	 */
	public void cleanUp() {
		shader.cleanUp();
	}

	/**
	 * Starts the shader program and loads up the projection view matrix, as
	 * well as the light direction. Enables and disables a few settings which
	 * should be pretty self-explanatory.
	 * 
	 * @param camera
	 *            - the camera being used.
	 * @param lightDir
	 *            - the direction of the light in the scene.
	 */
	private void prepare(Camera camera, Vector3f lightDir) {
		shader.enable();
		shader.loadPVMatrix(Matrix4f.mul(parent.getpMat(), camera.getLocation(), null));
		GL11.glEnable(GL11.GL_DEPTH_TEST);
	}

	/**
	 * Stops the shader program after rendering the entity.
	 */
	private void finish() {
		shader.disable();
	}
}
