package de.kjEngine.core.light;

import org.lwjgl.util.vector.Vector3f;
import org.lwjgl.util.vector.Vector4f;

public class SpotLight extends PositionalLight {
	
	private Vector3f direction;
	private float cutoffAngle, falloffExp;

	public SpotLight() {
		direction = new Vector3f();
	}

	public SpotLight(Vector4f ambient, Vector4f diffuse, Vector4f specular, Vector3f position, float strength,
			Vector3f direction, float cufoffAngle, float falloffExp, boolean castingShadows) {
		super(ambient, diffuse, specular, position, strength, castingShadows);
		setDirection(direction);
		setCutoffAngle(cufoffAngle);
		setFalloffExp(falloffExp);
	}

	public Vector3f getDirection() {
		return direction;
	}

	public void setDirection(Vector3f direction) {
		this.direction = direction;
	}

	public float getCutoffAngle() {
		return cutoffAngle;
	}

	public void setCutoffAngle(float cutoffAngle) {
		this.cutoffAngle = cutoffAngle;
	}

	public float getFalloffExp() {
		return falloffExp;
	}

	public void setFalloffExp(float falloffExp) {
		this.falloffExp = falloffExp;
	}
}
