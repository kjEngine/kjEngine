package de.kjEngine.core.light;

import org.lwjgl.util.vector.*;

public abstract class Light {
	
	private Vector4f ambient, diffuse, specular;
	private boolean castingShadows = false;;

	public Light() {
		ambient = new Vector4f();
		diffuse = new Vector4f();
		specular = new Vector4f();
	}

	public Light(Vector4f ambient, Vector4f diffuse, Vector4f specular, boolean castingShadows) {
		this.ambient = ambient;
		this.diffuse = diffuse;
		this.specular = specular;
		this.castingShadows = castingShadows;
	}

	public Vector4f getAmbient() {
		return ambient;
	}

	public void setAmbient(Vector4f ambient) {
		this.ambient = ambient;
	}

	public Vector4f getDiffuse() {
		return diffuse;
	}

	public void setDiffuse(Vector4f diffuse) {
		this.diffuse = diffuse;
	}

	public Vector4f getSpecular() {
		return specular;
	}

	public void setSpecular(Vector4f specular) {
		this.specular = specular;
	}

	public boolean isCastingShadows() {
		return castingShadows;
	}

	public void setCastingShadows(boolean castingShadows) {
		this.castingShadows = castingShadows;
	}
}
