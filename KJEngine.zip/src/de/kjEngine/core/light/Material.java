package de.kjEngine.core.light;

import org.lwjgl.util.vector.*;

public class Material {
	
	public static final Material STONE = new Material(new Vector4f(0.2f, 0.2f, 0.2f, 1f), new Vector4f(0.9f, 0.9f, 0.9f, 1f),
													  new Vector4f(0.01f, 0.01f, 0.01f, 0.01f), 0.5f);
	
	private Vector4f ambient, diffuse, specular;
	private float shinyness;

	public Material() {
	}

	public Material(Vector4f ambient, Vector4f diffuse, Vector4f specular, float shinyness) {
		this.ambient = ambient;
		this.diffuse = diffuse;
		this.specular = specular;
		this.shinyness = shinyness;
	}

	public Vector4f getAmbient() {
		return ambient;
	}

	public void setAmbient(Vector4f ambient) {
		this.ambient = ambient;
	}

	public Vector4f getDiffuse() {
		return diffuse;
	}

	public void setDiffuse(Vector4f diffuse) {
		this.diffuse = diffuse;
	}

	public Vector4f getSpecular() {
		return specular;
	}

	public void setSpecular(Vector4f specular) {
		this.specular = specular;
	}

	public float getShinyness() {
		return shinyness;
	}

	public void setShinyness(float shinyness) {
		this.shinyness = shinyness;
	}
	
	public Material copy() {
		return new Material(ambient, diffuse, specular, shinyness);
	}
}
