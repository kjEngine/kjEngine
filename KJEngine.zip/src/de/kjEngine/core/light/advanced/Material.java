package de.kjEngine.core.light.advanced;

import org.lwjgl.util.vector.Vector3f;

public class Material {
	
	private String name;
	private int diffusemap;
	private int normalmap;
	private int displacemap;
	private int ambientmap;
	private int specularmap;
	private int alphamap;
	private Vector3f color = new Vector3f();
	private float alpha;
	private float displaceScale;
	private float emission;
	private float shininess;
	private float horizontalScale;

	public Material() {
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the diffusemap
	 */
	public int getDiffusemap() {
		return diffusemap;
	}

	/**
	 * @param diffusemap the diffusemap to set
	 */
	public void setDiffusemap(int diffusemap) {
		this.diffusemap = diffusemap;
	}

	/**
	 * @return the normalmap
	 */
	public int getNormalmap() {
		return normalmap;
	}

	/**
	 * @param normalmap the normalmap to set
	 */
	public void setNormalmap(int normalmap) {
		this.normalmap = normalmap;
	}

	/**
	 * @return the displacemap
	 */
	public int getDisplacemap() {
		return displacemap;
	}

	/**
	 * @param displacemap the displacemap to set
	 */
	public void setDisplacemap(int displacemap) {
		this.displacemap = displacemap;
	}

	/**
	 * @return the ambientmap
	 */
	public int getAmbientmap() {
		return ambientmap;
	}

	/**
	 * @param ambientmap the ambientmap to set
	 */
	public void setAmbientmap(int ambientmap) {
		this.ambientmap = ambientmap;
	}

	/**
	 * @return the specularmap
	 */
	public int getSpecularmap() {
		return specularmap;
	}

	/**
	 * @param specularmap the specularmap to set
	 */
	public void setSpecularmap(int specularmap) {
		this.specularmap = specularmap;
	}

	/**
	 * @return the alphamap
	 */
	public int getAlphamap() {
		return alphamap;
	}

	/**
	 * @param alphamap the alphamap to set
	 */
	public void setAlphamap(int alphamap) {
		this.alphamap = alphamap;
	}

	/**
	 * @return the color
	 */
	public Vector3f getColor() {
		return color;
	}

	/**
	 * @param color the color to set
	 */
	public void setColor(Vector3f color) {
		this.color = color;
	}

	/**
	 * @return the alpha
	 */
	public float getAlpha() {
		return alpha;
	}

	/**
	 * @param alpha the alpha to set
	 */
	public void setAlpha(float alpha) {
		this.alpha = alpha;
	}

	/**
	 * @return the displaceScale
	 */
	public float getDisplaceScale() {
		return displaceScale;
	}

	/**
	 * @param displaceScale the displaceScale to set
	 */
	public void setDisplaceScale(float displaceScale) {
		this.displaceScale = displaceScale;
	}

	/**
	 * @return the emission
	 */
	public float getEmission() {
		return emission;
	}

	/**
	 * @param emission the emission to set
	 */
	public void setEmission(float emission) {
		this.emission = emission;
	}

	/**
	 * @return the shininess
	 */
	public float getShininess() {
		return shininess;
	}

	/**
	 * @param shininess the shininess to set
	 */
	public void setShininess(float shininess) {
		this.shininess = shininess;
	}

	/**
	 * @return the horizontalScale
	 */
	public float getHorizontalScale() {
		return horizontalScale;
	}

	/**
	 * @param horizontalScale the horizontalScale to set
	 */
	public void setHorizontalScale(float horizontalScale) {
		this.horizontalScale = horizontalScale;
	}
}
