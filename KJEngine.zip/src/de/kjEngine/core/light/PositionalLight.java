package de.kjEngine.core.light;

import org.lwjgl.util.vector.*;

public class PositionalLight extends Light {
	
	private Vector3f position;
	private float strength = 10f;

	public PositionalLight() {
		position = new Vector3f();
	}

	public PositionalLight(Vector4f ambient, Vector4f diffuse, Vector4f specular, Vector3f position, float strength,
			boolean castingShadows) {
		super(ambient, diffuse, specular, castingShadows);
		this.position = position;
		this.strength = strength;
	}

	public Vector3f getPosition() {
		return position;
	}

	public void setPosition(Vector3f position) {
		this.position = position;
	}

	public float getStrength() {
		return strength;
	}

	public void setStrength(float strength) {
		this.strength = strength;
	}
}
