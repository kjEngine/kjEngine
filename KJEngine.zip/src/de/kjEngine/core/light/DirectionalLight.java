package de.kjEngine.core.light;

import org.lwjgl.util.vector.*;

public class DirectionalLight extends Light {
	
	private Vector3f direction;

	public DirectionalLight() {
		direction = new Vector3f();
	}

	public DirectionalLight(Vector4f ambient, Vector4f diffuse, Vector4f specular, Vector3f direction, boolean castingShadows) {
		super(ambient, diffuse, specular, castingShadows);
		this.direction = direction;
	}

	public Vector3f getDirection() {
		return direction;
	}

	public void setDirection(Vector3f direction) {
		this.direction = direction;
	}
}
