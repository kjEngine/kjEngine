package de.kjEngine.core.particles;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL13.*;
import static org.lwjgl.opengl.GL20.*;
import static org.lwjgl.opengl.GL31.*;

import java.nio.*;
import java.util.*;

import org.lwjgl.*;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.vector.*;

import de.kjEngine.core.*;
import de.kjEngine.core.api.Cleanable;
import de.kjEngine.core.util.Loader;
import de.kjEngine.core.util.OpenGlUtils;

public class ParticleRenderer implements Cleanable {

	private static final int MAX_INSTANCES = 1000000;
	private static final int INSTANCE_DATA_LENGTH = 16;

	private static final FloatBuffer buffer = BufferUtils.createFloatBuffer(MAX_INSTANCES * INSTANCE_DATA_LENGTH);

	private ParticleShader shader;
	private int vbo;
	private int pointer = 0;

	public ParticleRenderer() {
		shader = new ParticleShader();
		vbo = Loader.createEmptyVbo(INSTANCE_DATA_LENGTH * MAX_INSTANCES);
		Loader.addInstanceAttribute(Particle.getParticleModel().getVao(), vbo, 2, 4, INSTANCE_DATA_LENGTH, 0);
		Loader.addInstanceAttribute(Particle.getParticleModel().getVao(), vbo, 3, 4, INSTANCE_DATA_LENGTH, 4);
		Loader.addInstanceAttribute(Particle.getParticleModel().getVao(), vbo, 4, 4, INSTANCE_DATA_LENGTH, 8);
		Loader.addInstanceAttribute(Particle.getParticleModel().getVao(), vbo, 5, 4, INSTANCE_DATA_LENGTH, 12);
	}

	public void render(Map<Integer, List<Particle>> particles, Matrix4f vMat, Matrix4f pMat, boolean aditiveBlending) {
		if (particles.size() > 0) {
			shader.enable();
			
			Map<Integer, List<Particle>> alpha = new HashMap<>();
			Map<Integer, List<Particle>> add = new HashMap<>();
			
			 for (Integer tex : particles.keySet()) {
				 for (Particle p : particles.get(tex)) {
					 if (p.isAdditiveBlending()) {
						 List<Particle> ps = add.get(tex);
						 if (ps == null) {
							 ps = new ArrayList<>();
							 add.put(tex, ps);
						 }
						 ps.add(p);
					 } else {
						 List<Particle> ps = alpha.get(tex);
						 if (ps == null) {
							 ps = new ArrayList<>();
							 alpha.put(tex, ps);
						 }
						 ps.add(p);
					 }
				 }
			 }

			Particle.getParticleModel().enable();
			glEnableVertexAttribArray(3);
			glEnableVertexAttribArray(4);
			glEnableVertexAttribArray(5);

			shader.loadMVMat(vMat, pMat);
			shader.inverseVMat.loadMatrix(Matrix4f.invert(vMat, null));
			shader.live.loadFloat(1f);
			
			_render(add, true);
			_render(alpha, false);

			glDisableVertexAttribArray(3);
			glDisableVertexAttribArray(4);
			glDisableVertexAttribArray(5);
			Particle.getParticleModel().disable();
			
			GL11.glDepthMask(true);

			OpenGlUtils.disableBlending();

			shader.disable();
		}
	}

	private void _render(Map<Integer, List<Particle>> particles, boolean aditiveBlending) {
		if (aditiveBlending) {
			OpenGlUtils.enableAdditiveBlending();
		} else {
			OpenGlUtils.enableAlphaBlending();
		}
		
		GL11.glDepthMask(false);

		for (int id : particles.keySet()) {

			glActiveTexture(GL_TEXTURE0);
			glBindTexture(GL_TEXTURE_2D, id);

			List<Particle> pl = particles.get(id);

			pointer = 0;
			float[] vboData = new float[pl.size() * INSTANCE_DATA_LENGTH];

			for (Particle p : pl) {
				storeMatrix(p.getTransform().getMatrix(), vboData);
			}

			Loader.updateVbo(vbo, vboData, buffer);

			glDrawElementsInstanced(GL_TRIANGLES, Particle.getParticleModel().getIndexCount(), GL_UNSIGNED_INT, 0,
					pl.size());
		}
	}

	private void storeMatrix(Matrix4f m, float[] f) {
		f[pointer++] = m.m00;
		f[pointer++] = m.m01;
		f[pointer++] = m.m02;
		f[pointer++] = m.m03;

		f[pointer++] = m.m10;
		f[pointer++] = m.m11;
		f[pointer++] = m.m12;
		f[pointer++] = m.m13;

		f[pointer++] = m.m20;
		f[pointer++] = m.m21;
		f[pointer++] = m.m22;
		f[pointer++] = m.m23;

		f[pointer++] = m.m30;
		f[pointer++] = m.m31;
		f[pointer++] = m.m32;
		f[pointer++] = m.m33;
	}

	@Override
	public void cleanUp() {
		shader.cleanUp();
		buffer.clear();
	}
}
