package de.kjEngine.core.particles;

import static org.lwjgl.opengl.GL20.*;

import org.lwjgl.util.vector.*;

import de.kjEngine.core.*;
import de.kjEngine.core.api.Shader;
import de.kjEngine.core.uniforms.UniformFloat;
import de.kjEngine.core.uniforms.UniformMat4;

public class ParticleShader extends Shader {

	private int vMatLoc, pMatLoc;
	public UniformMat4 inverseVMat;
	public UniformFloat live;

	public ParticleShader() {
		super("/de/kjEngine/core/particles/vertexShader.glsl", "/de/kjEngine/core/particles/fragmentShader.glsl");
	}

	@Override
	public void cleanUp() {
		glDeleteProgram(id);
	}

	@Override
	protected void loadUniformLocations() {
		vMatLoc = glGetUniformLocation(id, "vMat");
		pMatLoc = glGetUniformLocation(id, "pMat");
		inverseVMat = new UniformMat4(id, "inverseVMat");
		live = new UniformFloat(id, "live");
	}

	public void loadMVMat(Matrix4f vMat, Matrix4f pMat) {
		loadMatrix(vMatLoc, vMat);
		loadMatrix(pMatLoc, pMat);
	}
}
