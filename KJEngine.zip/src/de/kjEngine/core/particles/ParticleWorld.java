package de.kjEngine.core.particles;

import java.util.*;

import org.lwjgl.util.vector.*;

import de.kjEngine.core.awt.DisplayManager;
import de.kjEngine.core.model.*;
import de.kjEngine.core.particles.emitters.ParticleEmitter;

public class ParticleWorld {

	private List<Particle> particles;
	private List<Terrain> terrains = new ArrayList<>();
	private List<ParticleEmitter> emitters = new ArrayList<>();
	private List<Force> forces = new ArrayList<>();

	public ParticleWorld() {
		this(new ArrayList<>());
	}

	public ParticleWorld(List<Particle> particles) {
		this.particles = particles;
	}

	public void addTerrain(Terrain e) {
		terrains.add(e);
	}

	public void removeTerrain(Terrain e) {
		terrains.remove(e);
	}

	public void update(Vector3f camPos) {
		float delta = DisplayManager.getDelta();
		for (Particle p : particles) {
			for (Terrain terrain : terrains) {
				if (terrain != null) {
					float h = terrain.getHeightAt(p.getTransform().getTranslation().x,
							p.getTransform().getTranslation().z);
					if (p.getTransform().getTranslation().y < h) {
						p.getTransform().getTranslation().y = h + p.getTransform().getScale().x * 0.5f;
						p.getVel().y *= -0.8f;
						Vector3f normal = terrain.getNormal(p.getTransform().getTranslation().x,
								p.getTransform().getTranslation().z);
						p.getVel().x -= normal.x * p.getG().y * 20.0 * delta;
						p.getVel().z -= normal.z * p.getG().y * 20.0 * delta;
					}
				}
			}
			p.update(camPos);
		}
		for (int i = 0; i < particles.size(); i++) {
			if (!particles.get(i).isAllive())
				particles.remove(i);
		}
		for (ParticleEmitter e : emitters) {
			e.emit();
			e.update();
		}
		for (Force f : forces) {
			for (Particle p : particles) {
				f.apply(p);
			}
		}
		InsertionSort.sortHighToLow(particles);
	}

	public void render(ParticleRenderer renderer, Matrix4f vMat, Matrix4f pMat, boolean ad) {
		Map<Integer, List<Particle>> p = new HashMap<>();
		for (Particle e : particles) {
			List<Particle> batch = p.get(e.getTexture());
			if (batch == null)
				batch = new ArrayList<>();
			batch.add(e);
			p.put(e.getTexture(), batch);
		}
		renderer.render(p, vMat, pMat, ad);
	}

	/**
	 * @return
	 */
	public List<Particle> getParticles() {
		return particles;
	}

	/**
	 * @param particles
	 */
	public void setParticles(List<Particle> particles) {
		this.particles = particles;
	}

	/**
	 * @return the emitters
	 */
	public List<ParticleEmitter> getEmitters() {
		return emitters;
	}

	/**
	 * @return the forces
	 */
	public List<Force> getForces() {
		return forces;
	}
}
