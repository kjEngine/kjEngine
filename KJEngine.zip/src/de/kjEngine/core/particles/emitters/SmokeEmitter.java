package de.kjEngine.core.particles.emitters;

import java.util.HashMap;
import java.util.Map;

import org.lwjgl.util.vector.Vector3f;

import de.kjEngine.core.awt.DisplayManager;
import de.kjEngine.core.particles.Particle;
import de.kjEngine.core.particles.ParticleWorld;
import de.kjEngine.core.util.Noise;

public class SmokeEmitter extends ParticleEmitter {

	private float density;
	private Map<Particle, Noise[]> smoke = new HashMap<>();
	private float t;
	private final float spred, lift;

	public SmokeEmitter(int texture, Vector3f src, ParticleWorld world, float particleLive, float density,
			float spred, float lift) {
		super(texture, src, world, particleLive);
		setDensity(density);
		this.spred = spred;
		this.lift = lift;
	}

	/**
	 * @return the density
	 */
	public float getDensity() {
		return density;
	}

	/**
	 * @param density
	 *            the density to set
	 */
	public void setDensity(float density) {
		if (density < 0) {
			throw new IllegalArgumentException("density < 0");
		}
		this.density = density;
	}

	/**
	 * @return the spred
	 */
	public float getSpred() {
		return spred;
	}

	/**
	 * @return the lift
	 */
	public float getLift() {
		return lift;
	}

	@Override
	public void emit() {
		Particle p = new Particle(src, new Vector3f(density, density, density), new Vector3f(), new Vector3f(), texture,
				particleLive, false);
		world.getParticles().add(p);
		smoke.put(p, new Noise[] { new Noise(spred), new Noise(lift), new Noise(spred) });
	}

	@Override
	public void update() {
		for (Particle p : smoke.keySet()) {
			Noise[] n = smoke.get(p);
			Vector3f acc = new Vector3f(n[0].getNoise(0f, t) - spred * 0.5f, n[1].getNoise(0f, t) + lift,
					n[2].getNoise(0f, t * 20f) - spred * 0.5f);
			p.setG(acc);
		}
		t += DisplayManager.getDelta();
	}
}
