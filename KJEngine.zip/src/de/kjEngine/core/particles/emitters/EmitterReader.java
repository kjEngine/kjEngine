package de.kjEngine.core.particles.emitters;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Reader;

import org.lwjgl.util.vector.Vector3f;

import de.kjEngine.core.io.PropertiesFile;
import de.kjEngine.core.io.PropertiesReader;
import de.kjEngine.core.util.Loader;

public class EmitterReader implements AutoCloseable {

	private PropertiesReader r;

	public EmitterReader(String file) throws FileNotFoundException {
		r = new PropertiesReader(new File(file));
	}

	public EmitterReader(File file) throws FileNotFoundException {
		r = new PropertiesReader(file);
	}

	public EmitterReader(Reader in) {
		r = new PropertiesReader(in);
	}

	public ParticleEmitter read() throws IOException {
		PropertiesFile f = r.read();

		String shape = f.getString("shape");

		float xo = get(f, "x_off", 0f);
		float yo = get(f, "y_off", 0f);
		float zo = get(f, "z_off", 0f);
		float rate = get(f, "rate", 1f);
		float scale = get(f, "scale", 1f);
		float live = get(f, "live", 1f);
		int texture = Loader.loadTexturei(f.getString("texture"));

		return create(shape, xo, yo, zo, rate, scale, texture, live, f);
	}

	private ParticleEmitter create(String shape, float xo, float yo, float zo, float rate, float scale, int texture,
			float live, PropertiesFile f) {
		switch (shape) {
		case "circle":
			return new CircleEmitter(texture, new Vector3f(), null, live, scale, get(f, "r", 1f));
		}
		return null;
	}

	private float get(PropertiesFile f, String name, float def) {
		try {
			return f.getFloat(name);
		} catch (Exception e) {
		}
		return def;
	}

	@Override
	public void close() throws IOException {
		r.close();
	}
}
