package de.kjEngine.core.particles.emitters;

import java.util.ArrayList;
import java.util.List;

import org.lwjgl.util.vector.Vector3f;

import de.kjEngine.core.particles.Particle;
import de.kjEngine.core.particles.ParticleWorld;

public abstract class ParticleEmitter {
	
	protected int texture;
	protected Vector3f src;
	protected ParticleWorld world;
	protected float particleLive;
	protected List<Particle> particles = new ArrayList<>();

	public ParticleEmitter(int texture, Vector3f src, ParticleWorld world, float particleLive) {
		setTexture(texture);
		setSrc(src);
		this.world = world;
		setParticleLive(particleLive);
	}

	/**
	 * @return the texture
	 */
	public int getTexture() {
		return texture;
	}

	/**
	 * @param texture the texture to set
	 */
	public void setTexture(int texture) {
		this.texture = texture;
	}

	/**
	 * @return the src
	 */
	public Vector3f getSrc() {
		return src;
	}

	/**
	 * @param src the src to set
	 */
	public void setSrc(Vector3f src) {
		this.src = src;
	}
	
	/**
	 * @return the world
	 */
	public ParticleWorld getWorld() {
		return world;
	}

	public void setWorld(ParticleWorld world) {
		this.world = world;
	}

	/**
	 * @return the particleLive
	 */
	public float getParticleLive() {
		return particleLive;
	}

	/**
	 * @param particleLive the particleLive to set
	 */
	public void setParticleLive(float particleLive) {
		if (particleLive < 0) {
			throw new IllegalArgumentException("particleLive < 0");
		}
		this.particleLive = particleLive;
	}

	public List<Particle> getParticles() {
		return particles;
	}

	public abstract void emit();
	public abstract void update();
}
