package de.kjEngine.core.particles.emitters;

import java.util.ArrayList;
import java.util.List;

import org.lwjgl.util.vector.Vector3f;

import de.kjEngine.core.particles.Force;
import de.kjEngine.core.particles.Particle;
import de.kjEngine.core.particles.ParticleWorld;

public class RockerExhaustEmitter extends ParticleEmitter {

	private Vector3f dir;
	private float width;
	private List<Force> forces = new ArrayList<>();

	public RockerExhaustEmitter(int texture, Vector3f src, ParticleWorld world, float particleLive, Vector3f dir, float width) {
		super(texture, src, world, particleLive);
		setDir(dir);
		setWidth(width);
		Vector3f ray = new Vector3f(dir.x, dir.y, dir.z);
		ray.normalise();
		Vector3f cp = new Vector3f(src.x, src.y, src.z);
		Vector3f mcp = new Vector3f(src.x, src.y, src.z);
		for (int i = 0; i < particleLive; i++) {
			forces.add(new Force(cp, width / (i + 1f)));
			forces.add(new Force(mcp, width / (i + 1f)));
			Vector3f.add(cp, ray, cp);
			Vector3f.sub(mcp, ray, mcp);
		}
		world.getForces().addAll(forces);
	}

	/**
	 * @return the dir
	 */
	public Vector3f getDir() {
		return dir;
	}

	/**
	 * @param dir
	 *            the dir to set
	 */
	public void setDir(Vector3f dir) {
		this.dir = dir;
	}

	/**
	 * @return the width
	 */
	public float getWidth() {
		return width;
	}

	/**
	 * @param width the width to set
	 */
	public void setWidth(float width) {
		this.width = width;
		for (Force f : forces) {
			f.setStrength(width);
		}
	}

	@Override
	public void emit() {
		Vector3f vel = new Vector3f(dir.x, dir.y, dir.z);
		vel.normalise();
		vel.scale(5f);
		vel.x += (Math.random() - 0.5) * 0.1;
		vel.y += (Math.random() - 0.5) * 0.1;
		vel.z += (Math.random() - 0.5) * 0.1;
		Particle p = new Particle(src, new Vector3f(0.1f, 0.1f, 0.1f), vel, new Vector3f(), texture, particleLive,
				true);
		world.getParticles().add(p);
	}

	@Override
	public void update() {
	}
}
