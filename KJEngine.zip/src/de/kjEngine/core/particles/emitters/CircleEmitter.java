package de.kjEngine.core.particles.emitters;

import org.lwjgl.util.vector.Vector3f;

import de.kjEngine.core.particles.Particle;
import de.kjEngine.core.particles.ParticleWorld;

public class CircleEmitter extends ParticleEmitter {

	private float r, scl;

	public CircleEmitter(int texture, Vector3f src, ParticleWorld world, float particleLive, float p_scale, float r) {
		super(texture, src, world, particleLive);
		setR(r);
		scl = p_scale;
	}

	public float getR() {
		return r;
	}

	public void setR(float r) {
		this.r = r;
	}

	@Override
	public void emit() {
		float a = (float) (Math.random() * Math.PI * 2f);
		float d = (float) (Math.random() * r);
		Vector3f n_pos = new Vector3f((float) Math.cos(a), 0f, (float) Math.sin(a));
		n_pos.scale(d);
		Vector3f.add(n_pos, getSrc(), n_pos);
		Particle p = new Particle(n_pos, new Vector3f(scl, scl, scl), new Vector3f(), new Vector3f(0f, 1f, 0f), texture,
				particleLive, true);
		world.getParticles().add(p);
		particles.add(p);
	}

	@Override
	public void update() {
	}
}
