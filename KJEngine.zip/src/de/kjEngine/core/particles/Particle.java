package de.kjEngine.core.particles;

import org.lwjgl.util.vector.*;

import de.kjEngine.core.*;
import de.kjEngine.core.api.Entity;
import de.kjEngine.core.awt.DisplayManager;
import de.kjEngine.core.model.*;
import de.kjEngine.core.util.KTexture;
import de.kjEngine.core.util.Loader;

public class Particle extends Entity {

	private static Model model;
	private Vector3f vel, g;
	private int texture;
	private float remainingLive;
	private float distFromCam;
	private boolean additiveBlending;

	public static void init() {
		model = Loader.loadModel3D(new float[] { -1f, 1f, 0f, -1f, -1f, 0f, 1f, -1f, 0f, 1f, 1f, 0f },
				new float[] { 0f, 0f, 0f, 1f, 1f, 1f, 1f, 0f }, null, new int[] { 0, 1, 2, 2, 3, 0 }, new KTexture(0),
				"particle");
	}

	public static Model getParticleModel() {
		return model;
	}

	public Particle(int texture, float live) {
		this(new Vector3f(), new Vector3f(1f, 1f, 1f), new Vector3f(), new Vector3f(), texture, live, false);
	}

	public Particle(Vector3f position, Vector3f scale, Vector3f vel, Vector3f g, int texture, float live, boolean ab) {
		super(position, 0f, 0f, 0f, scale, model);
		this.vel = vel;
		this.g = g;
		this.texture = texture;
		remainingLive = live;
		setAdditiveBlending(ab);
	}

	public void update(Vector3f camPos) {
		float delta = DisplayManager.getDelta();
		Vector3f.add(vel, new Vector3f(g.x * delta, g.y * delta, g.z * delta), vel);
		if (getTransform().getTranslation().y < 0.0)
			vel.y *= -0.8;
		getTransform().setTranslation(Vector3f.add(getTransform().getTranslation(),
				new Vector3f(vel.x * delta, vel.y * delta, vel.z * delta), null));
		remainingLive -= delta;
		updateCamDist(camPos);
	}

	private void updateCamDist(Vector3f camPos) {
		distFromCam = Vector3f.sub(camPos, getTransform().getTranslation(), null).lengthSquared();
	}

	public Vector3f getVel() {
		return vel;
	}

	public void setVel(Vector3f vel) {
		this.vel = vel;
	}

	public Vector3f getG() {
		return g;
	}

	public void setG(Vector3f g) {
		this.g = g;
	}

	public int getTexture() {
		return texture;
	}

	public void setTexture(int texture) {
		this.texture = texture;
	}

	public float getRemainingLive() {
		return remainingLive;
	}

	public void setRemainingLive(float remainingLive) {
		this.remainingLive = remainingLive;
	}

	public boolean isAllive() {
		return remainingLive > 0;
	}

	public float getDistFromCam() {
		return distFromCam;
	}

	/**
	 * @return the additiveBlending
	 */
	public boolean isAdditiveBlending() {
		return additiveBlending;
	}

	/**
	 * @param additiveBlending
	 *            the additiveBlending to set
	 */
	public void setAdditiveBlending(boolean additiveBlending) {
		this.additiveBlending = additiveBlending;
	}
}
