package de.kjEngine.core.particles;

import org.lwjgl.util.vector.Vector3f;

import de.kjEngine.core.awt.DisplayManager;

public class Force {
	
	private Vector3f pos;
	private float strength;

	public Force(Vector3f pos, float strength) {
		setPos(pos);
		setStrength(strength);
	}

	/**
	 * @return the pos
	 */
	public Vector3f getPos() {
		return pos;
	}

	/**
	 * @param pos the pos to set
	 */
	public void setPos(Vector3f pos) {
		this.pos = pos;
	}

	/**
	 * @return the strength
	 */
	public float getStrength() {
		return strength;
	}

	/**
	 * @param strength the strength to set
	 */
	public void setStrength(float strength) {
		this.strength = strength;
	}
	
	public void apply(Particle p) {
		Vector3f v = p.getTransform().getTranslation();
		Vector3f dir = Vector3f.sub(v, pos, null);
		float dsq = dir.lengthSquared();
		dir.scale((strength * DisplayManager.getDelta()) / dsq);
		Vector3f.add(p.getVel(), dir, p.getVel());
	}
}
