package de.kjEngine.core.awt;

import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;

public class KCurser {

	private static Gui currentLabel;

	public static Gui getCurrentLabel() {
		return currentLabel;
	}

	public static void setCurrentLabel(Gui currentLabel) {
		if (currentLabel != null)
			DisplayManager.getRootPanel().removeElement(currentLabel);
		KCurser.currentLabel = currentLabel;
		DisplayManager.getRootPanel().add(currentLabel);
	}

	public static void update() {
		float mx = ((float) Mouse.getX() / (float) Display.getWidth()) * 2f - 1f;
		float my = ((float) Mouse.getY() / (float) Display.getHeight()) * 2f - 1f;

		if (currentLabel != null) {
			currentLabel.setPosition(mx, my);
		}
	}
}
