package de.kjEngine.core.awt.rendering;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL13.*;

import java.util.ArrayList;
import java.util.List;

import org.lwjgl.util.vector.*;

import de.kjEngine.core.*;
import de.kjEngine.core.api.Cleanable;
import de.kjEngine.core.awt.font.FontRenderer;
import de.kjEngine.core.model.*;
import de.kjEngine.core.util.Axis;
import de.kjEngine.core.util.KTexture;
import de.kjEngine.core.util.Loader;
import de.kjEngine.core.util.OpenGlUtils;

/**
 * This handles the rendering of guis.
 * 
 * @author konst_df8d75v
 *
 */
public class GuiRenderer implements Cleanable {

	private Model quad;
	private GuiShader shader;
	private FontRenderer fontRenderer;
	private static Matrix4f IDENTITY = Matrix4f.setIdentity(new Matrix4f());
	private List<RenderingRequest> requests = new ArrayList<>();

	/**
	 * Initializes the guiRenderer. The quad model will be created and the shader as
	 * well.
	 */
	public GuiRenderer() {
		quad = Loader.loadModel3D(new float[] { 0f, 0f, 0f, 1f, 0f, 0f, 1f, 1f, 0f, 0f, 1f, 0f },
				new float[] { 0f, 1f, 1f, 1f, 1f, 0f, 0f, 0f }, null, new int[] { 0, 1, 2, 2, 3, 0 }, new KTexture(0),
				"ui");
		shader = new GuiShader();
		fontRenderer = new FontRenderer();
	}

	/**
	 * Renders an image/gui.
	 * 
	 * @param x      the target x position of the image.
	 * @param y      the target y position of the image.
	 * @param width  the target width of the image.
	 * @param height the target height of the image.
	 * @param image  the id of the texture of the image.
	 */
	public void renderImage(float x, float y, float width, float height, int image, Rectangle clip, float alpha) {
		shader.enable();
		quad.enable();

		glDisable(GL_DEPTH_TEST);

		OpenGlUtils.enableAlphaBlending();

		Matrix4f mat = Matrix4f.setIdentity(new Matrix4f());
		mat.translate(new Vector2f(x, y));
		mat.scale(new Vector3f(width, height, 1f));

		shader.loadTransforms(mat);
		shader.loadClipPlane(clip);
		shader.loadDisplayBounds();
		shader.loadAlpha(alpha);

		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, image);

		glDrawElements(GL_TRIANGLES, quad.getIndexCount(), GL_UNSIGNED_INT, 0);

		glEnable(GL_DEPTH_TEST);

		OpenGlUtils.disableBlending();

		quad.disable();
		shader.disable();
//		requests.add(new RenderingRequest(x, y, width, height, image, clip, alpha, 0f, false, false));
	}

	public void renderImage(float x, float y, float width, float height, int image, Rectangle clip, float alpha,
			float rot, boolean centered) {
		shader.enable();
		quad.enable();

		glDisable(GL_DEPTH_TEST);

		OpenGlUtils.enableAlphaBlending();

		Matrix4f mat = Matrix4f.setIdentity(new Matrix4f());
		mat.translate(new Vector2f(x, y));
		mat.scale(new Vector3f(width, height, 1f));
		mat.rotate(rot, Axis.Z);
		if (centered) {
			mat.translate(new Vector2f(-0.5f, -0.5f));
		}

		shader.loadTransforms(mat);
		shader.loadClipPlane(clip);
		shader.loadDisplayBounds();
		shader.loadAlpha(alpha);

		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, image);

		glDrawElements(GL_TRIANGLES, quad.getIndexCount(), GL_UNSIGNED_INT, 0);

		glEnable(GL_DEPTH_TEST);

		OpenGlUtils.disableBlending();

		quad.disable();
		shader.disable();
//		requests.add(new RenderingRequest(x, y, width, height, image, clip, alpha, rot, centered, false));
	}
	
	public void renderImage(float x, float y, float width, float height, int image, Rectangle clip, float alpha,
			float rot, boolean centered, float w_scl, float h_scl) {
		shader.enable();
		quad.enable();

		glDisable(GL_DEPTH_TEST);

		OpenGlUtils.enableAlphaBlending();

		Matrix4f mat = Matrix4f.setIdentity(new Matrix4f());
		mat.translate(new Vector2f(x, y));
		mat.scale(new Vector3f(width, height, 1f));
		mat.rotate(rot, Axis.Z);
		mat.scale(new Vector3f(w_scl, h_scl, 1f));
		if (centered) {
			mat.translate(new Vector2f(-0.5f, -0.5f));
		}

		shader.loadTransforms(mat);
		shader.loadClipPlane(clip);
		shader.loadDisplayBounds();
		shader.loadAlpha(alpha);

		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, image);

		glDrawElements(GL_TRIANGLES, quad.getIndexCount(), GL_UNSIGNED_INT, 0);

		glEnable(GL_DEPTH_TEST);

		OpenGlUtils.disableBlending();

		quad.disable();
		shader.disable();
	}

	public void renderImageWithAdditiveBlending(float x, float y, float width, float height, int image, Rectangle clip,
			float alpha) {
		shader.enable();
		quad.enable();

		glDisable(GL_DEPTH_TEST);

		OpenGlUtils.enableAdditiveBlending();

		Matrix4f mat = Matrix4f.setIdentity(new Matrix4f());
		mat.translate(new Vector2f(x, y));
		mat.scale(new Vector3f(width, height, 1f));

		shader.loadTransforms(mat);
		shader.loadClipPlane(clip);
		shader.loadDisplayBounds();
		shader.loadAlpha(alpha);

		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, image);

		glDrawElements(GL_TRIANGLES, quad.getIndexCount(), GL_UNSIGNED_INT, 0);

		glEnable(GL_DEPTH_TEST);

		OpenGlUtils.disableBlending();

		quad.disable();
		shader.disable();
//		requests.add(new RenderingRequest(x, y, width, height, image, clip, alpha, 0f, false, true));
	}

	public void drawLine(float x0, float y0, float x1, float y1, int color) {
		drawLine(x0, y0, x1, y1, color, IDENTITY);
	}

	public void drawLine(float x0, float y0, float x1, float y1, int color, Matrix4f transform) {
		shader.enable();

		Model m = Loader.loadModel3D(new float[] { x0, y0, 0f, x1, y1, 0f }, new float[] { 0f, 0f, 0f, 0f },
				new float[] { 0f, 0f, 0f, 0f, 0f, 0f }, new int[] { 0, 1 }, null, "line");
		m.enable();

		glDisable(GL_DEPTH_TEST);

		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

		shader.loadTransforms(transform);
		shader.loadClipPlane(new Rectangle(-1f, -1f, 2f, 2f));

		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, color);

		glDrawElements(GL_LINES, m.getIndexCount(), GL_UNSIGNED_INT, 0);

		glEnable(GL_DEPTH_TEST);

		glDisable(GL_BLEND);

		m.disable();
		m.cleanUp();
		shader.disable();
	}

	/**
	 * @return The FontRenderer that is 'build in' the GuiRenderer.
	 */
	public FontRenderer getFontRenderer() {
		return fontRenderer;
	}

	public void pollRequests() {
		prepare();
		boolean lastbm = false;
		Rectangle lastclip = null;
		float lastAlpha = 0;
		int lastTexture = 0;
		OpenGlUtils.enableAlphaBlending();
		for (RenderingRequest r : requests) {
			if (lastclip == null) {
				lastclip = r.clip;
				shader.loadClipPlane(r.clip);
			}
			if (r.additive != lastbm) {
				if (r.additive) {
					OpenGlUtils.enableAdditiveBlending();
				} else {
					OpenGlUtils.enableAlphaBlending();
				}
				lastbm = r.additive;
			}
			Matrix4f mat = Matrix4f.setIdentity(new Matrix4f());
			mat.translate(new Vector2f(r.x, r.y));
			mat.scale(new Vector3f(r.width, r.height, 1f));
			mat.rotate(r.rot, Axis.Z);
			if (r.centered) {
				mat.translate(new Vector2f(-0.5f, -0.5f));
			}

			shader.loadTransforms(mat);
			if (!lastclip.equals(r.clip)) {
				shader.loadClipPlane(r.clip);
				lastclip = r.clip;
			}
			if (r.alpha != lastAlpha) {
				shader.loadAlpha(r.alpha);
				lastAlpha = r.alpha;
			}
			if (r.texture != lastTexture) {
				glActiveTexture(GL_TEXTURE0);
				glBindTexture(GL_TEXTURE_2D, r.texture);
				lastTexture = r.texture;
			}

			glDrawElements(GL_TRIANGLES, quad.getIndexCount(), GL_UNSIGNED_INT, 0);
		}

		end();
		requests.clear();

	}

	private void end() {
		glEnable(GL_DEPTH_TEST);

		OpenGlUtils.disableBlending();

		quad.disable();
		shader.disable();
	}

	private void prepare() {
		shader.enable();
		quad.enable();

		glDisable(GL_DEPTH_TEST);

		shader.loadDisplayBounds();
	}

	/**
	 * Deletes the guiRendering shaders.
	 */
	@Override
	public void cleanUp() {
		shader.cleanUp();
		fontRenderer.cleanUp();
	}
}
