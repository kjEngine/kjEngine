package de.kjEngine.core.awt.rendering;

import de.kjEngine.core.model.Rectangle;

class RenderingRequest {
	
	float x, y, width, height;
	int texture;
	Rectangle clip;
	float alpha, rot;
	boolean centered;
	boolean additive;

	public RenderingRequest() {
	}

	public RenderingRequest(float x, float y, float width, float height, int texture, Rectangle clip, float alpha,
			float rot, boolean centered, boolean additive) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		this.texture = texture;
		this.clip = clip;
		this.alpha = alpha;
		this.rot = rot;
		this.centered = centered;
		this.additive = additive;
	}
}
