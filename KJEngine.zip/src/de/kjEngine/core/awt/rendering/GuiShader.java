package de.kjEngine.core.awt.rendering;

import static org.lwjgl.opengl.GL20.*;

import org.lwjgl.opengl.Display;
import org.lwjgl.util.vector.Matrix4f;

import de.kjEngine.core.api.Shader;
import de.kjEngine.core.model.Rectangle;

/**
 * This handles the shaderProgramm for rendering guis.
 * 
 * @author konst_df8d75v
 */
public class GuiShader extends Shader {

	private int mMatLoc;
	private int cpxLoc, cpyLoc, cpwLoc, cphLoc;
	private int widthLoc, heightLoc;
	private int alphaLoc;

	public GuiShader() {
		super("/de/kjEngine/core/awt/rendering/vertexShader.glsl",
				"/de/kjEngine/core/awt/rendering/fragmentShader.glsl");
	}

	/**
	 * Deletes the shader.
	 */
	@Override
	public void cleanUp() {
		glDeleteProgram(id);
	}

	/**
	 * Loads the locations of the uniform variables.
	 */
	@Override
	protected void loadUniformLocations() {
		mMatLoc = glGetUniformLocation(id, "mMat");
		loadClipAttribbs();
		loadDisplayBoundUniforms();
		alphaLoc = glGetUniformLocation(id, "alpha");
	}

	/**
	 * Loads the uniform locations of the attributes of the 'clip plane'.
	 */
	private void loadClipAttribbs() {
		cpxLoc = glGetUniformLocation(id, "clip.x");
		cpyLoc = glGetUniformLocation(id, "clip.y");
		cpwLoc = glGetUniformLocation(id, "clip.width");
		cphLoc = glGetUniformLocation(id, "clip.height");
	}

	/**
	 * Loads the uniform locations of the display bounds uniforms.
	 */
	private void loadDisplayBoundUniforms() {
		widthLoc = glGetUniformLocation(id, "width");
		heightLoc = glGetUniformLocation(id, "height");
	}

	/**
	 * Loads the transforms that will be applied to the gui.
	 * 
	 * @param mat The Matrix4f that will hold the transforms.
	 */
	public void loadTransforms(Matrix4f mat) {
		loadMatrix(mMatLoc, mat);
	}

	/**
	 * Loads the attributes of the clip plane;
	 * 
	 * @param r
	 */
	public void loadClipPlane(Rectangle r) {
		loadFloat(cpxLoc, r.x);
		loadFloat(cpyLoc, r.y);
		loadFloat(cpwLoc, r.width);
		loadFloat(cphLoc, r.height);
	}

	/**
	 * Loads the bounds of the display to the shader.
	 */
	public void loadDisplayBounds() {
		loadFloat(widthLoc, 1f / Display.getWidth());
		loadFloat(heightLoc, 1f / Display.getHeight());
	}

	public void loadAlpha(float a) {
		loadFloat(alphaLoc, a);
	}
}
