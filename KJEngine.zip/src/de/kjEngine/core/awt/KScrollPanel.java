package de.kjEngine.core.awt;

import de.kjEngine.core.awt.event.ChangeListener;
import de.kjEngine.core.awt.event.KEventListener;
import de.kjEngine.core.awt.event.KEventSheduler;
import de.kjEngine.core.awt.event.KScrollBarListener;
import de.kjEngine.core.model.Rectangle;

public class KScrollPanel extends KPanel {

	private KScrollBar scroller;
	private float factor = 1f;

	public KScrollPanel() {
		this(0f, 0f, 0f, 0f);
	}

	public KScrollPanel(float x, float y, float width, float height, float r, float g, float b, float a) {
		super(x, y, width, height, r, g, b, a);
		init();
	}

	public KScrollPanel(float x, float y, float width, float height, KColor fg) {
		super(x, y, width, height, fg);
		init();
	}

	public KScrollPanel(float x, float y, float width, float height) {
		super(x, y, width, height);
		init();
	}

	private void init() {
		scroller = new KScrollBar(width - 0.03f, 0f, 0.03f, height);
		scroller.setValue(1f);
		scroller.addKScrollBarListener(new KScrollBarListener() {

			float lastValue = 1f;

			@Override
			public void valueChanged(float value) {
				float diff = value - lastValue;
				lastValue = value;

				for (Gui g : KScrollPanel.this.elements) {
					if (!g.equals(scroller) && !g.getCode().contains(Codes.NOT_MOVABLE_BY_SCROLL_PANEL)) {
						g.y -= diff * factor;
					}
				}
			}
		});
		scroller.setVisible(true);
		addStatic(scroller);

		addEVListener(new KEventListener() {

			@Override
			public void mouseReleased() {
			}

			@Override
			public void mousePressed() {
			}

			@Override
			public void mouseMoved(int dx, int dy) {
			}

			@Override
			public void mouseDragged(int dx, int dy) {
			}

			@Override
			public void mouseClicked() {
			}

			@Override
			public void keyTyped(int key) {
			}

			@Override
			public void keyReleased(int key) {
			}

			@Override
			public void keyPressed(int key) {
			}

			@Override
			public void mouseWheelMoved(int d) {
				if (!isVisible()) {
					return;
				}

				if (isFocused()) {
					scroller.setValue(scroller.getValue() + d * 0.05f * factor);
					KEventSheduler.stop();
				}
			}
		});

		addChangeListener(new ChangeListener() {

			@Override
			public void resize(float width, float height) {
				setClip(getAbsoluteBounds());
			}

			@Override
			public void move(float x, float y) {
				setClip(getAbsoluteBounds());
			}
		});
	}

	/**
	 * @return the scroller
	 */
	public KScrollBar getScroller() {
		return scroller;
	}

	@Override
	public void add(Gui e) {
		e.setClip(getClip());
		super.add(e);
	}

	public void addStatic(Gui e) {
		e.getCode().add(Codes.NOT_MOVABLE_BY_SCROLL_PANEL);
		super.add(e);
	}

	public float getFactor() {
		return factor;
	}

	public void setFactor(float factor) {
		this.factor = factor;
	}

	@Override
	public void setClip(Rectangle clip) {
		this.clip = clip;
		for (Gui g : elements) {
			if (!g.getCode().contains(Codes.NOT_MOVABLE_BY_SCROLL_PANEL)) {
				g.setClip(clip);
			}
		}
	}
}
