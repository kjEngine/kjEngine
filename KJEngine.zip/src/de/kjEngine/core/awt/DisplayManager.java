package de.kjEngine.core.awt;

import java.util.ArrayList;
import java.util.List;

import org.lwjgl.LWJGLException;
import org.lwjgl.Sys;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import org.lwjgl.util.vector.Vector2f;

import de.kjEngine.core.api.Console;
import de.kjEngine.core.audio.AudioMaster;
import de.kjEngine.core.awt.event.FrameListener;
import de.kjEngine.core.awt.event.InputHandler;
import de.kjEngine.core.particles.Particle;
import de.kjEngine.core.postProcessing.PostProcessing;
import de.kjEngine.core.util.KJEngineException;
import de.kjEngine.core.xvec.Vector2i;

/**
 * This handles the Display.
 * 
 * @author konst_df8d75v
 *
 */
public class DisplayManager {

	private static int frames = 0, fps = 0;
	private static long time = System.currentTimeMillis();
	private static KRootPanel rootPanel;
	private static long lastFrameTime;
	private static float delta = 0f;
	private static List<FrameListener> frameListeners = new ArrayList<>();

	/**
	 * Creates a new Display.
	 * 
	 * @param width  the width of the Display.
	 * @param height the height of the Display.
	 * @param title  the title of the Display.
	 * @throws KJEngineException gets thrown when the Display could not be created.
	 */
	public static void create(int width, int height, String title, boolean resizable, boolean console)
			throws KJEngineException {
		try {
			Display.setResizable(resizable);
			Display.setDisplayMode(new DisplayMode(width, height));
			Display.setTitle(title);
			Display.create();
		} catch (LWJGLException e) {
			throw new KJEngineException("Could not create display!");
		}

		AudioMaster.init();

		if (console) {
			Console.init(width, height, title, resizable);
			// System.setOut(new PrintStream(Console.getOut()));
			// System.setErr(new PrintStream(Console.getOut()));
		}

		System.gc();

		Particle.init();
		InputHandler.start();
		KColor.init();
		PostProcessing.init();

		System.gc();

		rootPanel = new KRootPanel(-1f, -1f, 0f, 0f);
		rootPanel.setVisible(true);

		// glEnable(GL_CLIP_DISTANCE0);

		lastFrameTime = getCurrentTime();

		update();
	}

	/**
	 * Swaps the buffers of the Display.
	 * 
	 * @throws KJEngineException gets thrown when the Display does not exist.
	 */
	public static void update() throws KJEngineException {
		if (!Display.isCreated()) {
			throw new KJEngineException("Display has not been created!");
		}

		Display.update();
		frames++;
		calcFps();
		calcDelta();
		for (FrameListener l : frameListeners) {
			l.frame(delta);
		}
	}

	private static void calcFps() {
		if (System.currentTimeMillis() - time > 1000) {
			fps = frames;
			frames = 0;
			time += 1000;
		}
	}

	private static void calcDelta() {
		long currentFrameTime = getCurrentTime();
		delta = (currentFrameTime - lastFrameTime) * 0.001f;
		lastFrameTime = getCurrentTime();
	}

	/**
	 * Destroys the Display.
	 */
	public static void destroy() {
		Display.destroy();
		AudioMaster.cleanUp();
	}

	/**
	 * @return the rate on which update is called.
	 */
	public static int getFps() {
		return fps;
	}

	/**
	 * @return The aspect ratio of the Display.
	 */
	public static float getAspect() {
		return ((float) Display.getWidth() / (float) Display.getHeight());
	}

	/**
	 * @return The rootPanel of the Display.
	 */
	public static KRootPanel getRootPanel() {
		return rootPanel;
	}

	/**
	 * @return The current time of the Display in milliseconds.
	 */
	public static long getCurrentTime() {
		return (Sys.getTime() * 1000) / Sys.getTimerResolution();
	}

	/**
	 * @return The delta time that the last frame has taken.
	 */
	public static float getDelta() {
		return delta;
	}

	public static Vector2f toGLCoords(int x, int y) {
		return new Vector2f((float) x / (float) Display.getWidth() * 2f - 1f,
				(float) (y) / (float) Display.getHeight() * 2f - 1f);
	}

	public static Vector2i toPixelCoords(float x, float y) {
		return new Vector2i((int) ((x * 0.5f + 0.5f) * Display.getWidth()),
				(int) ((y * 0.5f + 0.5f) * Display.getHeight()));
	}

	public static void addFrameListener(FrameListener l) {
		frameListeners.add(l);
	}

	public static void removeFrameListener(FrameListener l) {
		frameListeners.remove(l);
	}
}
