package de.kjEngine.core.awt;

import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;

import de.kjEngine.core.awt.event.ResizeListener;
import de.kjEngine.core.awt.font.FontType;
import de.kjEngine.core.awt.font.GUIText;
import de.kjEngine.core.awt.font.Text;
import de.kjEngine.core.awt.font.TextMeshCreator;
import de.kjEngine.core.awt.rendering.GuiRenderer;

public abstract class KTextContainer extends Gui {

	protected Text text;
	protected float fontSize = 0.02f;
	protected boolean centered = true, clamped = false;
	protected FontType font = FontType.ARIAL;
	protected Vector3f fontColor = GuiManager.getDefaultFontColor();

	public KTextContainer() {
		this(0f, 0f, 0f, 0f);
	}

	public KTextContainer(float x, float y, float width, float height) {
		super(x, y, width, height);
		addResizeListener(new ResizeListener() {

			@Override
			public void resize(float width, float height) {
				if (text != null) {
					setText(text.getText().getTextString());
				}
			}
		});
	}

	public Text getText() {
		return text;
	}

	public void setText(String text) {
		if (centered) {
			this.text = new Text(font, new GUIText(text, fontSize, font, new Vector2f(), 1f, centered, clamped));
		} else {
			this.text = new Text(font,
					new GUIText(text, fontSize, font, new Vector2f(), width * 0.5f, centered, clamped));
		}
		this.text.getText().setColour(fontColor.x, fontColor.y, fontColor.z);
	}

	public float getFontSize() {
		return fontSize;
	}

	public void setFontSize(float fontSize) {
		this.fontSize = fontSize;
	}

	public boolean isCentered() {
		return centered;
	}

	public void setCentered(boolean centered) {
		this.centered = centered;
	}

	public FontType getFont() {
		return font;
	}

	public void setFont(FontType font) {
		this.font = font;
	}

	public void setText(float size, FontType font, String text) {
		setText(size, font, true, text);
	}

	public void setToDefaultFontColor() {
		fontColor = GuiManager.getDefaultFontColor();
	}

	public Vector3f getFontColor() {
		return fontColor;
	}

	public void setFontColor(Vector3f fontColor) {
		this.fontColor = fontColor;
	}

	public boolean isClamped() {
		return clamped;
	}

	public void setClamped(boolean clamped) {
		this.clamped = clamped;
	}

	public void setText(float size, FontType font, boolean centered, String text) {
		setFontSize(size);
		setFont(font);
		setCentered(centered);
		setText(text);
	}

	public void updateText() {
		float x = getAbsolutePosition().x;
		float y = getAbsolutePosition().y;

		if (text != null) {
			if (text.getText() != null) {
				if (text.getText().isCentered()) {
					text.getText().setPosition(new Vector2f(x + width * 0.5f, (float) ((y - 1f) + height * 0.5f
							+ text.getText().getFontSize() * 1f * TextMeshCreator.LINE_HEIGHT)));
				} else {
					text.getText().setPosition(new Vector2f(x + 1f, (float) ((y - 1f) + height)));
				}
			}
		}
	}

	public void renderText(GuiRenderer renderer) {
		if (!isVisible())
			return;
		if (text != null)
			renderer.getFontRenderer().render(text, getClip());
	}
}
