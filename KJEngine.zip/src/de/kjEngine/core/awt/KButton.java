package de.kjEngine.core.awt;

import java.util.ArrayList;
import java.util.List;

import org.lwjgl.util.vector.Vector4f;

import de.kjEngine.core.awt.css.CSSAttribute;
import de.kjEngine.core.awt.css.CSSFile;
import de.kjEngine.core.awt.event.KButtonController;
import de.kjEngine.core.awt.event.KButtonListener;
import de.kjEngine.core.awt.event.KEventListener;
import de.kjEngine.core.awt.event.KEventSheduler;
import de.kjEngine.core.awt.event.KResetListener;
import de.kjEngine.core.awt.rendering.GuiRenderer;
import de.kjEngine.core.util.Loader;

public class KButton extends KTextContainer {

	private List<KButtonListener> listeners = new ArrayList<>();
	private boolean hovering = false;
	private boolean pressed = false;
	private KResetListener resetListener;

	public KButton() {
		this(0, 0, 0, 0);
	}

	public KButton(float x, float y, float width, float height, float r, float g, float b, float a, KButtonListener l) {
		this(x, y, width, height);
		setBackground(Loader.loadColorToTexture(new Vector4f(r, g, b, a)));
		setForeground(Loader.loadColorToTexture(new Vector4f(r, g, b, a)));
		if (l != null)
			addKButtonListener(l);
		setVisible(true);
	}

	public KButton(float x, float y, float width, float height, KColor fg, KButtonListener l) {
		this(x, y, width, height);
		setBackground(fg.getId());
		setForeground(fg.getId());
		if (l != null)
			addKButtonListener(l);
		setVisible(true);
	}

	public KButton(float x, float y, float width, float height, int fg, KButtonListener l) {
		this(x, y, width, height);
		setBackground(fg);
		setForeground(fg);
		if (l != null)
			addKButtonListener(l);
		setVisible(true);
	}

	public KButton(float x, float y, float width, float height) {
		super(x, y, width, height);
		addKButtonListener(new KButtonListener() {

			@Override
			public void exited(Gui gui) {
				setForeground(KColor.GRAY_05.getId());
			}

			@Override
			public void entered(Gui gui) {
				setForeground(KColor.GRAY_06.getId());
			}

			@Override
			public void released(Gui gui) {
				if (isHovering())
					setForeground(KColor.GRAY_06.getId());
				else
					setForeground(KColor.GRAY_05.getId());
			}

			@Override
			public void pressed(Gui gui) {
				setForeground(KColor.GRAY_07.getId());
			}

			@Override
			public void clicked(Gui gui) {
			}
		});

		listener = new KEventListener() {

			@Override
			public void mouseReleased() {
				if (!isVisible())
					return;

				if (pressed) {
					pressed = false;
					requestFocus();
					for (KButtonListener e : listeners) {
						e.released(get());
						e.clicked(get());
					}
					KEventSheduler.stop();
				}
			}

			@Override
			public void mousePressed() {
				if (!isVisible())
					return;

				if (hovering) {
					if (!pressed) {
						pressed = true;
						for (KButtonListener e : listeners)
							e.pressed(get());
					}
					KEventSheduler.stop();
				}
			}

			@Override
			public void mouseMoved(int dx, int dy) {
				if (!isVisible())
					return;

				hovering = GuiHelper.handleHovering(hovering, listeners, get());
			}

			@Override
			public void mouseDragged(int dx, int dy) {
			}

			@Override
			public void mouseClicked() {
			}

			@Override
			public void keyTyped(int key) {
			}

			@Override
			public void keyReleased(int key) {
			}

			@Override
			public void keyPressed(int key) {
			}

			@Override
			public void mouseWheelMoved(int d) {
			}
		};

		resetListener = new KResetListener() {

			@Override
			public void reset() {
				for (KButtonListener l : listeners)
					l.exited(get());
				hovering = false;
			}
		};
		KButtonController.addKResetListener(resetListener);
	}

	public void addKButtonListener(KButtonListener e) {
		listeners.add(e);
	}

	public void removeKButtonListener(KButtonListener e) {
		listeners.remove(e);
	}

	public void removeKButtonListener(int index) {
		listeners.remove(index);
	}

	public boolean isHovering() {
		return hovering;
	}

	public void setHovering(boolean hovering) {
		this.hovering = hovering;
	}

	public boolean isPressed() {
		return pressed;
	}

	public void setPressed(boolean pressed) {
		this.pressed = pressed;
	}

	@Override
	public void render(GuiRenderer renderer) {
		if (!isVisible()) {
			return;
		}

		float x = getAbsoluteX();
		float y = getAbsoluteY();

		updateText();

		renderer.renderImage(x, y, width, height, background, clip, alpha);
		renderer.renderImage(x, y, width, height, foreground, clip, alpha);
	}
	
	public void replaceKButtonListener(int i, KButtonListener l) {
		removeKButtonListener(i);
		addKButtonListener(l);
	}

	@Override
	public void apply(CSSFile style) {
		super.apply(style);
		List<CSSAttribute> attribs = style.getAttributes();
		for (CSSAttribute e : attribs) {
			if (typeName.equals(e.getName())) {
			}
		}
	}
}
