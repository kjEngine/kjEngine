package de.kjEngine.core.awt;

import java.util.ArrayList;
import java.util.List;

import de.kjEngine.core.api.KUtillities;
import de.kjEngine.core.awt.css.CSSFile;
import de.kjEngine.core.awt.event.EnterListener;
import de.kjEngine.core.awt.event.KEventListener;
import de.kjEngine.core.awt.event.KFocusListener;
import de.kjEngine.core.awt.rendering.GuiRenderer;

public class KTextInputGui extends KTextContainer {

	private KCaret caret;
	private List<EnterListener> enterListeners = new ArrayList<>();

	public KTextInputGui() {
		this(0f, 0f, 0f, 0f);
	}

	private void appendText(String text) {
		String ntxt = getText().getText().getTextString();
		if (text.equals("back")) {
			int l = ntxt.length();
			if (l > 1) {
				ntxt = ntxt.substring(0, ntxt.length() - 1);
				caret.move(-1, false);
			} else {
				ntxt = "";
				caret.move(-1, false);
			}
		} else {
			ntxt += text;
			caret.move(1, false);
		}
		setText(ntxt);
		caret.update();
	}

	public KTextInputGui(float x, float y, float width, float height) {
		super(x, y, width, height);

		caret = new KCaret(this);
		caret.setVisible(false);
		caret.setBlinkDelay(300);

		addEVListener(new KEventListener() {

			@Override
			public void mouseReleased() {
			}

			@Override
			public void mousePressed() {
			}

			@Override
			public void mouseMoved(int dx, int dy) {
			}

			@Override
			public void mouseDragged(int dx, int dy) {
			}

			@Override
			public void mouseClicked() {
			}

			@Override
			public void keyTyped(int key) {
				if (isFocused()) {
					KUtillities.invokeNext(() -> {

						if (key == 8) {
							appendText("back");
						} else {
							if (key != 0) {
								if (key != 13) {
									appendText(String.valueOf((char) key));
								} else {
									for (EnterListener l : enterListeners) {
										l.enter(KTextInputGui.this);
									}
								}
							}
						}
					});
				}
			}

			@Override
			public void keyReleased(int key) {
			}

			@Override
			public void keyPressed(int key) {
			}

			@Override
			public void mouseWheelMoved(int d) {
			}
		});
		
		addKFocusListener(new KFocusListener() {
			
			@Override
			public void focusLost(Gui src) {
				caret.setVisible(false);
			}
			
			@Override
			public void focusGained(Gui src) {
				caret.setVisible(true);
			}
			
			@Override
			public void focusChanged(Gui src) {
			}
		});
	}

	public KCaret getCaret() {
		return caret;
	}

	public void setCaret(KCaret caret) {
		if (caret == null)
			throw new NullPointerException();
		this.caret = caret;
	}

	@Override
	public void render(GuiRenderer renderer) {
		if (!isVisible())
			return;

		float x = getAbsoluteX();
		float y = getAbsoluteY();

		updateText();

		renderer.renderImage(x, y, width, height, background, clip, alpha);
		renderer.renderImage(x, y, width, height, foreground, clip, alpha);
		caret.render(renderer);
	}

	@Override
	public void apply(CSSFile style) {
	}

	public void clear() {
		caret.setTxtPosition(0);
		caret.setTxtPrev_position(0);
		caret.update();
		setText("");
	}

	public void addEnterListener(EnterListener l) {
		enterListeners.add(l);
	}

	public void removeEnterListener(EnterListener l) {
		enterListeners.remove(l);
	}
}
