package de.kjEngine.core.awt;

import java.util.ArrayList;
import java.util.List;

import org.lwjgl.opengl.Display;

import de.kjEngine.core.awt.css.CSSFile;
import de.kjEngine.core.awt.event.KEventListener;
import de.kjEngine.core.awt.event.KEventSheduler;
import de.kjEngine.core.awt.event.KScrollBarListener;
import de.kjEngine.core.awt.rendering.GuiRenderer;

public class KScrollBar extends Gui {
	
	public static final int HORIZONTAL = 0, VERTICAL = 1;
	
	protected int axis;
	protected float value;
	protected KButton curser;	
	protected List<KScrollBarListener> listeners = new ArrayList<>();

	public KScrollBar() {
		this(0f, 0f, 0f, 0f);
	}
	
	public KScrollBar(float x, float y, float width, float height) {
		super(x, y, width, height);
				
		if(width > height) {
			axis = HORIZONTAL;
			curser = new KButton(0, 0, width * 0.1f, height);
		} else {
			axis = VERTICAL;
			curser = new KButton(0, 0, width, height * 0.1f);
		}
		curser.setParent(this);
		
		listener = new KEventListener() {
			
			@Override
			public void mouseReleased() {				
			}
			
			@Override
			public void mousePressed() {				
			}
			
			@Override
			public void mouseMoved(int dx, int dy) {				
			}
			
			@Override
			public void mouseDragged(int dx, int dy) {
				if(!isVisible()) return;
				
				float mdx = ((float) dx / (float) Display.getWidth()) * 2f;
				float mdy = ((float) dy / (float) Display.getHeight()) * 2f;
						
				if(curser.isPressed()) {
					if(axis == VERTICAL) {
						float nvalue = value + mdy / (height * 0.9f);
						
						if(nvalue < 0) nvalue = 0;
						else if(nvalue > 1f) nvalue = 1f;
						
						if(value != nvalue)
							for(KScrollBarListener e : listeners)
								e.valueChanged(nvalue);
						
						value = nvalue;
						
						curser.setY(value * (height * 0.9f));
					} else {
						float nvalue = value + mdx / (width * 0.9f);
						
						if(nvalue < 0) nvalue = 0;
						else if(nvalue > 1f) nvalue = 1f;
						
						if(value != nvalue)
							for(KScrollBarListener e : listeners)
								e.valueChanged(nvalue);
						
						value = nvalue;
						
						curser.setX(value * (width * 0.9f));
					}
					KEventSheduler.stop();
				}
			}
			
			@Override
			public void mouseClicked() {				
			}
			
			@Override
			public void keyTyped(int key) {				
			}
			
			@Override
			public void keyReleased(int key) {				
			}
			
			@Override
			public void keyPressed(int key) {				
			}

			@Override
			public void mouseWheelMoved(int d) {
			}
		};
	}
	
	public void addKScrollBarListener(KScrollBarListener e) {
		listeners.add(e);
	}
	
	public void removeKScrollBarListener(KScrollBarListener e) {
		listeners.remove(e);
	}

	public int getAxis() {
		return axis;
	}

	public void setAxis(int axis) {
		this.axis = axis;
	}

	public float getValue() {
		return value;
	}

	public void setValue(float value) {
		if(axis == VERTICAL) {
			if(value < 0) value = 0;
			else if(value > 1f) value = 1f;
			
			if(value != this.value)
				for(KScrollBarListener e : listeners)
					e.valueChanged(value);
			
			curser.setY(value * (height * 0.9f));
		} else {
			if(value < 0) value = 0;
			else if(value > 1f) value = 1f;
			
			if(value != this.value)
				for(KScrollBarListener e : listeners)
					e.valueChanged(value);
			
			curser.setX(value * (width * 0.9f));
		}
		this.value = value;
	}

	public KButton getCurser() {
		return curser;
	}

	@Override
	public void setVisible(boolean visible) {
		curser.setVisible(visible);
		super.setVisible(visible);
	}
	
	@Override
	public void render(GuiRenderer renderer) {
		if(!isVisible()) return;
		
		float x = getAbsoluteX();
		float y = getAbsoluteY();
		
		renderer.renderImage(x, y, width, height, background, clip, alpha);	
		renderer.renderImage(x, y, width, height, foreground, clip, alpha);
		
		curser.render(renderer);
	}

	@Override
	public void apply(CSSFile style) {
	}
}
