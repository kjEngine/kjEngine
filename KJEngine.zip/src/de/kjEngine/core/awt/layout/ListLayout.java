package de.kjEngine.core.awt.layout;

import de.kjEngine.core.awt.Gui;
import de.kjEngine.core.awt.KColor;
import de.kjEngine.core.awt.KPanel;

public class ListLayout extends KPanel {

	public static final int HORIZONTAL = 0, VERTICAL = 1;

	private int pointer, axis;
	private float tileWidth, tileHeight;
	private float padding_x, padding_y;

	public ListLayout(int axis) {
		init(axis);
	}

	public ListLayout(float x, float y, float width, float height, float r, float g, float b, float a, int axis) {
		super(x, y, width, height, r, g, b, a);
		init(axis);
	}

	public ListLayout(float x, float y, float width, float height, KColor fg, int axis) {
		super(x, y, width, height, fg);
		init(axis);
	}

	public ListLayout(float x, float y, float width, float height, int axis) {
		super(x, y, width, height);
		init(axis);
	}

	private void init(int axis) {
		this.axis = axis;
	}

	public float getTileWidth() {
		return tileWidth;
	}

	public void setTileWidth(float tileWidth) {
		this.tileWidth = tileWidth;
	}

	public float getTileHeight() {
		return tileHeight;
	}

	public void setTileHeight(float tileHeight) {
		this.tileHeight = tileHeight;
	}

	public float getPadding_x() {
		return padding_x;
	}

	public void setPadding_x(float padding_x) {
		this.padding_x = padding_x;
	}

	public float getPadding_y() {
		return padding_y;
	}

	public void setPadding_y(float padding_y) {
		this.padding_y = padding_y;
	}

	public int getAxis() {
		return axis;
	}

	@Override
	public void add(Gui e) {
		float size;
		float padding;
		if (axis == HORIZONTAL) {
			 size = tileWidth;
			 padding = padding_x;
		} else  {
			size = tileHeight;
			padding = padding_y;
		}
		float a = pointer * (size + padding) + padding;
		if (axis == HORIZONTAL) {
			e.setX(a);
			e.setY(padding_y);
		} else {
			e.setX(padding_x);
			e.setY(a);
		}
		e.setWidth(tileWidth);
		e.setHeight(tileHeight);
		System.out.println(e);
		pointer++;
		super.add(e);
	}
}
