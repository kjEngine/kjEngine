package de.kjEngine.core.awt.layout;

import de.kjEngine.core.awt.Gui;
import de.kjEngine.core.awt.KColor;
import de.kjEngine.core.awt.KPanel;

public class GridLayout extends KPanel {
	
	private int cols;
	private int pointer;
	private float tileWidth, tileHeight;
	private float padding_x, padding_y;
	
	public GridLayout() {
		init();
	}

	public GridLayout(float x, float y, float width, float height) {
		super(x, y, width, height);
		init();
	}
	
	public GridLayout(float x, float y, float width, float height, KColor fg) {
		super(x, y, width, height, fg);
		init();
	}

	private void init() {
	}

	public int getCols() {
		return cols;
	}

	public void setCols(int cols) {
		this.cols = cols;
	}

	public float getTileWidth() {
		return tileWidth;
	}

	public void setTileWidth(float tileWidth) {
		this.tileWidth = tileWidth;
	}

	public float getTileHeight() {
		return tileHeight;
	}

	public void setTileHeight(float tileHeight) {
		this.tileHeight = tileHeight;
	}

	public float getPadding_x() {
		return padding_x;
	}

	public void setPadding_x(float padding_x) {
		this.padding_x = padding_x;
	}

	public float getPadding_y() {
		return padding_y;
	}

	public void setPadding_y(float padding_y) {
		this.padding_y = padding_y;
	}

	@Override
	public void add(Gui e) {
		float nx = (tileWidth + padding_x) * (pointer % cols);
		float ny = height - (tileHeight + padding_y) * (pointer / cols) - tileHeight;
		e.setX(nx);
		e.setY(ny);
		super.add(e);
		pointer++;
	}

	public void addElement(Gui e, int grid_x, int grid_y) {
		float nx = (tileWidth + padding_x) * grid_x;
		float ny = (tileHeight + padding_y) * grid_y;
		e.setX(nx);
		e.setY(ny);
		super.add(e);
	}
	
	public float addedHeight() {
		return (tileHeight + padding_y) * (pointer / cols) + tileHeight * 2f;
	}

	@Override
	public void removeElement(Gui e) {
		super.removeElement(e);
		pointer--;
	}

	@Override
	public void removeAllElements() {
		super.removeAllElements();
		pointer = 0;
	}
}
