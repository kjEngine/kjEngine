package de.kjEngine.core.awt;

import java.util.List;

import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;

import de.kjEngine.core.awt.event.HoverListener;
import de.kjEngine.core.awt.event.KButtonController;
import de.kjEngine.core.awt.event.KEventSheduler;

public class GuiHelper {
	
	public static boolean handleHovering(boolean lastStatus, List<? extends HoverListener> listeners, Gui me) {
		float nx = me.getAbsolutePosition().x;
		float ny = me.getAbsolutePosition().y;

		float mx = ((float) Mouse.getX() / (float) Display.getWidth()) * 2f - 1f;
		float my = ((float) Mouse.getY() / (float) Display.getHeight()) * 2f - 1f;

		boolean h = !(mx < nx || my < ny || mx > nx + me.width || my > ny + me.height);

		if (h != lastStatus) {
			if (h) {
				KButtonController.callReset();
				for (HoverListener e : listeners)
					e.entered(me);
			} else {
				KButtonController.callReset();
				for (HoverListener e : listeners)
					e.exited(me);
			}
		}
		if (h)
			KEventSheduler.stop();
		return h;
	}
}
