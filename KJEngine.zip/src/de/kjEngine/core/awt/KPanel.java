package de.kjEngine.core.awt;

import java.util.ArrayList;
import java.util.List;

import org.lwjgl.util.vector.Vector4f;

import de.kjEngine.core.awt.css.CSSFile;
import de.kjEngine.core.awt.event.KEventDispatcher;
import de.kjEngine.core.awt.event.KEventListener;
import de.kjEngine.core.awt.event.KEventType;
import de.kjEngine.core.awt.rendering.GuiRenderer;
import de.kjEngine.core.model.Rectangle;
import de.kjEngine.core.util.Loader;

public class KPanel extends Gui {

	protected List<Gui> elements = new ArrayList<>();
	protected List<KEventListener> listeners = new ArrayList<>();
	protected KEventDispatcher dispatcher;

	public KPanel() {
		this(0f, 0f, 0f, 0f);
	}

	public KPanel(float x, float y, float width, float height, float r, float g, float b, float a) {
		this(x, y, width, height);
		setBackground(Loader.loadColorToTexture(new Vector4f()));
		setForeground(Loader.loadColorToTexture(new Vector4f(r, g, b, a)));
		setVisible(true);
	}

	public KPanel(float x, float y, float width, float height, KColor fg) {
		this(x, y, width, height);
		setBackground(fg.getId());
		setForeground(fg.getId());
		setVisible(true);
	}

	public KPanel(float x, float y, float width, float height) {
		super(x, y, width, height);

		dispatcher = new KEventDispatcher(listeners);

		addEVListener(new KEventListener() {

			@Override
			public void mouseReleased() {
				dispatcher.dispatch(KEventType.MOUSE_RELEASED, 0, 0, 0, 0);
			}

			@Override
			public void mousePressed() {
				dispatcher.dispatch(KEventType.MOUSE_PRESSED, 0, 0, 0, 0);
			}

			@Override
			public void mouseMoved(int dx, int dy) {
				dispatcher.dispatch(KEventType.MOUSE_MOVED, 0, dx, dy, 0);
			}

			@Override
			public void mouseDragged(int dx, int dy) {
				dispatcher.dispatch(KEventType.MOUSE_DRAGGED, 0, dx, dy, 0);
			}

			@Override
			public void mouseClicked() {
				dispatcher.dispatch(KEventType.MOUSE_CLICKED, 0, 0, 0, 0);
			}

			@Override
			public void keyTyped(int key) {
				dispatcher.dispatch(KEventType.KEY_TYPED, key, 0, 0, 0);
			}

			@Override
			public void keyReleased(int key) {
				dispatcher.dispatch(KEventType.KEY_RELEASED, key, 0, 0, 0);
			}

			@Override
			public void keyPressed(int key) {
				dispatcher.dispatch(KEventType.KEY_PRESSED, key, 0, 0, 0);
			}

			@Override
			public void mouseWheelMoved(int d) {
				dispatcher.dispatch(KEventType.MOUSE_WHEEL_MOVED, 0, 0, 0, d);
			}
		});
	}

	public void addXCentered(Gui e) {
		e.x = width * 0.5f - e.width * 0.5f;
		add(e);
	}

	public void addYCentered(Gui e) {
		e.y = height * 0.5f - e.height * 0.5f;
		add(e);
	}

	public void addXYCentered(Gui e) {
		e.y = height * 0.5f - e.height * 0.5f;
		e.x = width * 0.5f - e.width * 0.5f;
		add(e);
	}

	public void add(Gui g) {
		List<Gui> uis = g.uis();
		for (Gui e : uis) {
			addKEventListener(e.getListener());
			if (e instanceof KScrollBar) {
				addKEventListener(((KScrollBar) e).getCurser().getListener());
			} else if (e instanceof KComboBox) {
				for (KButton b : ((KComboBox) e).getElements())
					addKEventListener(b.getListener());
				addKEventListener(((KComboBox) e).getSelectedElement().getListener());
				addKEventListener(((KComboBox) e).getCollapseButton().getListener());
			} else if (e instanceof KSpinner) {
				KSpinner s = (KSpinner) e;
				add(s.getLess());
				add(s.getMore());
				add(s.getDisplay());
			}
			e.setParent(this);
			elements.add(e);
		}
	}

	public void removeElement(Gui e) {
		removeKEventListener(e.getListener());
		if (e instanceof KScrollBar) {
			removeKEventListener(((KScrollBar) e).getCurser().getListener());
		} else if (e instanceof KComboBox) {
			for (KButton b : ((KComboBox) e).getElements())
				removeKEventListener(b.getListener());
			removeKEventListener(((KComboBox) e).getSelectedElement().getListener());
			removeKEventListener(((KComboBox) e).getCollapseButton().getListener());
		}
		e.setParent(null);
		elements.remove(e);
	}

	public void removeAllElements() {
		for (int i = 0; i < elements.size(); i++) {
			removeElement(elements.get(i));
		}
	}

	public void addKEventListener(KEventListener l) {
		listeners.add(l);
		dispatcher.setListeners(listeners);
	}

	public void removeKEventListener(KEventListener l) {
		listeners.remove(l);
		dispatcher.setListeners(listeners);
	}

	public void removeAllKEventListeners() {
		listeners.clear();
		dispatcher.setListeners(listeners);
	}

	public List<Gui> allGuis() {
		List<Gui> result = new ArrayList<>();
		result.addAll(elements);
		for (Gui e : elements) {
			if (e instanceof KPanel) {
				KPanel p = (KPanel) e;
				result.addAll(p.allGuis());
			}
		}
		return result;
	}

	@Override
	public void render(GuiRenderer renderer) {
		if (!isVisible())
			return;

		float x = getAbsoluteX();
		float y = getAbsoluteY();

		renderer.renderImage(x, y, width, height, background, clip, alpha);
		renderer.renderImage(x, y, width, height, foreground, clip, alpha);

		for (int i = elements.size() - 1; i >= 0; i--) {
			elements.get(i).render(renderer);
			elements.get(i).animate();
			if (elements.get(i) instanceof KTextContainer) {
				((KTextContainer) elements.get(i)).renderText(renderer);
			}
		}
	}

	@Override
	public void apply(CSSFile style) {
	}

	@Override
	public void setClip(Rectangle clip) {
		super.setClip(clip);
		for (Gui g : elements) {
			g.setClip(clip);
		}
	}
}
