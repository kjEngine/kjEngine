package de.kjEngine.core.awt;

import java.util.ArrayList;
import java.util.List;

import de.kjEngine.core.awt.css.CSSFile;
import de.kjEngine.core.awt.event.KEventListener;
import de.kjEngine.core.awt.event.KEventSheduler;
import de.kjEngine.core.awt.event.KTickBoxListener;
import de.kjEngine.core.awt.rendering.GuiRenderer;

public class KTickBox extends Gui {

	private boolean selected = false;
	private boolean hovering = false;
	private int selectedTexture, deselectedTexture;
	private List<KTickBoxListener> listeners = new ArrayList<>();

	public KTickBox() {
		this(0f, 0f, 0f, 0f);
	}

	public KTickBox(float x, float y, float width, float height) {
		super(x, y, width, height);

		listener = new KEventListener() {

			@Override
			public void mouseReleased() {
			}

			@Override
			public void mousePressed() {
			}

			@Override
			public void mouseMoved(int dx, int dy) {
				if (!isVisible())
					return;
				
				hovering = GuiHelper.handleHovering(hovering, listeners, get());
			}

			@Override
			public void mouseDragged(int dx, int dy) {
			}

			@Override
			public void mouseClicked() {
				if (hovering) {
					selected = !selected;
					if (selected) {
						for (KTickBoxListener l : listeners)
							l.activated(get());
						setForeground(selectedTexture);
						setBackground(selectedTexture);
					} else {
						for (KTickBoxListener l : listeners)
							l.deactivated(get());
						setForeground(deselectedTexture);
						setBackground(deselectedTexture);
					}
					KEventSheduler.stop();
				}
			}

			@Override
			public void keyTyped(int key) {
			}

			@Override
			public void keyReleased(int key) {
			}

			@Override
			public void keyPressed(int key) {
			}

			@Override
			public void mouseWheelMoved(int d) {
			}
		};
	}

	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	public int getSelectedTexture() {
		return selectedTexture;
	}

	public void setSelectedTexture(int selectedTexture) {
		this.selectedTexture = selectedTexture;
	}

	public int getDeselectedTexture() {
		return deselectedTexture;
	}

	public void setDeselectedTexture(int deselectedTexture) {
		this.deselectedTexture = deselectedTexture;
	}

	public boolean isHovering() {
		return hovering;
	}
	
	public void addKTickBoxListener(KTickBoxListener l) {
		listeners.add(l);
	}
	
	public void removeKTickBoxListener(KTickBoxListener l) {
		listeners.remove(l);
	}
	
	@Override
	public KTickBox get() {
		return this;
	}

	@Override
	public void render(GuiRenderer renderer) {
		if (!isVisible())
			return;

		float x = getAbsoluteX();
		float y = getAbsoluteY();
		
		renderer.renderImage(x, y, width, height, background, clip, alpha);
		renderer.renderImage(x, y, width, height, foreground, clip, alpha);
	}

	@Override
	public void apply(CSSFile style) {
	}
}
