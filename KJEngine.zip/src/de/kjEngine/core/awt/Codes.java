package de.kjEngine.core.awt;

public class Codes {

	public static final Integer NOT_MOVABLE_BY_SCROLL_PANEL = 1;
}
