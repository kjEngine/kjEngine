package de.kjEngine.core.awt;

public class Relation {
	
	public static Relation of(float a, float b) {
		return new Relation(a, b);
	}
	
	public static Relation of(float diff) {
		return new Relation(0, diff);
	}
	
	private float a, b;
	private final float diff;

	private Relation(float a, float b) {
		this.a = a;
		this.b = b;
		diff = b - a;
	}

	/**
	 * @return the a
	 */
	public float getA() {
		return a;
	}

	/**
	 * @param a the a to set
	 */
	public void setA(float a) {
		this.a = a;
		b = a + diff;
	}

	/**
	 * @return the b
	 */
	public float getB() {
		return b;
	}

	/**
	 * @param b the b to set
	 */
	public void setB(float b) {
		this.b = b;
		a = b - diff;
	}

	/**
	 * @return the diff
	 */
	public float getDiff() {
		return diff;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Float.floatToIntBits(a);
		result = prime * result + Float.floatToIntBits(b);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof Relation))
			return false;
		Relation other = (Relation) obj;
		if (Float.floatToIntBits(a) != Float.floatToIntBits(other.a))
			return false;
		if (Float.floatToIntBits(b) != Float.floatToIntBits(other.b))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Relation [a=" + a + ", b=" + b + "]";
	}
}
