package de.kjEngine.core.awt;

import java.util.ArrayList;
import java.util.List;

import de.kjEngine.core.awt.css.CSSFile;
import de.kjEngine.core.awt.event.KButtonAdapter;
import de.kjEngine.core.awt.event.KSpinnerListener;
import de.kjEngine.core.awt.event.ResizeListener;
import de.kjEngine.core.awt.rendering.GuiRenderer;
import de.kjEngine.core.model.Rectangle;

public class KSpinner extends Gui {

	private KButton more, less;
	private KLabel display;
	private int moreTexture, lessTexture;
	private int value, prevValue;
	private List<KSpinnerListener> kSpinnerListeners = new ArrayList<>();

	public KSpinner() {
		this(0f, 0f, 0f, 0f);
	}

	public KSpinner(float x, float y, float width, float height) {
		super(x, y, width, height);

		more = new KButton(x + width * 0.5f, y + height * 0.5f, width * 0.5f, height * 0.5f, moreTexture,
				new KButtonAdapter() {

					@Override
					public void clicked(Gui gui) {
						value++;
						for (KSpinnerListener l : kSpinnerListeners)
							l.valueChanged(get());
					}
				});

		less = new KButton(x + width * 0.5f, y, width * 0.5f, height * 0.5f, lessTexture, new KButtonAdapter() {

			@Override
			public void clicked(Gui gui) {
				value--;
				for (KSpinnerListener l : kSpinnerListeners)
					l.valueChanged(get());
			}
		});

		display = new KLabel(x, y, width * 0.5f, 0f, KColor.NONE);
		display.setText(String.valueOf(value));

		addResizeListener(new ResizeListener() {

			@Override
			public void resize(float width, float height) {
				more.setBounds(x + width * 0.5f, y + height * 0.5f, width * 0.5f, height * 0.5f);
				less.setBounds(x + width * 0.5f, y, width * 0.5f, height * 0.5f);
				display.setBounds(x, y, width * 0.5f, 0f);
			}
		});
	}

	/**
	 * @return the moreTexture
	 */
	public int getMoreTexture() {
		return moreTexture;
	}

	/**
	 * @param moreTexture
	 *            the moreTexture to set
	 */
	public void setMoreTexture(int moreTexture) {
		this.moreTexture = moreTexture;
		more.setBackground(moreTexture);
		more.setForeground(moreTexture);
	}

	/**
	 * @return the lessTexture
	 */
	public int getLessTexture() {
		return lessTexture;
	}

	/**
	 * @param lessTexture
	 *            the lessTexture to set
	 */
	public void setLessTexture(int lessTexture) {
		this.lessTexture = lessTexture;
		less.setBackground(lessTexture);
		less.setForeground(lessTexture);
	}

	/**
	 * @return the value
	 */
	public int getValue() {
		return value;
	}

	/**
	 * @param value
	 *            the value to set
	 */
	public void setValue(int value) {
		this.value = value;
	}

	@Override
	public void setClip(Rectangle clip) {
		super.setClip(clip);
		more.setClip(getClip());
		less.setClip(getClip());
		display.setClip(getClip());
	}

	/**
	 * @return the more
	 */
	KButton getMore() {
		return more;
	}

	/**
	 * @return the less
	 */
	KButton getLess() {
		return less;
	}

	/**
	 * @return the display
	 */
	KLabel getDisplay() {
		return display;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see de.kjEngine.core.awt.Gui#setVisible(boolean)
	 */
	@Override
	public void setVisible(boolean visible) {
		super.setVisible(visible);
		more.setVisible(visible);
		less.setVisible(visible);
		display.setVisible(visible);
	}

	public void addKSpinnerListener(KSpinnerListener l) {
		kSpinnerListeners.add(l);
	}

	public void removeKSpinnerListener(KSpinnerListener l) {
		kSpinnerListeners.remove(l);
	}

	public KSpinner get() {
		return this;
	}

	@Override
	public void render(GuiRenderer renderer) {
		if (!isVisible())
			return;

		if (value != prevValue) {
			display.setText(String.valueOf(value));
			prevValue = value;
		}

		float x = getAbsoluteX();
		float y = getAbsoluteY();

		renderer.renderImage(x, y, width, height, background, clip, alpha);
		renderer.renderImage(x, y, width, height, foreground, clip, alpha);
	}

	@Override
	public void apply(CSSFile style) {
	}
}
