package de.kjEngine.core.awt.css;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class CSSParser {
	
	public static CSSFile loadCSSFile(String file) {
		CSSFile result = new CSSFile();
		try (BufferedReader r = new BufferedReader(new FileReader(new File(file)))) {
			// load file
			StringBuilder sb = new StringBuilder();
			String line = null;
			while ((line = r.readLine()) != null) {
				sb.append(line);
			}
			String data = sb.toString();
			// parse file
			String[] attributes = data.split("\\.");
			for (int i = 1; i < attributes.length; i++) {
				String attribute = attributes[i];
				String[] parts = attribute.split("\\{");
				// get name
				String name = parts[0].trim();
				CSSAttribute attrib = new CSSAttribute(name);
				// get content
				String content = parts[1].split("\\}")[0].trim();
				String[] data0 = content.split(";");
				for (String data1 : data0) {
					String[] attribParts = data1.split(":");
					String attribName = attribParts[0];
					String value = attribParts[1].trim();
					attrib.getData().put(attribName, value);
				}
				result.getAttributes().add(attrib);
			}
		} catch (IOException e) {
		}
		return result;
	}
}
