package de.kjEngine.core.awt.css;

public class AttribException extends Exception {
	private static final long serialVersionUID = 2213481336106843005L;

	public AttribException() {
	}

	public AttribException(String message) {
		super(message);
	}

	public AttribException(Throwable cause) {
		super(cause);
	}

	public AttribException(String message, Throwable cause) {
		super(message, cause);
	}

	public AttribException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
}
