package de.kjEngine.core.awt.css;

import java.util.List;

import de.kjEngine.core.awt.DisplayManager;
import de.kjEngine.core.awt.Gui;

public class StyleManager {
	
	private static CSSFile currentStyle;

	/**
	 * @return the currentStyle
	 */
	public static CSSFile getCurrentStyle() {
		return currentStyle;
	}

	/**
	 * @param currentStyle the currentStyle to set
	 */
	public static void setCurrentStyle(CSSFile currentStyle) {
		if (currentStyle == null)
			throw new NullPointerException();
		StyleManager.currentStyle = currentStyle;
	}
	
	public static void applyStyle() {
		List<Gui> guis = DisplayManager.getRootPanel().allGuis();
		for (Gui e : guis) {
			e.apply(currentStyle);
		}
	}
}
