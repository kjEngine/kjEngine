package de.kjEngine.core.awt.css;

public class AttribNotFoundException extends AttribException {
	private static final long serialVersionUID = 5349500907888689520L;

	public AttribNotFoundException() {
	}

	public AttribNotFoundException(String message) {
		super(message);
	}

	public AttribNotFoundException(Throwable cause) {
		super(cause);
	}

	public AttribNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}

	public AttribNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
}
