package de.kjEngine.core.awt.css;

import java.util.ArrayList;
import java.util.List;

/**
 * This is the data of a whole css file.
 * It contains all the attributes.
 * The best way to create a CSSFile is with CSSFile.fromFile(String);
 * 
 * @author konst
 *
 */
public class CSSFile {
	
	public static CSSFile fromFile(String file) {
		return CSSParser.loadCSSFile(file);
	}
	
	private List<CSSAttribute> attributes = new ArrayList<>();
	
	public CSSFile() {
	}

	/**
	 * @return the attributes
	 */
	public List<CSSAttribute> getAttributes() {
		return attributes;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "CSSFile [attributes=" + attributes + "]";
	}
}
