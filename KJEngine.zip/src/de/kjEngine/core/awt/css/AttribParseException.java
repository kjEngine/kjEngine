package de.kjEngine.core.awt.css;

public class AttribParseException extends AttribException {
	private static final long serialVersionUID = 9170385233312999938L;

	public AttribParseException() {
	}

	public AttribParseException(String message) {
		super(message);
	}

	public AttribParseException(Throwable cause) {
		super(cause);
	}

	public AttribParseException(String message, Throwable cause) {
		super(message, cause);
	}

	public AttribParseException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
}
