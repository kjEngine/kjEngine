package de.kjEngine.core.awt.css;

import java.util.HashMap;
import java.util.Map;

/**
 * 
 * This is an css-attribute for a gui. It has a name (eg: button) and data (eg:
 * <i> [-foreground-color, #ffff00ff], </i> <i> [-background-color,
 * #ff00ffff]</i> ).
 * 
 * @author konst
 *
 */
public class CSSAttribute {
	/**
	 * The name of the attribute.
	 */
	private String name;
	private Map<String, String> data = new HashMap<>();

	public CSSAttribute() {
		this("");
	}

	public CSSAttribute(String name) {
		setName(name);
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		if (name == null)
			throw new NullPointerException();
		this.name = name;
	}

	/**
	 * @return the data
	 */
	public Map<String, String> getData() {
		return data;
	}

	public String getString(String key) throws AttribNotFoundException, AttribParseException {
		if (!data.containsKey(key)) {
			throw new AttribNotFoundException(key);
		}
		return data.get(key);
	}

	public int getInt(String key) throws AttribNotFoundException, AttribParseException {
		if (!data.containsKey(key)) {
			throw new AttribNotFoundException(key);
		}
		try {
			return Integer.parseInt(data.get(key));
		} catch (NumberFormatException e) {
			throw new AttribParseException(e);
		}
	}

	public float getFloat(String key) throws AttribNotFoundException, AttribParseException {
		if (!data.containsKey(key)) {
			throw new AttribNotFoundException(key);
		}
		try {
			return Float.parseFloat(data.get(key));
		} catch (NumberFormatException e) {
			throw new AttribParseException(e);
		}
	}

	public Double getDouble(String key) throws AttribNotFoundException, AttribParseException {
		if (!data.containsKey(key)) {
			throw new AttribNotFoundException(key);
		}
		try {
			return Double.parseDouble(data.get(key));
		} catch (NumberFormatException e) {
			throw new AttribParseException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "CSSAttribute [name=" + name + ", data=" + data + "]";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((data == null) ? 0 : data.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof CSSAttribute))
			return false;
		CSSAttribute other = (CSSAttribute) obj;
		if (data == null) {
			if (other.data != null)
				return false;
		} else if (!data.equals(other.data))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}
}
