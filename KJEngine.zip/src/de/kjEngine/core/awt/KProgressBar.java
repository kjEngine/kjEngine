package de.kjEngine.core.awt;

import de.kjEngine.core.awt.rendering.GuiRenderer;
import de.kjEngine.core.math.KMath;

public class KProgressBar extends KTextContainer {

	private float progress;

	public KProgressBar() {
		this(0f, 0f, 0f, 0f);
	}

	public KProgressBar(float x, float y, float width, float height) {
		super(x, y, width, height);
	}

	public float getProgress() {
		return progress;
	}

	public void setProgress(float progress) {
		if (progress < 0 || progress > 1f) {
			throw new IllegalArgumentException();
		}
		this.progress = progress;
	}

	public void addProgress(float progress) {
		this.progress += progress;
		this.progress = KMath.clamp(this.progress, 0f, 1f);
	}

	public void reset() {
		progress = 0f;
	}

	@Override
	public void render(GuiRenderer renderer) {
		if (!isVisible()) {
			return;
		}

		float x = getAbsoluteX();
		float y = getAbsoluteY();

		renderer.renderImage(x, y, width, height, background, clip, alpha);
		if (width > height) {
			renderer.renderImage(x, y, width * progress, height, foreground, clip, alpha);
		} else {
			renderer.renderImage(x, y, width, height * progress, foreground, clip, alpha);
		}

		updateText();
	}
}
