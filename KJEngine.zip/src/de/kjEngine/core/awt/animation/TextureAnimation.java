package de.kjEngine.core.awt.animation;

import de.kjEngine.core.api.TimingVerifier;
import de.kjEngine.core.awt.Gui;

public class TextureAnimation extends Animation {
	
	private int[] fgs, bgs;
	private TimingVerifier frameTimer;
	private boolean looping;
	private int pointer;

	public TextureAnimation(Gui parent, int[] fgs, int[] bgs, int frameLength, boolean looping) {
		super(parent);
		this.fgs = fgs;
		this.bgs = bgs;
		frameTimer = new TimingVerifier(frameLength);
		setLooping(looping);
	}
	
	public void reset() {
		pointer = 0;
	}

	@Override
	public void run() {
		if (frameTimer.time()) {
			parent.setForeground(fgs[pointer]);
			parent.setBackground(bgs[pointer++]);
			if (pointer > Math.min(fgs.length, bgs.length)) {
				if (isLooping()) {
					reset();
				} else {
					pointer--;
				}
			}
		}
	}

	public boolean isLooping() {
		return looping;
	}

	public void setLooping(boolean looping) {
		this.looping = looping;
	}

	public TimingVerifier getFrameTimer() {
		return frameTimer;
	}
}
