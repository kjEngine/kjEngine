package de.kjEngine.core.awt.animation;

import org.lwjgl.util.vector.Vector2f;

import de.kjEngine.core.awt.DisplayManager;
import de.kjEngine.core.awt.Gui;
import de.kjEngine.core.math.KMath;

public class SlideAnimation extends Animation {

	private Vector2f target;
	private float speed;

	public SlideAnimation(Gui parent, float speed) {
		super(parent);
		target = parent.getPosition();
		setSpeed(speed);
	}

	/**
	 * @return the target
	 */
	public Vector2f getTarget() {
		return target;
	}

	/**
	 * @param target
	 *            the target to set
	 */
	public void setTarget(Vector2f target) {
		this.target = target;
	}

	/**
	 * @return the speed
	 */
	public float getSpeed() {
		return speed;
	}

	/**
	 * @param speed
	 *            the speed to set
	 */
	public void setSpeed(float speed) {
		if (speed < 0) {
			throw new IllegalArgumentException("speed < 0");
		}
		this.speed = speed;
	}

	@Override
	public void run() {
		if (target != null) {
			if (DisplayManager.getDelta() < 0.5) {
				parent.setPosition(KMath.interpolate(parent.getPosition(), getTarget(),
						Math.min(speed * DisplayManager.getDelta(), 1f)));
			}
		}
	}
}
