package de.kjEngine.core.awt.animation;

import org.lwjgl.util.vector.Vector4f;

import de.kjEngine.core.awt.DisplayManager;
import de.kjEngine.core.awt.Gui;
import de.kjEngine.core.awt.KColor;
import de.kjEngine.core.math.KMath;

public class FlashAnimation extends Animation {
	
	private long time;
	private KColor target, usual;
	private boolean fg;
	private float progress;

	public FlashAnimation(Gui parent, KColor usual, KColor target, long time, boolean fg) {
		super(parent);
		setTime(time);
		setTarget(target);
		setFg(fg);
		setUsual(usual);
	}
	
	public void flash() {
		progress = 0f;
	}

	@Override
	public void run() {
		if (progress < 1f) {
			setColor();
			progress += DisplayManager.getDelta() / (time / 1000f);
		}
	}

	private void setColor() {
		float a = progress * 2f;
		if (a > 1f) {
			a = 2f - a;
		}
		Vector4f mix = KMath.interpolate(usual.getColor(), target.getColor(), a);
		if (fg) {
			parent.setForeground(new KColor(mix));
		} else {
			parent.setBackground(new KColor(mix));
		}
	}

	public long getTime() {
		return time;
	}

	public void setTime(long time) {
		this.time = time;
	}

	public KColor getTarget() {
		return target;
	}

	public void setTarget(KColor target) {
		this.target = target;
	}

	public boolean isFg() {
		return fg;
	}

	public void setFg(boolean fg) {
		this.fg = fg;
	}

	public KColor getUsual() {
		return usual;
	}

	public void setUsual(KColor usual) {
		this.usual = usual;
	}
}
