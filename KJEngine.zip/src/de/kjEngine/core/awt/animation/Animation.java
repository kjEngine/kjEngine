package de.kjEngine.core.awt.animation;

import de.kjEngine.core.awt.Gui;

public abstract class Animation implements Runnable {
	
	protected Gui parent;

	public Animation(Gui parent) {
		setParent(parent);
	}

	/**
	 * @return the parent
	 */
	public Gui getParent() {
		return parent;
	}

	/**
	 * @param parent the parent to set
	 */
	public void setParent(Gui parent) {
		this.parent = parent;
	}
}
