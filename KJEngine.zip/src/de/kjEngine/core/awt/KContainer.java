package de.kjEngine.core.awt;

import java.util.List;

public interface KContainer {

	List<Gui> uis();
}
