package de.kjEngine.core.awt;

import de.kjEngine.core.awt.event.InputHandler;

public class KRootPanel extends KPanel {
		
	public KRootPanel() {
		this(0f, 0f, 0f, 0f);
	}

	public KRootPanel(float x, float y, float width, float height) {
		super(x, y, width, height);
		InputHandler.addKEventListener(listener);
		alpha = 0f;
		setFocusable(false);
	}
}
