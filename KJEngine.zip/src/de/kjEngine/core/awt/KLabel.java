package de.kjEngine.core.awt;

import de.kjEngine.core.awt.css.CSSFile;
import de.kjEngine.core.awt.rendering.GuiRenderer;

public class KLabel extends KTextContainer {

	public KLabel() {
		this(0, 0, 0, 0);
	}

	public KLabel(float x, float y, float width, float height) {
		super(x, y, width, height);
	}

	public KLabel(float x, float y, float width, float height, KColor fg) {
		this(x, y, width, height, fg.getId());
	}

	public KLabel(float x, float y, float width, float height, int fg) {
		super(x, y, width, height);
		setForeground(KColor.NONE);
		setBackground(fg);
		setVisible(true);
	}

	@Override
	public void render(GuiRenderer renderer) {
		if (!isVisible())
			return;

		float x = getAbsoluteX();
		float y = getAbsoluteY();

		updateText();

		renderer.renderImage(x, y, width, height, background, clip, alpha);
		renderer.renderImage(x, y, width, height, foreground, clip, alpha);
	}

	@Override
	public void apply(CSSFile style) {
	}
}
