package de.kjEngine.core.awt;

import org.lwjgl.util.vector.Vector3f;

public class GuiManager {
	
	public static enum CoordMode {
		PIXEL, GL_COORDS_DEFAULT, GL_COORDS_WITH_ASPECT_CORRECTION
	}
	
	private static CoordMode sizeMode = CoordMode.GL_COORDS_DEFAULT;
	private static Vector3f defaultFontColor = new Vector3f();

	public static CoordMode getSizeMode() {
		return sizeMode;
	}

	public static void setSizeMode(CoordMode sizeMode) {
		GuiManager.sizeMode = sizeMode;
	}

	public static Vector3f getDefaultFontColor() {
		return defaultFontColor;
	}

	public static void setDefaultFontColor(Vector3f defaultFontColor) {
		if (defaultFontColor == null) {
			defaultFontColor = new Vector3f();
		}
		GuiManager.defaultFontColor = defaultFontColor;
	}
}
