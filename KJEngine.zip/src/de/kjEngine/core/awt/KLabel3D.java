package de.kjEngine.core.awt;

import java.awt.Dimension;

import org.lwjgl.opengl.GL30;
import org.lwjgl.util.vector.Vector3f;
import org.lwjgl.util.vector.Vector4f;

import de.kjEngine.core.api.Entity;
import de.kjEngine.core.api.Instances;
import de.kjEngine.core.awt.css.CSSFile;
import de.kjEngine.core.awt.rendering.GuiRenderer;
import de.kjEngine.core.mainrendering.Renderer;
import de.kjEngine.core.model.Model;
import de.kjEngine.core.postProcessing.Fbo;

public class KLabel3D extends Gui {

	private Model content;
	private float distance;
	private float rotation;
	private Vector3f scale = new Vector3f(1f, 1f, 1f);
	private Vector4f clearColor = new Vector4f();
	private Renderer renderer;
	private Fbo fbo, buffer2;

	public KLabel3D(Renderer renderer, int samples, Dimension resolution) {
		this(0f, 0f, 0f, 0f, renderer, samples, resolution);
	}

	public KLabel3D(float x, float y, float width, float height, Renderer renderer, int samples, Dimension resolution) {
		super(x, y, width, height);
		this.renderer = renderer;
		fbo = new Fbo(resolution.width, resolution.height, new int[] { GL30.GL_COLOR_ATTACHMENT0 }, samples);
		buffer2 = new Fbo(resolution.width, resolution.height, Fbo.NONE, new int[] { GL30.GL_COLOR_ATTACHMENT0 });
	}

	/**
	 * @return the renderer
	 */
	public Renderer getRenderer() {
		return renderer;
	}

	/**
	 * @return the content
	 */
	public Model getContent() {
		return content;
	}

	/**
	 * @param content
	 *            the content to set
	 */
	public void setContent(Model content) {
		this.content = content;
	}

	/**
	 * @return the distance
	 */
	public float getDistance() {
		return distance;
	}

	/**
	 * @param distance
	 *            the distance to set
	 */
	public void setDistance(float distance) {
		this.distance = distance;
	}

	/**
	 * @return the rotation
	 */
	public float getRotation() {
		return rotation;
	}

	/**
	 * @param rotation
	 *            the rotation to set
	 */
	public void setRotation(float rotation) {
		this.rotation = rotation;
	}

	/**
	 * @return the scale
	 */
	public Vector3f getScale() {
		return scale;
	}

	/**
	 * @param scale
	 *            the scale to set
	 */
	public void setScale(Vector3f scale) {
		this.scale = scale;
	}

	/**
	 * @return the clearColor
	 */
	public Vector4f getClearColor() {
		return clearColor;
	}

	/**
	 * @param clearColor the clearColor to set
	 */
	public void setClearColor(Vector4f clearColor) {
		this.clearColor = clearColor;
	}

	@Override
	public void render(GuiRenderer renderer) {
		if (!isVisible()) {
			return;
		}

		if (content != null && renderer != null) {
			fbo.bindFrameBuffer();
			this.renderer.setClearColor(clearColor);
			this.renderer.clear();
			this.renderer.clearEntitys();
			this.renderer.processEntity(new Entity(new Vector3f(0f, 0f, distance), 0f, rotation, 0f, scale, content));
			this.renderer.render(Instances.IDENTITY_MATRIX, new Vector3f());
			this.renderer.clearEntitys();
			fbo.unbindFrameBuffer();
			fbo.resolveToFbo(GL30.GL_COLOR_ATTACHMENT0, buffer2);
		}

		renderer.renderImage(x, y, width, height, background, clip, alpha);
		renderer.renderImage(x, y, width, height, foreground, clip, alpha);
		renderer.renderImage(x, y, width, height, buffer2.getColourTexture(), clip, alpha);
	}

	@Override
	public void apply(CSSFile style) {
	}
}
