package de.kjEngine.core.awt;

import org.lwjgl.util.vector.Vector4f;

import de.kjEngine.core.util.Loader;

public class KColor {
	
	public static final KColor NONE = new KColor(new Vector4f());
	public static final KColor BLACK = new KColor(new Vector4f(0f, 0f, 0f, 1f));
	public static final KColor WHITE = new KColor(new Vector4f(1f, 1f, 1f, 1f));
	public static final KColor RED = new KColor(new Vector4f(1f, 0f, 0f, 1f));
	public static final KColor GREEN = new KColor(new Vector4f(0f, 1f, 0f, 1f));
	public static final KColor BLUE = new KColor(new Vector4f(0f, 0f, 1f, 1f));
	public static final KColor YELLOW = new KColor(new Vector4f(1f, 1f, 0f, 1f));
	public static final KColor PURPLE = new KColor(new Vector4f(1f, 0f, 1f, 1f));
	
	public static final KColor GRAY_09 = new KColor(new Vector4f(0.9f, 0.9f, 0.9f, 1f));
	public static final KColor GRAY_08 = new KColor(new Vector4f(0.8f, 0.8f, 0.8f, 1f));
	public static final KColor GRAY_07 = new KColor(new Vector4f(0.7f, 0.7f, 0.7f, 1f));
	public static final KColor GRAY_06 = new KColor(new Vector4f(0.6f, 0.6f, 0.6f, 1f));
	public static final KColor GRAY_05 = new KColor(new Vector4f(0.5f, 0.5f, 0.5f, 1f));
	public static final KColor GRAY_04 = new KColor(new Vector4f(0.4f, 0.4f, 0.4f, 1f));
	public static final KColor GRAY_03 = new KColor(new Vector4f(0.3f, 0.3f, 0.3f, 1f));	
	public static final KColor GRAY_02 = new KColor(new Vector4f(0.2f, 0.2f, 0.2f, 1f));
	public static final KColor GRAY_01 = new KColor(new Vector4f(0.1f, 0.1f, 0.1f, 1f));
	public static final KColor ORANGE = new KColor(new Vector4f(1f, 0.5f, 0f, 1f));
	public static final KColor LIGHT_BLUE = new KColor(new Vector4f(0.2f, 0.6f, 1f, 1f));
	
	private Vector4f color;
	private int id;
	
	public static void init() {
	}
	
	public KColor(Vector4f color) {
		setColor(color);
	}
	
	public KColor(float r, float g, float b, float a) {
		setColor(new Vector4f(r, g, b, a));
	}

	public Vector4f getColor() {
		return color;
	}

	public void setColor(Vector4f color) {
		this.color = color;
		id = Loader.loadColorToTexture(color);
	}

	public int getId() {
		return id;
	}
}
