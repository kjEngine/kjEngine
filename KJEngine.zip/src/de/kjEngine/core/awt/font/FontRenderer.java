package de.kjEngine.core.awt.font;

import static org.lwjgl.opengl.GL11.GL_BLEND;
import static org.lwjgl.opengl.GL11.GL_DEPTH_TEST;
import static org.lwjgl.opengl.GL11.GL_ONE_MINUS_SRC_ALPHA;
import static org.lwjgl.opengl.GL11.GL_SRC_ALPHA;
import static org.lwjgl.opengl.GL11.GL_TEXTURE_2D;
import static org.lwjgl.opengl.GL11.GL_TRIANGLES;
import static org.lwjgl.opengl.GL11.glBindTexture;
import static org.lwjgl.opengl.GL11.glBlendFunc;
import static org.lwjgl.opengl.GL11.glDisable;
import static org.lwjgl.opengl.GL11.glDrawArrays;
import static org.lwjgl.opengl.GL11.glEnable;
import static org.lwjgl.opengl.GL13.GL_TEXTURE0;
import static org.lwjgl.opengl.GL13.glActiveTexture;
import static org.lwjgl.opengl.GL20.glDisableVertexAttribArray;
import static org.lwjgl.opengl.GL20.glEnableVertexAttribArray;
import static org.lwjgl.opengl.GL30.glBindVertexArray;

import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector4f;

import de.kjEngine.core.api.Cleanable;
import de.kjEngine.core.model.Rectangle;

/**
 * This is for rendering texts.
 * 
 * @author konst_df8d75v
 *
 */
public class FontRenderer implements Cleanable {
	
	private static final Matrix4f IDENTITY = Matrix4f.setIdentity(new Matrix4f());

	private FontShader shader;
	
	/**
	 * Creates a new fontRenderer.
	 */
	public FontRenderer() {
		shader = new FontShader();
	}
	
	/**
	 * Deletes the fontShader.
	 */
	@Override
	public void cleanUp(){
		shader.cleanUp();
	}
	
	/**
	 * @param text The text that should be rendered.
	 */
	public void render(Text text, Rectangle clip, Matrix4f transform) {
		prepare();
		renderText(text.getText(), clip, transform);
		endRendering();
	}
	
	/**
	 * @param text The text that should be rendered.
	 */
	public void render(Text text, Rectangle clip) {
		prepare();
		renderText(text.getText(), clip, IDENTITY);
		endRendering();
	}
	
	/**
	 * Prepares the rendering;
	 */
	private void prepare(){
		shader.enable();
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		glDisable(GL_DEPTH_TEST);
	}
	
	/**
	 * Renders the text.
	 * @param text the text that should be rendered.
	 */
	private void renderText(GUIText text, Rectangle clip, Matrix4f transform){
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, text.getFont().getTextureAtlas());
		
		glBindVertexArray(text.getMesh());
		glEnableVertexAttribArray(0);
		glEnableVertexAttribArray(1);
		
		shader.loadColor(new Vector4f(text.getColour().x, text.getColour().y, text.getColour().z, 1f));
		shader.loadPosition(text.getPosition());
		shader.loadClipPlane(clip);
		shader.loadDisplayBounds();
		shader.transform.loadMatrix(transform);
		
		glDrawArrays(GL_TRIANGLES, 0, text.getVertexCount());
		
		glDisableVertexAttribArray(0);
		glDisableVertexAttribArray(1);
		glBindVertexArray(0);
	}
	
	/**
	 * Ends the rendering. (resets gl-settings and disables the shader)
	 */
	private void endRendering(){
		glDisable(GL_BLEND);
		glEnable(GL_DEPTH_TEST);
		shader.disable();
	}
}
