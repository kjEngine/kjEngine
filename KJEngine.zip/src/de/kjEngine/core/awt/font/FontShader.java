package de.kjEngine.core.awt.font;

import static org.lwjgl.opengl.GL20.*;

import org.lwjgl.opengl.Display;
import org.lwjgl.util.vector.*;

import de.kjEngine.core.*;
import de.kjEngine.core.api.Shader;
import de.kjEngine.core.model.Rectangle;
import de.kjEngine.core.uniforms.UniformMat4;

/**
 * Handles the Shader that renders the texts.
 * 
 * @author konst_df8d75v
 *
 */
public class FontShader extends Shader {

	private static final String VERTEX_FILE = "/de/kjEngine/core/awt/font/fontVertex.glsl";
	private static final String FRAGMENT_FILE = "/de/kjEngine/core/awt/font/fontFragment.glsl";
	
	private int colorLoc, posLoc;
	private int cpxLoc, cpyLoc, cpwLoc, cphLoc;
	private int widthLoc, heightLoc;
	
	public UniformMat4 transform;
	
	/**
	 * Creates a new FontShader.
	 */
	public FontShader() {
		super(VERTEX_FILE, FRAGMENT_FILE);
	}
	
	/**
	 * Loads all the uniform locations.
	 */
	@Override
	protected void loadUniformLocations() {	
		colorLoc = glGetUniformLocation(id, "color");
		posLoc = glGetUniformLocation(id, "position");
		loadClipAttribbs();
		loadDisplayBoundUniforms();
		transform = new UniformMat4(id, "transform");
	}
	

	/**
	 * Loads the uniform locations of the attributes of the 'clip plane'.
	 */
	private void loadClipAttribbs() {
		cpxLoc = glGetUniformLocation(id, "clip.x");
		cpyLoc = glGetUniformLocation(id, "clip.y");
		cpwLoc = glGetUniformLocation(id, "clip.width");
		cphLoc = glGetUniformLocation(id, "clip.height");
	}
	
	/**
	 * Loads the uniform locations of the display bounds uniforms.
	 */
	private void loadDisplayBoundUniforms() {
		widthLoc = glGetUniformLocation(id, "width");
		heightLoc = glGetUniformLocation(id, "height");
	}
	
	/**
	 * Deletes the Shader.
	 */
	@Override
	public void cleanUp() {	
		glDeleteProgram(id);
	}
	
	/**
	 * Loads the text-color to the shader.
	 * @param color the text-color.
	 */
	public void loadColor(Vector4f color) {
		loadVector(colorLoc, color);
	}
	
	/**
	 * Loads the text-position to the shader.
	 * @param position the text-position.
	 */
	public void loadPosition(Vector2f position) {
		loadVector(posLoc, position);
	}
	
	/**
	 * Loads the attributes of the clip plane;
	 * 
	 * @param r
	 */
	public void loadClipPlane(Rectangle r) {
		loadFloat(cpxLoc, r.x);
		loadFloat(cpyLoc, r.y);
		loadFloat(cpwLoc, r.width);
		loadFloat(cphLoc, r.height);
	}
	
	/**
	 * Loads the bounds of the display to the shader.
	 */
	public void loadDisplayBounds() {
		loadFloat(widthLoc, 1f / Display.getWidth());
		loadFloat(heightLoc, 1f / Display.getHeight());
	}
}
