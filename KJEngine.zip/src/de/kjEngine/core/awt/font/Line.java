package de.kjEngine.core.awt.font;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a line of text during the loading of a text.
 * 
 * @author Karl
 *
 */
public class Line {

	private double maxLength;
	private double spaceSize;
	private double toMax;
	private boolean clamp;

	private List<Word> words = new ArrayList<Word>();
	private double currentLineLength = 0;

	/**
	 * Creates an empty line.
	 * 
	 * @param spaceWidth
	 *            - the screen-space width of a space character.
	 * @param fontSize
	 *            - the size of font being used.
	 * @param maxLength
	 *            - the screen-space maximum length of a line.
	 */
	public Line(double spaceWidth, double fontSize, double maxLength, boolean clamp) {
		this.spaceSize = spaceWidth * fontSize;
		this.maxLength = maxLength;
		toMax = maxLength;
		this.clamp = clamp;
	}

	/**
	 * Attempt to add a word to the line. If the line can fit the word in
	 * without reaching the maximum line length then the word is added and the
	 * line length increased.
	 * 
	 * @param word
	 *            - the word to try to add.
	 * @return {@code true} if the word has successfully been added to the line.
	 */
	protected boolean attemptToAddWord(Word word) {
		double additionalLength = word.getWordWidth();
		additionalLength += !words.isEmpty() ? spaceSize : 0;
		if (currentLineLength + additionalLength <= maxLength) {
			words.add(word);
			currentLineLength += additionalLength;
			toMax -= additionalLength;
			return true;
		} else {
			if (clamp && words.size() > 1) {
				int spaces = words.size() - 1;
				spaceSize += toMax / spaces;
				currentLineLength = maxLength;
			}
			return false;
		}
	}

	/**
	 * @return The max length of the line.
	 */
	public double getMaxLength() {
		return maxLength;
	}

	/**
	 * @return The current screen-space length of the line.
	 */
	public double getLineLength() {
		return currentLineLength;
	}

	/**
	 * @return The list of words in the line.
	 */
	public List<Word> getWords() {
		return words;
	}
	
	public List<Character> getCharacters() {
		List<Character> result = new ArrayList<>();
		for (Word w : words) {
			result.addAll(w.getCharacters());
		}
		return result;
	}

	public double getToMax() {
		return toMax;
	}

	public double getSpaceSize() {
		return spaceSize;
	}
}
