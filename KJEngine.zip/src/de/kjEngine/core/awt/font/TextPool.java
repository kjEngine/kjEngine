package de.kjEngine.core.awt.font;

import java.util.HashSet;
import java.util.Set;

import org.lwjgl.util.vector.Vector2f;

import de.kjEngine.core.util.Loader;

public class TextPool {

	private static Set<TextData> texts = new HashSet<>();

	public static Text createText(FontType font, String text, float fontSize, boolean centered, float maxLineLength,
			Vector2f position, boolean clamped) {
		TextData txt = new TextData(text, fontSize, font, maxLineLength, centered, clamped);
		if (texts.contains(txt)) {
			Text t = new Text(font, new GUIText(txt, position));
			return t;
		}
		GUIText t = new GUIText(txt, position);
		TextMeshData data = font.loadText(t);
		int vao = Loader.loadModel2D(data.getVertexPositions(), data.getTextureCoords());
		t.setMeshInfo(vao, data.getVertexCount());
		texts.add(t);
		return new Text(font, t);
	}
}
