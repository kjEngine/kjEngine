package de.kjEngine.core.awt.font;

import org.lwjgl.util.vector.Vector2f;

import de.kjEngine.core.util.Loader;

public class Text {

	private FontType font;
	private GUIText text;

	public Text(FontType font, GUIText text) {
		setFont(font);
		setText(text);
	}

	public FontType getFont() {
		return font;
	}

	public void setFont(FontType font) {
		this.font = font;
	}

	public GUIText getText() {
		return text;
	}

	public void setText(GUIText text) {
		if (this.text != null) {
			this.text.cleanUp();
		}
		TextMeshData data = font.loadText(text);
		int vao = Loader.loadModel2D(data.getVertexPositions(), data.getTextureCoords());
		text.setMeshInfo(vao, data.getVertexCount());
		this.text = text;
	}
	
	public static Text valueOf(String text) {
		return valueOf(text, 1f);
	}
	
	public static Text valueOf(String text, float fontSize) {
		return valueOf(FontType.ARIAL, text, fontSize, true);
	}
	
	public static Text valueOf(FontType font, String text, float fontSize) {
		return valueOf(font, text, fontSize, true);
	}
	
	public static Text valueOf(FontType font, String text, float fontSize, boolean centered) {
		return valueOf(font, text, fontSize, centered, 2f, new Vector2f());
	}
	
	public static Text valueOf(FontType font, String text, float fontSize, boolean centered, float maxLineLength) {
		return valueOf(font, text, fontSize, centered, maxLineLength, new Vector2f());
	}

	public static Text valueOf(FontType font, String text, float fontSize, boolean centered, float maxLineLength,
			Vector2f position) {
		return TextPool.createText(font, text, fontSize, centered, maxLineLength, position, false);
	}
}
