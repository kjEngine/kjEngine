package de.kjEngine.core.awt.font;

import static org.lwjgl.opengl.GL30.*;

import org.lwjgl.util.vector.Vector2f;

import de.kjEngine.core.api.Cleanable;

/**
 * Represents a piece of text in the game.
 * 
 * @author Karl
 *
 */
public class GUIText extends TextData implements Cleanable {

	private Vector2f position;

	/**
	 * Creates a new text, loads the text's quads into a VAO, and adds the text
	 * to the screen.
	 * 
	 * @param text
	 *            - the text.
	 * @param fontSize
	 *            - the font size of the text, where a font size of 1 is the
	 *            default size.
	 * @param font
	 *            - the font that this text should use.
	 * @param position
	 *            - the position on the screen where the top left corner of the
	 *            text should be rendered. The top left corner of the screen is
	 *            (0, 0) and the bottom right is (1, 1).
	 * @param maxLineLength
	 *            - basically the width of the virtual page in terms of screen
	 *            width (1 is full screen width, 0.5 is half the width of the
	 *            screen, etc.) Text cannot go off the edge of the page, so if
	 *            the text is longer than this length it will go onto the next
	 *            line. When text is centered it is centered into the middle of
	 *            the line, based on this line length value.
	 * @param centered
	 *            - whether the text should be centered or not.
	 */
	public GUIText(String text, float fontSize, FontType font, Vector2f position, float maxLineLength, boolean centered,
			boolean clamped) {
		super(text, fontSize, font, maxLineLength, centered, clamped);
		setPosition(position);
	}

	public GUIText(TextData txt, Vector2f position) {
		super(txt.getTextString(), txt.getFontSize(), txt.getFont(), txt.getMaxLineSize(), txt.isCentered(),
				txt.isClamped());
		setPosition(position);
	}

	/**
	 * @param position
	 *            The position the text should have.
	 */
	public void setPosition(Vector2f position) {
		this.position = position;
	}

	/**
	 * @return The position of the top-left corner of the text in screen-space.
	 *         (0, 0) is the top left corner of the screen, (1, 1) is the bottom
	 *         right.
	 */
	public Vector2f getPosition() {
		return position;
	}

	@Override
	public void cleanUp() {
		glDeleteVertexArrays(getMesh());
	}
}
