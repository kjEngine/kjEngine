package de.kjEngine.core.awt;

import java.util.ArrayList;
import java.util.List;

import de.kjEngine.core.awt.font.Character;
import de.kjEngine.core.awt.font.GUIText;
import de.kjEngine.core.awt.font.Line;
import de.kjEngine.core.awt.font.Word;
import de.kjEngine.core.awt.rendering.GuiRenderer;

public class KCaret extends KLabel {

	private int position, prev_position;
	private int blinkDelay;
	private long lastChange;
	private boolean visibilityAnim;
	private boolean writing;
	private long lastInput;

	public KCaret(KTextInputGui parent) {
		super(0f, 0f, 0.002f, 0.01f, KColor.BLACK);
		setParent(parent);
	}

	public int getTxtPosition() {
		return position;
	}

	public void setTxtPosition(int position) {
		prev_position = this.position;
		this.position = position;
	}

	public int getTxtPrev_position() {
		return prev_position;
	}

	public void setTxtPrev_position(int prev_position) {
		this.prev_position = prev_position;
	}

	public void setParent(KTextInputGui parent) {
		if (parent == null)
			throw new NullPointerException();
		this.parent = parent;
	}

	public void update() {
		setX(getXP());
		setWidth(0.005f);
		setHeight(parent.getHeight());
	}

	private float getXP() {
		float l = 0f;
		GUIText txt = ((KTextInputGui) parent).getText().getText();
		Line line = txt.getLines().get(0);
		List<Word> ws = line.getWords();
		List<Character> cs = new ArrayList<>();
		for (Word w : ws) {
			for (Character c : w.getCharacters()) {
				cs.add(c);
			}
			cs.add(null);
		}
		for (int i = 0; i <= position; i++) {
			if (cs.get(i) != null) {
				l += cs.get(i).getxAdvance() * txt.getFontSize() * 2f;
			} else {
				l += line.getSpaceSize() * 2f;
			}
		}
		return l;
	}

	public void move(int a, boolean hold) {
		position += a;
		if (!hold) {
			prev_position += a;
		}
		position = Math.max(position, 0);
		prev_position = Math.max(prev_position, 0);
		writing = true;
		lastInput = System.currentTimeMillis();
	}

	public int getBlinkDelay() {
		return blinkDelay;
	}

	public void setBlinkDelay(int blinkDelay) {
		this.blinkDelay = blinkDelay;
	}

	@Override
	public void render(GuiRenderer renderer) {
		if (isVisible()) {
			if (System.currentTimeMillis() - lastChange > blinkDelay) {
				visibilityAnim = !visibilityAnim;
				lastChange = System.currentTimeMillis();
			}
		}
		if (System.currentTimeMillis() - lastInput > blinkDelay) {
			writing = false;
		}
		if (writing) {
			visibilityAnim = true;
		}
		if (visibilityAnim) {
			super.render(renderer);
		}
	}
}
