package de.kjEngine.core.awt.event;

import de.kjEngine.core.awt.KSpinner;

public interface KSpinnerListener {
	
	void valueChanged(KSpinner src);
}
