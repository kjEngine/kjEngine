package de.kjEngine.core.awt.event;

public interface KResetListener {
	
	void reset();
}
