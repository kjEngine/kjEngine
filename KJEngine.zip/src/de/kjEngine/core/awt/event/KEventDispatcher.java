package de.kjEngine.core.awt.event;

import java.util.List;

public class KEventDispatcher {

	private List<KEventListener> listeners;

	public KEventDispatcher(List<KEventListener> listeners) {
		this.listeners = listeners;
	}

	public void dispatch(KEventType type, int key, int dx, int dy, int d) {
		switch (type) {
		case KEY_PRESSED:
			for (int i = 0; KEventSheduler.isDispatching() && i < listeners.size(); i++)
				listeners.get(i).keyPressed(key);
			break;
		case KEY_RELEASED:
			for (int i = 0; KEventSheduler.isDispatching() && i < listeners.size(); i++)
				listeners.get(i).keyReleased(key);
			;
			break;
		case KEY_TYPED:
			for (int i = 0; KEventSheduler.isDispatching() && i < listeners.size(); i++)
				listeners.get(i).keyTyped(key);
			break;
		case MOUSE_CLICKED:
			for (int i = 0; KEventSheduler.isDispatching() && i < listeners.size(); i++)
				listeners.get(i).mouseClicked();
			break;
		case MOUSE_DRAGGED:
			for (int i = 0; KEventSheduler.isDispatching() && i < listeners.size(); i++)
				listeners.get(i).mouseDragged(dx, dy);
			break;
		case MOUSE_MOVED:
			for (int i = 0; KEventSheduler.isDispatching() && i < listeners.size(); i++)
				listeners.get(i).mouseMoved(dx, dy);
			break;
		case MOUSE_PRESSED:
			for (int i = 0; KEventSheduler.isDispatching() && i < listeners.size(); i++)
				listeners.get(i).mousePressed();
			break;
		case MOUSE_RELEASED:
			for (int i = 0; KEventSheduler.isDispatching() && i < listeners.size(); i++)
				listeners.get(i).mouseReleased();
			break;
		case MOUSE_WHEEL_MOVED:
			for (int i = 0; KEventSheduler.isDispatching() && i < listeners.size(); i++)
				listeners.get(i).mouseWheelMoved(d);
			break;
		}
	}

	public List<KEventListener> getListeners() {
		return listeners;
	}

	public void setListeners(List<KEventListener> listeners) {
		this.listeners = listeners;
	}
}
