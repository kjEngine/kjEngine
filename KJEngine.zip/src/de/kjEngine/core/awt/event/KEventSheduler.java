package de.kjEngine.core.awt.event;

public class KEventSheduler {
	
	private static boolean dispatching = false;
	
	public static void start() {
		dispatching = true;
	}
	
	public static void stop() {
		dispatching = false;
	}
	
	public static boolean isDispatching() {
		return dispatching;
	}
}
