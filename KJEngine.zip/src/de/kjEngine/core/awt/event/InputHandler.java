package de.kjEngine.core.awt.event;

import java.util.ArrayList;
import java.util.List;

import org.lwjgl.LWJGLException;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

public class InputHandler {

	private static int mouseX, mouseY;
	private static boolean mousePressed;
	public static boolean[] keys = new boolean[68836];
	private static Thread updater;
	private static List<KEventListener> listeners = new ArrayList<>();
	private static int mouseWheelPos;

	private InputHandler() {
	}

	public static void start() {
		try {
			Keyboard.create();
		} catch (LWJGLException e1) {
			e1.printStackTrace();
		}
		updater = new Thread(new Runnable() {

			@Override
			public void run() {
				while (true) {
					try {
						update();
						Thread.sleep(20);
					} catch (Exception e) {
						e.printStackTrace();
						continue;
					}
				}
			}
		});
		updater.start();
	}

	private static void update() {
		if (!Mouse.isCreated() || !Keyboard.isCreated())
			return;
		try {
			if (mouseX != Mouse.getX() || mouseY != Mouse.getY()) {
				KEventSheduler.start();
				int dx = Mouse.getX() - mouseX;
				int dy = Mouse.getY() - mouseY;
				for (KEventListener l : listeners)
					if (Mouse.isButtonDown(0))
						l.mouseDragged(dx, dy);
					else
						l.mouseMoved(dx, dy);
			}
			mouseX = Mouse.getX();
			mouseY = Mouse.getY();

			if (mousePressed != Mouse.isButtonDown(0)) {
				KEventSheduler.start();
				for (KEventListener l : listeners)
					if (Mouse.isButtonDown(0))
						l.mousePressed();
					else {
						l.mouseReleased();
						l.mouseClicked();
					}
			}
			mousePressed = Mouse.isButtonDown(0);

			for (int i = 0; i < Keyboard.getKeyCount(); i++) {
				if (keys[i] != Keyboard.isKeyDown(i)) {
					KEventSheduler.start();
					int key = Keyboard.getEventCharacter();
					Keyboard.next();
					for (KEventListener l : listeners) {
						if (Keyboard.isKeyDown(i))
							l.keyPressed(key);
						else {
							l.keyReleased(key);
							l.keyTyped(key);
						}
					}
					keys[i] = Keyboard.isKeyDown(i);
					break;
				}
			}

			if (Mouse.hasWheel()) {
				int d = Mouse.getDWheel() / 120;
				if (d != 0) {
					mouseWheelPos += d;
					for (KEventListener l : listeners) {
						l.mouseWheelMoved(d);
					}
				}
			}
		} catch (IllegalStateException e) {
			return;
		}
	}

	public static void addKEventListener(KEventListener l) {
		listeners.add(l);
	}

	public static void removeKEventListener(KEventListener l) {
		listeners.remove(l);
	}

	public static int getMouseX() {
		return mouseX;
	}

	public static int getMouseY() {
		return mouseY;
	}

	public static boolean isMousePressed() {
		return mousePressed;
	}

	public static boolean[] getKeys() {
		return keys;
	}

	public static int getMouseWheelPos() {
		return mouseWheelPos;
	}
}
