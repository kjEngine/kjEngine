package de.kjEngine.core.awt.event;

public enum KEventType {
	
	MOUSE_MOVED(0), MOUSE_DRAGGED(1), MOUSE_PRESSED(2), MOUSE_RELEASED(3), MOUSE_CLICKED(4), KEY_PRESSED(5),
	KEY_RELEASED(6), KEY_TYPED(7), MOUSE_WHEEL_MOVED(8);
	
	private int id;
	
	private KEventType(int id) {
		this.id = id;
	}
	
	public int getId() {
		return id;
	}
}
