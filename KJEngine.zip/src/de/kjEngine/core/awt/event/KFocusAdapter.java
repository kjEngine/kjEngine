package de.kjEngine.core.awt.event;

import de.kjEngine.core.awt.Gui;

public class KFocusAdapter implements KFocusListener {

	@Override
	public void focusGained(Gui src) {
	}

	@Override
	public void focusLost(Gui src) {
	}

	@Override
	public void focusChanged(Gui src) {
	}
}
