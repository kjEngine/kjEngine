package de.kjEngine.core.awt.event;

import de.kjEngine.core.awt.Gui;

public interface KVisibilityChangeListener {
	
	void visibilityChanged(Gui src);
}
