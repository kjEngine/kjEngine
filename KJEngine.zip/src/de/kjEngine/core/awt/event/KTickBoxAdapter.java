package de.kjEngine.core.awt.event;

import de.kjEngine.core.awt.Gui;
import de.kjEngine.core.awt.KTickBox;

public class KTickBoxAdapter implements KTickBoxListener {

	@Override
	public void entered(Gui gui) {
	}

	@Override
	public void exited(Gui gui) {
	}

	@Override
	public void activated(KTickBox e) {
	}

	@Override
	public void deactivated(KTickBox e) {
	}
}
