package de.kjEngine.core.awt.event;

import de.kjEngine.core.awt.Gui;

/**
 * Interface for handling mouseover events.
 * 
 * @author konst_df8d75v
 *
 */
public interface HoverListener {
	
	/**
	 * This method gets called when the mouse has entered the bounds of the gui.
	 * @param gui The gui that detected the event. 
	 */
	void entered(Gui gui);
	
	/**
	 * This method gets called when the mouse has exited the bounds of the gui.
	 * @param gui The gui that detected the event. 
	 */
	void exited(Gui gui);
}
