package de.kjEngine.core.awt.event;

import java.util.ArrayList;
import java.util.List;

public class KButtonController {
	
	private static List<KResetListener> listeners = new ArrayList<>();
	
	public static void addKResetListener(KResetListener l) {
		listeners.add(l);
	}
	
	public static void removeKResetListener(KResetListener l) {
		listeners.remove(l);
	}
	
	public static void callReset() {
		for(KResetListener l : listeners)
			l.reset();
	}
}
