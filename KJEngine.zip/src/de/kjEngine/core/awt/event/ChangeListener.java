package de.kjEngine.core.awt.event;

public interface ChangeListener extends MovementListner, ResizeListener {

}
