package de.kjEngine.core.awt.event;

import de.kjEngine.core.awt.Gui;

public interface KFocusListener {

	void focusGained(Gui src);
	void focusLost(Gui src);
	void focusChanged(Gui src);
}
