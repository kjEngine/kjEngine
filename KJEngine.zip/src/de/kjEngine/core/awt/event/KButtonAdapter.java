package de.kjEngine.core.awt.event;

import de.kjEngine.core.awt.Gui;

public class KButtonAdapter implements KButtonListener {

	@Override
	public void entered(Gui gui) {
	}

	@Override
	public void exited(Gui gui) {
	}

	@Override
	public void pressed(Gui gui) {
	}

	@Override
	public void released(Gui gui) {
	}

	@Override
	public void clicked(Gui gui) {
	}
}
