package de.kjEngine.core.awt.event;

import de.kjEngine.core.awt.Gui;

public interface EnterListener {

	void enter(Gui src);
}
