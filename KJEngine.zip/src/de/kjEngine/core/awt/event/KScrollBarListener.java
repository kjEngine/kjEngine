package de.kjEngine.core.awt.event;

public interface KScrollBarListener {
	
	void valueChanged(float value);
}
