package de.kjEngine.core.awt.event;

import de.kjEngine.core.awt.Gui;

public interface KButtonListener extends HoverListener {
	
	void pressed(Gui gui);
	void released(Gui gui);
	void clicked(Gui gui);
}
