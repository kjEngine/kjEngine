package de.kjEngine.core.awt.event;

import de.kjEngine.core.awt.KComboBox;

public interface KComboBoxListener {
	
	void selectionChanged(KComboBox src);
}
