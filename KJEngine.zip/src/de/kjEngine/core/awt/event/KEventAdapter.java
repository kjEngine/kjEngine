package de.kjEngine.core.awt.event;

public class KEventAdapter implements KEventListener {

	@Override
	public void mousePressed() {
	}

	@Override
	public void mouseReleased() {
	}

	@Override
	public void mouseClicked() {
	}

	@Override
	public void mouseMoved(int dx, int dy) {
	}

	@Override
	public void mouseDragged(int dx, int dy) {
	}

	@Override
	public void keyPressed(int key) {
	}

	@Override
	public void keyReleased(int key) {
	}

	@Override
	public void keyTyped(int key) {
	}

	@Override
	public void mouseWheelMoved(int d) {
	}
}
