package de.kjEngine.core.awt.event;

public class KScrollBarAdapter implements KScrollBarListener {

	@Override
	public void valueChanged(float value) {
	}
}
