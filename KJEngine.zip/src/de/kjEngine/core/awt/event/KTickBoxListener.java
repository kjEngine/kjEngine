package de.kjEngine.core.awt.event;

import de.kjEngine.core.awt.KTickBox;

public interface KTickBoxListener extends HoverListener {
	
	void activated(KTickBox e);
	void deactivated(KTickBox e);
}
