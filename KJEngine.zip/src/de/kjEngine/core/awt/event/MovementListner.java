package de.kjEngine.core.awt.event;

public interface MovementListner {

	void move(float x, float y);
}
