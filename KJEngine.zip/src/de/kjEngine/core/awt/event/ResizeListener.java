package de.kjEngine.core.awt.event;

public interface ResizeListener {
	
	void resize(float width, float height);
}
