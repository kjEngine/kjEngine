package de.kjEngine.core.awt.event;

public interface FrameListener {
	
	void frame(float delta);
}
