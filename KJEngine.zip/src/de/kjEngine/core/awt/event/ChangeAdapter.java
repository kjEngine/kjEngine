package de.kjEngine.core.awt.event;

public class ChangeAdapter implements ChangeListener {

	@Override
	public void move(float x, float y) {
	}

	@Override
	public void resize(float width, float height) {
	}
}
