package de.kjEngine.core.awt.event;

public interface KEventListener {
	
	void mousePressed();
	void mouseReleased();
	void mouseClicked();
	
	void mouseMoved(int dx, int dy);
	void mouseDragged(int dx, int dy);
	
	void mouseWheelMoved(int d);
	
	void keyPressed(int key);
	void keyReleased(int key);
	void keyTyped(int key);
}
