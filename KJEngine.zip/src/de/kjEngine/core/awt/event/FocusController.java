package de.kjEngine.core.awt.event;

import java.util.ArrayList;
import java.util.List;

import de.kjEngine.core.awt.Gui;

public class FocusController {
	
	private static List<KFocusListener> listeners = new ArrayList<>();
	private static Gui focusedGui;
	
	public static void addKFocusListener(KFocusListener l) {
		listeners.add(l);
	}

	public static void removeKFocusListener(KFocusListener l) {
		listeners.remove(l);
	}
	
	public static void resetFocus() {
		for (KFocusListener l : listeners) {
			l.focusLost(null);
		}
	}

	public static Gui getFocusedGui() {
		return focusedGui;
	}

	public static void setFocusedGui(Gui focusedGui) {
		FocusController.focusedGui = focusedGui;
	}
}
