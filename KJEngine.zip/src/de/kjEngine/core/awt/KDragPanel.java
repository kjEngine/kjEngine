package de.kjEngine.core.awt;

import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;
import org.lwjgl.util.vector.Vector2f;

import de.kjEngine.core.awt.event.KEventListener;
import de.kjEngine.core.awt.event.KEventSheduler;
import de.kjEngine.core.awt.event.KEventType;

public class KDragPanel extends KPanel {

	private boolean xMovement, yMovement;
	private boolean pressed;

	public KDragPanel(float x, float y, float width, float height, float r, float g, float b, float a) {
		super(x, y, width, height, r, g, b, a);
		init();
	}

	public KDragPanel(float x, float y, float width, float height, KColor fg) {
		super(x, y, width, height, fg);
		init();
	}

	public KDragPanel(float x, float y, float width, float height) {
		super(x, y, width, height);
		init();
	}

	private void init() {
		listener = new KEventListener() {

			@Override
			public void mouseReleased() {
				if (pressed) {
					KEventSheduler.stop();
				}
				pressed = false;
				dispatcher.dispatch(KEventType.MOUSE_RELEASED, 0, 0, 0, 0);
			}

			@Override
			public void mousePressed() {
				float nx = KDragPanel.this.getAbsolutePosition().x;
				float ny = KDragPanel.this.getAbsolutePosition().y;

				float mx = ((float) Mouse.getX() / (float) Display.getWidth()) * 2f - 1f;
				float my = ((float) Mouse.getY() / (float) Display.getHeight()) * 2f - 1f;

				boolean h = !(mx < nx || my < ny || mx > nx + KDragPanel.this.width
						|| my > ny + KDragPanel.this.height);

				pressed = h;
				dispatcher.dispatch(KEventType.MOUSE_PRESSED, 0, 0, 0, 0);
			}

			@Override
			public void mouseMoved(int dx, int dy) {
				dispatcher.dispatch(KEventType.MOUSE_MOVED, 0, dx, dy, 0);
			}

			@Override
			public void mouseDragged(int dx, int dy) {
				if (pressed) {
					Vector2f df = DisplayManager.toGLCoords(dx, dy);
					if (xMovement) {
						x += df.x;
					}
					if (yMovement) {
						y += df.y;
					}
					KEventSheduler.stop();
				}
				dispatcher.dispatch(KEventType.MOUSE_DRAGGED, 0, dx, dy, 0);
			}

			@Override
			public void mouseClicked() {
				dispatcher.dispatch(KEventType.MOUSE_CLICKED, 0, 0, 0, 0);
			}

			@Override
			public void keyTyped(int key) {
				dispatcher.dispatch(KEventType.KEY_TYPED, key, 0, 0, 0);
			}

			@Override
			public void keyReleased(int key) {
				dispatcher.dispatch(KEventType.KEY_RELEASED, key, 0, 0, 0);
			}

			@Override
			public void keyPressed(int key) {
				dispatcher.dispatch(KEventType.KEY_PRESSED, key, 0, 0, 0);
			}

			@Override
			public void mouseWheelMoved(int d) {
				dispatcher.dispatch(KEventType.KEY_PRESSED, 0, 0, 0, d);
			}
		};
	}

	/**
	 * @return the xMovement
	 */
	public boolean isxMovement() {
		return xMovement;
	}

	/**
	 * @param xMovement
	 *            the xMovement to set
	 */
	public void setxMovement(boolean xMovement) {
		this.xMovement = xMovement;
	}

	/**
	 * @return the yMovement
	 */
	public boolean isyMovement() {
		return yMovement;
	}

	/**
	 * @param yMovement
	 *            the yMovement to set
	 */
	public void setyMovement(boolean yMovement) {
		this.yMovement = yMovement;
	}

	/**
	 * @return the pressed
	 */
	public boolean isPressed() {
		return pressed;
	}
}
