package de.kjEngine.core.awt;

import de.kjEngine.core.awt.event.ResizeListener;
import de.kjEngine.core.awt.font.FontType;
import de.kjEngine.core.math.KMath;

public class KFrame extends KPanel {

	private KPanel uppperBar;
	private KButton exit;
	private float upperBarHeight = 0.1f;

	public KFrame() {
		init();
	}

	public KFrame(float x, float y, float width, float height) {
		super(x, y, width, height);
		init();
	}

	public KFrame(float x, float y, float width, float height, KColor fg) {
		super(x, y, width, height, fg);
		init();
	}

	private void init() {
		uppperBar = new KPanel(0f, height - upperBarHeight, width, upperBarHeight, KColor.GRAY_04);
		add(uppperBar);

		addResizeListener(new ResizeListener() {

			@Override
			public void resize(float width, float height) {
				update(width, height);
			}
		});

		exit = new KButton(width - upperBarHeight / DisplayManager.getAspect(), 0f,
				upperBarHeight / DisplayManager.getAspect(), upperBarHeight, KColor.NONE, null);
		exit.setText(0.03f, FontType.ARIAL, "X");
		addToUpperBar(exit);
	}

	private void update(float width, float height) {
		uppperBar.setBounds(0f, height - upperBarHeight, width, upperBarHeight);
		exit.setBounds(width - upperBarHeight / DisplayManager.getAspect(), 0f,
				upperBarHeight / DisplayManager.getAspect(), upperBarHeight);
	}

	public KPanel getUppperBar() {
		return uppperBar;
	}

	public float getUpperBarHeight() {
		return upperBarHeight;
	}

	public void setUppperBar(KPanel uppperBar) {
		this.uppperBar = uppperBar;
		update(width, height);
	}

	public void setUpperBarHeight(float upperBarHeight) {
		this.upperBarHeight = upperBarHeight;
		update(width, height);
	}

	public void addToUpperBar(Gui e) {
		e.setY(0f);
		e.setWidth(upperBarHeight / DisplayManager.getAspect());
		e.setHeight(upperBarHeight);
		uppperBar.add(e);
	}

	public void addToPane(Gui e) {
		e.x = KMath.clamp(e.x, 0f, width - e.getWidth());
		e.y = KMath.clamp(e.y, 0f, height - e.getHeight());
		add(e);
	}

	public KButton getExit() {
		return exit;
	}
}
