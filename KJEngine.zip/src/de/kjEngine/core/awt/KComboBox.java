package de.kjEngine.core.awt;

import java.util.ArrayList;
import java.util.List;

import de.kjEngine.core.api.KUtillities;
import de.kjEngine.core.awt.css.CSSFile;
import de.kjEngine.core.awt.event.KButtonAdapter;
import de.kjEngine.core.awt.event.KButtonListener;
import de.kjEngine.core.awt.event.KComboBoxListener;
import de.kjEngine.core.awt.event.KEventListener;
import de.kjEngine.core.awt.event.KFocusListener;
import de.kjEngine.core.awt.font.FontType;
import de.kjEngine.core.awt.rendering.GuiRenderer;

public class KComboBox extends KTextContainer {

	private List<KButton> elements = new ArrayList<>();
	private KButton selectedElement;
	private KButton collapseButton;
	private boolean collapsed;
	private List<KComboBoxListener> comboBoxListeners = new ArrayList<>();
	private KButtonListener defaultListener;

	public KComboBox() {
		this(0f, 0f, 0f, 0f, FontType.ARIAL, 1f);
	}

	public KComboBox(float x, float y, float width, float height, FontType font, float fontSize) {
		super(x, y, width, height);

		setFontSize(fontSize);
		setFont(font);

		addEVListener(new KEventListener() {

			@Override
			public void mouseReleased() {
			}

			@Override
			public void mousePressed() {
			}

			@Override
			public void mouseMoved(int dx, int dy) {
			}

			@Override
			public void mouseDragged(int dx, int dy) {
			}

			@Override
			public void mouseClicked() {
			}

			@Override
			public void keyTyped(int key) {
			}

			@Override
			public void keyReleased(int key) {
			}

			@Override
			public void keyPressed(int key) {
			}

			@Override
			public void mouseWheelMoved(int d) {
			}
		});

		selectedElement = new KButton(0, 0, width, height);
		selectedElement.setBackground(background);
		selectedElement.setForeground(foreground);
		selectedElement.setText(fontSize, font, false, "");
		selectedElement.setParent(this);
		selectedElement.addKButtonListener(new KButtonListener() {

			@Override
			public void exited(Gui gui) {
			}

			@Override
			public void entered(Gui gui) {
			}

			@Override
			public void released(Gui gui) {
			}

			@Override
			public void pressed(Gui gui) {
			}

			@Override
			public void clicked(Gui gui) {
			}
		});
		selectedElement.setVisible(true);

		collapseButton = new KButton(x + width * 0.9f, y, width * 0.1f, height, KColor.NONE, new KButtonAdapter() {

			@Override
			public void clicked(Gui gui) {
				setCollapsed(!isCollapsed());
			}
		});
		collapseButton.setText("");
		collapseButton.setParent(this);

		addKFocusListener(new KFocusListener() {

			@Override
			public void focusLost(Gui src) {
				setCollapsed(true);
			}

			@Override
			public void focusGained(Gui src) {
			}

			@Override
			public void focusChanged(Gui src) {
			}
		});
	}

	public void setSelectedElement(String e) {
		selectedElement.setText(e);
	}

	public void addElements(String[] elements) {
		for (String e : elements) {
			addElement(e);
		}
	}

	public void addElement(String element) {
		KButton e = new KButton(x, y - (elements.size() + 1) * height, width, height);
		e.setBackground(background);
		e.setForeground(foreground);
		e.setText(fontSize, font, false, element);
		e.setParent(this);
		e.addKButtonListener(defaultListener);
		e.addKButtonListener(new KButtonListener() {

			@Override
			public void exited(Gui gui) {
			}

			@Override
			public void entered(Gui gui) {
			}

			@Override
			public void released(Gui gui) {
			}

			@Override
			public void pressed(Gui gui) {
			}

			@Override
			public void clicked(Gui gui) {
				KButton b = (KButton) gui;
				KUtillities.invokeNext(() -> {
					selectedElement.setText(b.getText().getText().getTextString());
					for (KComboBoxListener l : comboBoxListeners) {
						l.selectionChanged(get());
					}
				});
			}
		});
		e.setVisible(true);
		elements.add(e);
	}

	public List<KButton> getElements() {
		return elements;
	}

	/**
	 * @return the selectedElement
	 */
	public KButton getSelectedElement() {
		return selectedElement;
	}

	public String getSelectedText() {
		return selectedElement.getText().getText().getTextString();
	}

	/**
	 * @return the collapsed
	 */
	public boolean isCollapsed() {
		return collapsed;
	}

	/**
	 * @param collapsed the collapsed to set
	 */
	public void setCollapsed(boolean collapsed) {
		this.collapsed = collapsed;
		for (KButton e : elements)
			e.setVisible(!collapsed);
	}

	/**
	 * @return the collapseButton
	 */
	public KButton getCollapseButton() {
		return collapseButton;
	}

	public KComboBox get() {
		return this;
	}

	public void addKComboBoxListener(KComboBoxListener l) {
		comboBoxListeners.add(l);
	}

	public void removeKComboBoxListener(KComboBoxListener l) {
		comboBoxListeners.remove(l);
	}

	public KButtonListener getDefaultListener() {
		return defaultListener;
	}

	public void setDefaultListener(KButtonListener defaultListener) {
		this.defaultListener = defaultListener;
	}

	@Override
	public void render(GuiRenderer renderer) {
		float x = getAbsoluteX();
		float y = getAbsoluteY();

		renderer.renderImage(x, y, width, height, background, clip, alpha);
		renderer.renderImage(x, y, width, height, foreground, clip, alpha);

		for (KButton e : elements) {
			e.render(renderer);
			e.renderText(renderer);
		}
		selectedElement.render(renderer);
		selectedElement.renderText(renderer);
	}

	@Override
	public void apply(CSSFile style) {
	}

	@Override
	public List<Gui> uis() {
		List<Gui> result = new ArrayList<>();
		result.add(collapseButton);
		result.add(this);
		result.addAll(elements);
		return result;
	}
}
