package de.kjEngine.core.awt;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;
import org.lwjgl.util.vector.Vector2f;

import de.kjEngine.core.api.PGraphics;
import de.kjEngine.core.api.PGraphicsGLImpl;
import de.kjEngine.core.awt.animation.Animation;
import de.kjEngine.core.awt.css.AttribException;
import de.kjEngine.core.awt.css.CSSAttribute;
import de.kjEngine.core.awt.css.CSSFile;
import de.kjEngine.core.awt.event.ChangeListener;
import de.kjEngine.core.awt.event.FocusController;
import de.kjEngine.core.awt.event.FrameListener;
import de.kjEngine.core.awt.event.HoverListener;
import de.kjEngine.core.awt.event.KEventListener;
import de.kjEngine.core.awt.event.KFocusListener;
import de.kjEngine.core.awt.event.KVisibilityChangeListener;
import de.kjEngine.core.awt.event.MovementListner;
import de.kjEngine.core.awt.event.ResizeListener;
import de.kjEngine.core.awt.rendering.GuiRenderer;
import de.kjEngine.core.model.Rectangle;
import de.kjEngine.core.util.Loader;

/**
 * This class is the base of the kjEngine gui framework. It holds information
 * about the dimensions, the position, the visibility, the foreground-texture
 * and the background-texture of the gui. It can be rendered and updated. It
 * overrides {@code hashCode()}, {@code toString()} and {@code equals}.
 * 
 * @author konst_df8d75v
 *
 * @see java.awt.Component
 */
public abstract class Gui implements Cloneable, KContainer {

	/**
	 * The position.
	 */
	protected float x, y;

	/**
	 * The dimensions.
	 */
	protected float width, height;

	/**
	 * The visibility.
	 */
	protected boolean visible;

	/**
	 * The textures.
	 */
	protected int foreground, background;

	/**
	 * The parent Gui of the Gui.
	 */
	protected Gui parent;

	/**
	 * The KEventListener that detects events from the parents and handles them.
	 */
	protected KEventListener listener;
	protected List<KEventListener> evListeners = new CopyOnWriteArrayList<>();

	/**
	 * The mouseOver 'effect' that is shown if the mouse is over the gui.
	 */
	protected Gui mouseOver;

	/**
	 * The rectangle in which the gui will be visible.
	 */
	protected Rectangle clip;

	/**
	 * The resizelisteners of the gui.
	 */
	protected List<ResizeListener> resizeListeners = new CopyOnWriteArrayList<>();
	protected List<MovementListner> movementListners = new CopyOnWriteArrayList<>();

	/**
	 * The alpha component of the gui.
	 */
	protected float alpha = 1f;

	/**
	 * If the visibility changes are smooth or not.
	 */
	protected boolean smooth = false;

	protected String name;
	protected String typeName;

	protected PGraphics g;

	protected List<KVisibilityChangeListener> visibilityChangeListeners = new CopyOnWriteArrayList<>();

	protected List<Animation> animations = new CopyOnWriteArrayList<>();

	protected boolean resizable = true;

	protected boolean focused;
	protected boolean focusable = true;
	protected List<HoverListener> hoverListeners = new CopyOnWriteArrayList<>();
	protected List<KFocusListener> focusListeners = new CopyOnWriteArrayList<>();

	protected List<Integer> code = new CopyOnWriteArrayList<>();;

	/**
	 * Creates a new Gui with default values.
	 */
	public Gui() {
		this(0, 0, 0, 0);
	}

	/**
	 * Creates a new Gui with a position and a size.
	 * 
	 * @param x      the x position.
	 * @param y      the y position.
	 * @param width  the width
	 * @param height the height
	 */
	public Gui(float x, float y, float width, float height) {
		setBounds(x, y, width, height);

		listener = new KEventListener() {

			@Override
			public void mouseReleased() {
				for (KEventListener l : evListeners) {
					l.mouseReleased();
				}
			}

			@Override
			public void mousePressed() {
				for (KEventListener l : evListeners) {
					l.mousePressed();
				}
			}

			@Override
			public void mouseMoved(int dx, int dy) {
				float x = getAbsolutePosition().x;
				float y = getAbsolutePosition().y;
				if (Mouse.getX() > x && Mouse.getX() < x + width && Mouse.getY() > y && Mouse.getY() < y + height) {
					KCurser.setCurrentLabel(mouseOver);
				} else if (KCurser.getCurrentLabel() != mouseOver) {
					KCurser.setCurrentLabel(null);
				}
				for (KEventListener l : evListeners) {
					l.mouseMoved(dx, dy);
				}
			}

			@Override
			public void mouseDragged(int dx, int dy) {
				for (KEventListener l : evListeners) {
					l.mouseDragged(dx, dy);
				}
			}

			@Override
			public void mouseClicked() {
				if (!isVisible()) {
					return;
				}

				if (isFocusable()) {
					Vector2f pos = getAbsolutePosition();

					float mx = ((float) Mouse.getX() / (float) Display.getWidth()) * 2f - 1f;
					float my = ((float) Mouse.getY() / (float) Display.getHeight()) * 2f - 1f;

					boolean h = !(mx < pos.x || my < pos.y || mx > pos.x + width || my > pos.y + height);

					if (h) {
						requestFocus();
					}
				}

				for (KEventListener l : evListeners) {
					l.mouseClicked();
				}
			}

			@Override
			public void keyTyped(int key) {
				for (KEventListener l : evListeners) {
					l.keyTyped(key);
				}
			}

			@Override
			public void keyReleased(int key) {
				for (KEventListener l : evListeners) {
					l.keyReleased(key);
				}
			}

			@Override
			public void keyPressed(int key) {
				for (KEventListener l : evListeners) {
					l.keyPressed(key);
				}
			}

			@Override
			public void mouseWheelMoved(int d) {
				for (KEventListener l : evListeners) {
					l.mouseWheelMoved(d);
				}
			}
		};
		// the whole screen.
		clip = new Rectangle(-1f, -1f, 2f, 2f);

		DisplayManager.addFrameListener(new FrameListener() {

			@Override
			public void frame(float delta) {
				if (smooth) {
					final float a = 5.0f * delta;
					if (isVisible()) {
						if (alpha + a < 1f) {
							alpha += a;
						}
					} else {
						if (alpha - a > 0) {
							alpha -= a;
						}
					}
				} else {
					alpha = 1f;
				}
			}
		});

		FocusController.addKFocusListener(new KFocusListener() {

			@Override
			public void focusLost(Gui src) {
				removeFocus();
			}

			@Override
			public void focusGained(Gui src) {
				requestFocus();
			}

			@Override
			public void focusChanged(Gui src) {
			}
		});

		setName(null);
		setTypeName(null);
	}

	/**
	 * Sets the position and the dimensions of the Gui.
	 * 
	 * @param x      the x position.
	 * @param y      the y position.
	 * @param width  the width.
	 * @param height the height.
	 */
	public void setBounds(float x, float y, float width, float height) {
		setPosition(x, y);
		setSize(width, height);
	}

	/**
	 * Sets the size and location to a given rectangle.
	 * 
	 * @param r The rectangle.
	 */
	public void setBounds(Rectangle r) {
		setBounds(r.x, r.y, r.width, r.height);
	}

	/**
	 * @return a rectangle that represents the global bounds of the gui.
	 */
	public Rectangle getBounds() {
		Vector2f pos = getPosition();
		return new Rectangle(pos.x, pos.y, width, height);
	}

	public Rectangle getAbsoluteBounds() {
		Vector2f pos = getAbsolutePosition();
		return new Rectangle(pos.x, pos.y, width, height);
	}

	public Rectangle getBounds(float padding) {
		Vector2f pos = getPosition();
		return new Rectangle(pos.x + padding, pos.y + padding, width - padding * 2f, height - padding * 2f);
	}

	/**
	 * Sets the size of the Gui.
	 * 
	 * @param size the size stored in a Vector2f. The x component is the width and
	 *             the y component is the height.
	 */
	public void setSize(Vector2f size) {
		setSize(size.x, size.y);
	}

	/**
	 * @return The size of the Gui stored in a Vector2f.
	 */
	public Vector2f getSize() {
		return new Vector2f(width, height);
	}

	/**
	 * Sets the size of the Gui.
	 * 
	 * @param width  the width
	 * @param height the height
	 */
	public void setSize(float width, float height) {
		setWidth(width);
		setHeight(height);
	}

	/**
	 * Sets the position of the Gui.
	 * 
	 * @param position the position stored in a Vector2f.
	 */
	public void setPosition(Vector2f position) {
		setPosition(position.x, position.y);
	}

	/**
	 * @return the absolute position of the Gui stored in a Vector2f.
	 */
	public Vector2f getAbsolutePosition() {
		if (parent != null)
			return new Vector2f(x + parent.getAbsolutePosition().x, y + parent.getAbsolutePosition().y);
		return new Vector2f(x, y);
	}

	/**
	 * @return the position of the Gui stored in a Vector2f.
	 */
	public Vector2f getPosition() {
		return new Vector2f(x, y);
	}

	/**
	 * Sets the position of the Gui.
	 * 
	 * @param x the x position
	 * @param y the y position
	 */
	public void setPosition(float x, float y) {
		setX(x);
		setY(y);
	}

	public float getAbsoluteX() {
		if (parent == null) {
			return getX();
		}
		return parent.getAbsoluteX() + getX();
	}

	public float getAbsoluteY() {
		if (parent == null) {
			return getY();
		}
		return parent.getAbsoluteY() + getY();
	}

	/**
	 * @return The x position.
	 */
	public float getX() {
		return x;
	}

	public float rightEdge() {
		return x + width;
	}

	public float rightAbsoluteEdge() {
		return getAbsolutePosition().x + width;
	}

	public float upperEdge() {
		return y + height;
	}

	public float upperAbsoluteEdge() {
		return getAbsolutePosition().y + height;
	}

	/**
	 * @param x The x position.
	 */
	public void setX(float x) {
		switch (GuiManager.getSizeMode()) {
		case GL_COORDS_DEFAULT:
			break;
		case PIXEL:
			x = DisplayManager.toGLCoords((int) x, 0).x;
			break;
		case GL_COORDS_WITH_ASPECT_CORRECTION:
			x /= DisplayManager.getAspect();
			break;
		}
		this.x = x;
		dispatchMoveEvent();
	}

	private void dispatchMoveEvent() {
		for (MovementListner l : movementListners) {
			l.move(x, y);
		}
	}

	/**
	 * @return The y position.
	 */
	public float getY() {
		return y;
	}

	/**
	 * @param y The y position.
	 */
	public void setY(float y) {
		switch (GuiManager.getSizeMode()) {
		case GL_COORDS_DEFAULT:
			break;
		case PIXEL:
			y = DisplayManager.toGLCoords(0, (int) y).y;
			break;
		default:
			break;
		}
		this.y = y;
		dispatchMoveEvent();
	}

	/**
	 * @return the width of the Gui.
	 */
	public float getWidth() {
		return width;
	}

	/**
	 * @param width the width of the Gui;
	 */
	public void setWidth(float width) {
		if (!isResizable()) {
			return;
		}
		switch (GuiManager.getSizeMode()) {
		case GL_COORDS_DEFAULT:
			break;
		case PIXEL:
			width = DisplayManager.toGLCoords((int) width, 0).x;
			break;
		case GL_COORDS_WITH_ASPECT_CORRECTION:
			width /= DisplayManager.getAspect();
			break;
		}
		this.width = width;
		dispatchResizeEvent();
	}

	/**
	 * @return the height of the Gui.
	 */
	public float getHeight() {
		return height;
	}

	/**
	 * @param height the height of the Gui;
	 */
	public void setHeight(float height) {
		if (!isResizable()) {
			return;
		}
		switch (GuiManager.getSizeMode()) {
		case GL_COORDS_DEFAULT:
			break;
		case PIXEL:
			height = DisplayManager.toGLCoords(0, (int) height).y;
			break;
		default:
			break;
		}
		this.height = height;
		dispatchResizeEvent();
	}

	/**
	 * @return the visibility.
	 */
	public boolean isVisible() {
		if (parent == null)
			return visible;
		else
			return visible && parent.isVisible();
	}

	/**
	 * @param visible the visibility.
	 */
	public void setVisible(boolean visible) {
		if (this.visible != visible) {
			this.visible = visible;
			for (KVisibilityChangeListener l : visibilityChangeListeners) {
				l.visibilityChanged(this);
			}
		}
	}

	/**
	 * Sets the textures of the Gui.
	 * 
	 * @param foreground the foreground-texture.
	 * @param background the background-texture.
	 */
	public void setColors(int foreground, int background) {
		setForeground(foreground);
		setBackground(background);
	}

	/**
	 * @return the foreground-texture.
	 */
	public int getForeground() {
		return foreground;
	}

	/**
	 * @param foreground the foreground-texture.
	 */
	public void setForeground(int foreground) {
		this.foreground = foreground;
	}

	public void setForeground(KColor foreground) {
		setForeground(foreground.getId());
	}

	/**
	 * @return the background-texture.
	 */
	public int getBackground() {
		return background;
	}

	/**
	 * @param background the background-texture.
	 */
	public void setBackground(int background) {
		this.background = background;
	}

	public void setBackground(KColor background) {
		setBackground(background.getId());
	}

	/**
	 * @return the parent Gui of the Gui.
	 */
	public Gui getParent() {
		return parent;
	}

	/**
	 * @param parent the parent Gui of the Gui.
	 */
	public void setParent(Gui parent) {
		this.parent = parent;
	}

	/**
	 * @return The EventListener of the Gui.
	 */
	public KEventListener getListener() {
		return listener;
	}

	/**
	 * @return this.
	 */
	public Gui get() {
		return this;
	}

	/**
	 * @return The current mouseOver-effect of the gui;
	 */
	public Gui getMouseOver() {
		return mouseOver;
	}

	/**
	 * @return the clip
	 */
	public Rectangle getClip() {
		return clip;
	}

	/**
	 * @return the alpha
	 */
	public float getAlpha() {
		return alpha;
	}

	/**
	 * @param alpha the alpha to set
	 */
	public void setAlpha(float alpha) {
		if (alpha < 0 || alpha > 1f)
			throw new IllegalArgumentException();
		this.alpha = alpha;
	}

	/**
	 * @param clip the clip to set
	 */
	public void setClip(Rectangle clip) {
		if (clip == null)
			throw new NullPointerException();
		this.clip = clip;
	}

	private void dispatchResizeEvent() {
		for (ResizeListener l : resizeListeners) {
			l.resize(width, height);
		}
	}

	/**
	 * Adds a ResizeListener to the Gui.
	 * 
	 * @param l
	 */
	public void addResizeListener(ResizeListener l) {
		resizeListeners.add(l);
	}

	/**
	 * Removes a ResizeListener to the Gui.
	 * 
	 * @param l
	 */
	public void removeResizeListener(ResizeListener l) {
		resizeListeners.remove(l);
	}

	/**
	 * @param mouseOver The new mouseOver-effect for the gui.
	 */
	public void setMouseOver(Gui mouseOver) {
		if (mouseOver == null)
			throw new NullPointerException();
		this.mouseOver = mouseOver;
	}

	/**
	 * @return the smooth
	 */
	public boolean isSmooth() {
		return smooth;
	}

	/**
	 * @param smooth the smooth to set
	 */
	public void setSmooth(boolean smooth) {
		this.smooth = smooth;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		if (name == null) {
			name = "none";
		}
		this.name = name;
	}

	/**
	 * @return the typeName
	 */
	public String getTypeName() {
		return typeName;
	}

	/**
	 * @param typeName the typeName to set
	 */
	public void setTypeName(String typeName) {
		if (typeName == null) {
			typeName = "none";
		}
		this.typeName = typeName;
	}

	public void createGraphics(GuiRenderer renderer) {
		g = new PGraphicsGLImpl(renderer);
	}

	public void addKVisibilityChangeListener(KVisibilityChangeListener l) {
		visibilityChangeListeners.add(l);
	}

	public void removeKVisibilityChangeListener(KVisibilityChangeListener l) {
		visibilityChangeListeners.remove(l);
	}

	public void addAnimation(Animation e) {
		animations.add(e);
	}

	public void removeAnimation(Animation e) {
		animations.remove(e);
	}

	public void animate() {
		for (Animation a : animations) {
			a.run();
		}
	}

	public boolean isResizable() {
		return resizable;
	}

	public void setResizable(boolean resizable) {
		this.resizable = resizable;
	}

	public void addEVListener(KEventListener l) {
		evListeners.add(l);
	}

	public void removeEVListener(KEventListener l) {
		evListeners.remove(l);
	}

	public void addMovementListener(MovementListner l) {
		movementListners.add(l);
	}

	public void removeMovementListener(MovementListner l) {
		movementListners.remove(l);
	}

	public void addChangeListener(ChangeListener l) {
		addResizeListener(l);
		addMovementListener(l);
	}

	public void removeChangeListener(ChangeListener l) {
		removeResizeListener(l);
		removeMovementListener(l);
	}

	public boolean isFocused() {
		return focused;
	}

	public void requestFocus() {
		FocusController.resetFocus();
		focused = true;
		FocusController.setFocusedGui(this);
		for (KFocusListener l : focusListeners) {
			l.focusGained(this);
		}
	}

	public void removeFocus() {
		focused = false;
		for (KFocusListener l : focusListeners) {
			l.focusLost(this);
		}
	}

	public void addKFocusListener(KFocusListener l) {
		focusListeners.add(l);
	}

	public void removeKFocusListener(KFocusListener l) {
		focusListeners.remove(l);
	}

	public void addHoverListener(HoverListener l) {
		hoverListeners.add(l);
	}

	public void removeHoverListener(HoverListener l) {
		hoverListeners.remove(l);
	}

	public boolean isFocusable() {
		return focusable;
	}

	public void setFocusable(boolean focusable) {
		this.focusable = focusable;
	}

	@Override
	public String toString() {
		return "Gui [x=" + x + ", y=" + y + ", width=" + width + ", height=" + height + ", visible=" + visible
				+ ", foreground=" + foreground + ", background=" + background + ", parent=" + parent + ", listener="
				+ listener + ", evListeners=" + evListeners + ", mouseOver=" + mouseOver + ", clip=" + clip
				+ ", resizeListeners=" + resizeListeners + ", movementListners=" + movementListners + ", alpha=" + alpha
				+ ", smooth=" + smooth + ", name=" + name + ", typeName=" + typeName + ", g=" + g
				+ ", visibilityChangeListeners=" + visibilityChangeListeners + ", animations=" + animations
				+ ", resizable=" + resizable + ", focused=" + focused + ", focusable=" + focusable + ", hoverListeners="
				+ hoverListeners + ", focusListeners=" + focusListeners + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Float.floatToIntBits(height);
		result = prime * result + (visible ? 1231 : 1237);
		result = prime * result + Float.floatToIntBits(width);
		result = prime * result + Float.floatToIntBits(x);
		result = prime * result + Float.floatToIntBits(y);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Gui other = (Gui) obj;
		if (Float.floatToIntBits(height) != Float.floatToIntBits(other.height))
			return false;
		if (visible != other.visible)
			return false;
		if (Float.floatToIntBits(width) != Float.floatToIntBits(other.width))
			return false;
		if (Float.floatToIntBits(x) != Float.floatToIntBits(other.x))
			return false;
		if (Float.floatToIntBits(y) != Float.floatToIntBits(other.y))
			return false;
		return true;
	}

	@Override
	protected Object clone() {
		try {
			return super.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * Renders the Gui.
	 * 
	 * @param renderer the GuiRenderer that is needed for this operation.
	 */
	public abstract void render(GuiRenderer renderer);

	public void apply(CSSFile style) {
		List<CSSAttribute> attribs = style.getAttributes();
		for (CSSAttribute e : attribs) {
			if (typeName.equals(e.getName())) {
				try {
					setForeground(Loader.loadColorToTexture(e.getInt("-foreground-color")));
				} catch (AttribException e1) {
				}
				try {
					setBackground(Loader.loadColorToTexture(e.getInt("-background-color")));
				} catch (AttribException e1) {
				}
				try {
					setForeground(Loader.loadTexturei(e.getString("-foreground-texture")));
				} catch (AttribException e1) {
				}
				try {
					setBackground(Loader.loadTexturei(e.getString("-background-texture")));
				} catch (AttribException e1) {
				}
			}
		}
	}

	@Override
	public List<Gui> uis() {
		return Arrays.asList(this);
	}

	public List<Integer> getCode() {
		return code;
	}
}
