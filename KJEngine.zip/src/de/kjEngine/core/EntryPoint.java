package de.kjEngine.core;

import java.io.IOException;
import java.io.InputStreamReader;

import de.kjEngine.core.io.PropertiesFile;
import de.kjEngine.core.io.PropertiesReader;

public class EntryPoint {

	public static void launch(String buildFile, String[] args) {
		PropertiesFile build = load(buildFile);
		String main = build.getString("main");
		try {
			Class<?> mainClass = Class.forName(main);
			try {
				mainClass.getMethod("getComponent", String[].class).invoke(null, (Object) (args));
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	private static PropertiesFile load(String buildFile) {
		try (PropertiesReader r = new PropertiesReader(new InputStreamReader(EntryPoint.class.getResourceAsStream(buildFile)))) {
			return r.read();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
}
