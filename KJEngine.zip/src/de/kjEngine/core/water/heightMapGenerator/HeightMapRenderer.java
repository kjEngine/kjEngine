package de.kjEngine.core.water.heightMapGenerator;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;

import de.kjEngine.core.api.Cleanable;
import de.kjEngine.core.postProcessing.PostProcessing;
import de.kjEngine.core.util.OpenGlUtils;
import de.kjEngine.core.water.Water;
import de.kjEngine.core.water.heightMapGenerator.frequency.FrequencyRenderer;
import de.kjEngine.core.water.heightMapGenerator.indices.ButterflyRenderer;
import de.kjEngine.core.water.heightMapGenerator.indices.IndicesRenderer;

public class HeightMapRenderer implements Cleanable {
	
	private HeightMapShader shader;
	private FrequencyRenderer frequencyRenderer;
	private IndicesRenderer indicesRenderer;
	private ButterflyRenderer butterflyRenderer;

	public HeightMapRenderer() {
		shader = new HeightMapShader();
		frequencyRenderer = new FrequencyRenderer();
		indicesRenderer = new IndicesRenderer();
		butterflyRenderer = new ButterflyRenderer();
	}
	
	public void render(Water water) {
		butterflyRenderer.render(water);
		
		water.getHeightMap().bindFrameBuffer();
		shader.enable();
		
		shader.pingpong.loadInt(water.getButterflyData().pingpong);
		
		PostProcessing.start();
		GL11.glClear(GL11.GL_COLOR_BUFFER_BIT);
		
		OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE0, water.getButterflyData().pingpong0.getColourTexture());
		OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE1, water.getButterflyData().pingpong1.getColourTexture());
		
		GL11.glDrawArrays(GL11.GL_TRIANGLE_STRIP, 0, 4);
		
		PostProcessing.end();
		shader.disable();
		water.getHeightMap().unbindFrameBuffer();
	}

	@Override
	public void cleanUp() {
		shader.cleanUp();
		frequencyRenderer.cleanUp();
		indicesRenderer.cleanUp();
	}

	/**
	 * @return the frequencyRenderer
	 */
	public FrequencyRenderer getFrequencyRenderer() {
		return frequencyRenderer;
	}

	/**
	 * @return the indicesRenderer
	 */
	public IndicesRenderer getIndicesRenderer() {
		return indicesRenderer;
	}

	/**
	 * @return the butterflyRenderer
	 */
	public ButterflyRenderer getButterflyRenderer() {
		return butterflyRenderer;
	}
}
