package de.kjEngine.core.water.heightMapGenerator.indices;

import org.lwjgl.opengl.GL30;

import de.kjEngine.core.postProcessing.Fbo;

public class ButterflyData {

	public Fbo pingpong0, pingpong1;
	public int pingpong;

	public ButterflyData(int width, int height) {
		pingpong0 = new Fbo(width, height, Fbo.NONE, new int[] { GL30.GL_COLOR_ATTACHMENT0 });
		pingpong1 = new Fbo(width, height, Fbo.NONE, new int[] { GL30.GL_COLOR_ATTACHMENT0 });
	}
}
