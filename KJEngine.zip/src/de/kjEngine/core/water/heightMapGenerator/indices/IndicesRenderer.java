package de.kjEngine.core.water.heightMapGenerator.indices;

import org.lwjgl.opengl.GL11;

import de.kjEngine.core.api.Cleanable;
import de.kjEngine.core.postProcessing.PostProcessing;
import de.kjEngine.core.water.Water;

public class IndicesRenderer implements Cleanable {
	
	private IndicesShader shader;

	public IndicesRenderer() {
		shader = new IndicesShader();
	}
	
	public void render(Water water) {
		water.getIndices().bindFrameBuffer();
		shader.enable();
		shader.N.loadInt(16);
		PostProcessing.start();
		GL11.glClear(GL11.GL_COLOR_BUFFER_BIT);
		GL11.glDrawArrays(GL11.GL_TRIANGLE_STRIP, 0, 4);
		PostProcessing.end();
		shader.disable();
		water.getIndices().unbindFrameBuffer();
	}

	@Override
	public void cleanUp() {
		shader.cleanUp();
	}
}
