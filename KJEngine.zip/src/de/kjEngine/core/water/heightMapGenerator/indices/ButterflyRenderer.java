package de.kjEngine.core.water.heightMapGenerator.indices;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;

import de.kjEngine.core.api.Cleanable;
import de.kjEngine.core.math.KMath;
import de.kjEngine.core.postProcessing.PostProcessing;
import de.kjEngine.core.util.OpenGlUtils;
import de.kjEngine.core.water.Water;

public class ButterflyRenderer implements Cleanable {

	private ButterflyShader shader;

	public ButterflyRenderer() {
		shader = new ButterflyShader();
	}

	public void render(Water water) {
		shader.enable();

		ButterflyData data = water.getButterflyData();

		PostProcessing.start();
		for (int d = 0; d < 3; d++) {
			data.pingpong = 0;
			renderPass(water, 0, d);
			renderPass(water, 1, d);
		}

		PostProcessing.end();
		shader.disable();
	}

	private void renderPass(Water water, int dir, int dim) {
		int logN = KMath.log(2, water.getN());
		ButterflyData data = water.getButterflyData();
		shader.direction.loadInt(dir);
		for (int i = 0; i < logN; i++) {
			shader.pingpong.loadInt(data.pingpong);
			shader.stage.loadInt(i);

			if (data.pingpong == 0) {
				data.pingpong1.bindFrameBuffer();
				data.pingpong = 1;
			} else {
				data.pingpong0.bindFrameBuffer();
				data.pingpong = 0;
			}

			GL11.glClear(GL11.GL_COLOR_BUFFER_BIT);

			OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE0, water.getIndices().getColourTexture());
			if (i == 0) {
				switch (dim) {
				case 0:
					OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE1, water.getB0().getColourTexture());
					break;
				case 1:
					OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE1, water.getB1().getColourTexture());
					break;
				case 2:
					OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE1, water.getB2().getColourTexture());
					break;
				}
			} else {
				OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE1, data.pingpong0.getColourTexture());
			}
			OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE2, data.pingpong1.getColourTexture());

			GL11.glDrawArrays(GL11.GL_TRIANGLE_STRIP, 0, 4);

			if (data.pingpong == 1) {
				data.pingpong1.unbindFrameBuffer();
			} else {
				data.pingpong0.unbindFrameBuffer();
			}
		}
	}

	@Override
	public void cleanUp() {
		shader.cleanUp();
	}
}
