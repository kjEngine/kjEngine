package de.kjEngine.core.water.heightMapGenerator.indices;

import de.kjEngine.core.api.Shader;
import de.kjEngine.core.uniforms.UniformInt;

public class ButterflyShader extends Shader {
	
	public UniformInt stage, pingpong, direction;

	public ButterflyShader() {
		super("/de/kjEngine/core/postProcessing/simpleVertex.glsl",
				"/de/kjEngine/core/water/heightMapGenerator/indices/butterflyShader.glsl");
	}

	@Override
	protected void loadUniformLocations() {
		stage = new UniformInt(id, "stage");
		pingpong = new UniformInt(id, "pingpong");
		direction = new UniformInt(id, "direction");
	}
}
