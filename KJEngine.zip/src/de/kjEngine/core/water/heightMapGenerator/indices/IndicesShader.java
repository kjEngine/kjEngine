package de.kjEngine.core.water.heightMapGenerator.indices;

import de.kjEngine.core.api.Shader;
import de.kjEngine.core.uniforms.UniformInt;

public class IndicesShader extends Shader {
	
	public UniformInt N;

	public IndicesShader() {
		super("/de/kjEngine/core/postProcessing/simpleVertex.glsl",
				"/de/kjEngine/core/water/heightMapGenerator/indices/fragmentShader.glsl");
	}

	@Override
	protected void loadUniformLocations() {
		N = new UniformInt(id, "N");
	}
}