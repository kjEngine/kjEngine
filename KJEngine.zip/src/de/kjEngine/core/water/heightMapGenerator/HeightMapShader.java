package de.kjEngine.core.water.heightMapGenerator;

import de.kjEngine.core.api.Shader;
import de.kjEngine.core.uniforms.UniformInt;

public class HeightMapShader extends Shader {
	
	public UniformInt pingpong;

	public HeightMapShader() {
		super("/de/kjEngine/core/postProcessing/simpleVertex.glsl",
				"/de/kjEngine/core/water/heightMapGenerator/fragmentShader.glsl");
	}

	@Override
	protected void loadUniformLocations() {
		pingpong = new UniformInt(id, "pingpong");
	}
}
