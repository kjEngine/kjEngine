package de.kjEngine.core.water.heightMapGenerator.frequency;

import de.kjEngine.core.api.Shader;

public class FrequencyShader extends Shader {
	
	public FrequencyShader() {
		super("/de/kjEngine/core/postProcessing/simpleVertex.glsl",
				"/de/kjEngine/core/water/heightMapGenerator/frequency/fragmentShader.glsl");
	}

	@Override
	protected void loadUniformLocations() {
	}
}
