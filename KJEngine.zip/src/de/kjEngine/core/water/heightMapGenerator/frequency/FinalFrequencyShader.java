package de.kjEngine.core.water.heightMapGenerator.frequency;

import de.kjEngine.core.api.Shader;
import de.kjEngine.core.uniforms.UniformFloat;

public class FinalFrequencyShader extends Shader {

	public UniformFloat t;

	public FinalFrequencyShader() {
		super("/de/kjEngine/core/postProcessing/simpleVertex.glsl",
				"/de/kjEngine/core/water/heightMapGenerator/frequency/finalFragmentShader.glsl");
	}

	@Override
	protected void loadUniformLocations() {
		t = new UniformFloat(id, "t");
	}
}
