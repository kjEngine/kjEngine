package de.kjEngine.core.water.heightMapGenerator.frequency;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;

import de.kjEngine.core.api.Cleanable;
import de.kjEngine.core.postProcessing.PostProcessing;
import de.kjEngine.core.util.OpenGlUtils;
import de.kjEngine.core.water.Water;

public class FrequencyRenderer implements Cleanable {
	
	private FrequencyShader shader;
	private FinalFrequencyShader finalFrequencyShader;

	public FrequencyRenderer() {
		shader = new FrequencyShader();
		finalFrequencyShader = new FinalFrequencyShader();
	}
	
	public void render(Water water) {
		water.getFrequencyComps().bindFrameBuffer();
		shader.enable();
		PostProcessing.start();
		GL11.glClear(GL11.GL_COLOR_BUFFER_BIT);
		GL11.glDrawArrays(GL11.GL_TRIANGLE_STRIP, 0, 4);
		PostProcessing.end();
		shader.disable();
		water.getFrequencyComps().unbindFrameBuffer();
		
		calcFinalFrequency(water);
	}

	private void calcFinalFrequency(Water water) {
		water.resolveFrequencyComps();
		
		water.getFrequency().bindFrameBuffer();
		finalFrequencyShader.enable();
		finalFrequencyShader.t.loadFloat(water.getT());
		PostProcessing.start();
		
		OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE0, water.getB0().getColourTexture());
		OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE1, water.getB1().getColourTexture());
		
		GL11.glClear(GL11.GL_COLOR_BUFFER_BIT);
		GL11.glDrawArrays(GL11.GL_TRIANGLE_STRIP, 0, 4);
		
		PostProcessing.end();
		finalFrequencyShader.disable();
		water.getFrequency().unbindFrameBuffer();
		
		water.resolveFrequency();
	}

	@Override
	public void cleanUp() {
		shader.cleanUp();
		finalFrequencyShader.cleanUp();
	}
}
