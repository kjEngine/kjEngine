package de.kjEngine.core.water;

import static org.lwjgl.opengl.GL20.*;

import org.lwjgl.util.vector.*;

import de.kjEngine.core.*;
import de.kjEngine.core.api.Shader;
import de.kjEngine.core.light.*;
import de.kjEngine.core.uniforms.UniformFloat;

public class WaterShader extends Shader {
	
	private int pMatLoc, vMatLoc, mMatLoc;
	private int animLoc, scaleLoc, waveHeightLoc;
	private int sunAmbLoc, sunDiffLoc, sunSpecLoc, sunDirLoc;
	private int minFogLoc, maxFogLoc, fogColLoc;
	public UniformFloat width, height;

	public WaterShader() {
		super("/de/kjEngine/core/water/vertexShader.glsl", "/de/kjEngine/core/water/fragmentShader.glsl");
	}

	@Override
	public void cleanUp() {		
		glDeleteProgram(id);
	}

	@Override
	protected void loadUniformLocations() {		
		pMatLoc = glGetUniformLocation(id, "pMat");
		vMatLoc = glGetUniformLocation(id, "vMat");
		mMatLoc = glGetUniformLocation(id, "mMat");
		
		loadSunUniforms();
		loadWaterUniforms();
		loadFogUniforms();
		
		width = new UniformFloat(id, "width");
		height = new UniformFloat(id, "height");
	}
	
	private void loadFogUniforms() {
		minFogLoc = glGetUniformLocation(id, "minFog");
		maxFogLoc = glGetUniformLocation(id, "maxFog");
		fogColLoc = glGetUniformLocation(id, "fogCol");
	}

	private void loadWaterUniforms() {	
		animLoc = glGetUniformLocation(id, "anim");
		scaleLoc = glGetUniformLocation(id, "scale");
		waveHeightLoc = glGetUniformLocation(id, "waveHeight");
	}

	private void loadSunUniforms() {
		sunAmbLoc = glGetUniformLocation(id, "sun.amb");
		sunDiffLoc = glGetUniformLocation(id, "sun.diff");
		sunSpecLoc = glGetUniformLocation(id, "sun.spec");
		sunDirLoc = glGetUniformLocation(id, "sun.dir");
	}
	
	public void loadMatrices(Matrix4f pMat, Matrix4f vMat, Matrix4f mMat) {
		loadMatrix(pMatLoc, pMat);
		loadMatrix(vMatLoc, vMat);
		loadMatrix(mMatLoc, mMat);
	}
	
	public void loadAnim(float anim) {
		loadFloat(animLoc, anim);
	}
	
	public void loadScale(float scale) {
		loadFloat(scaleLoc, scale);
	}
	
	public void loadSun(DirectionalLight sun) {
		loadVector(sunAmbLoc, sun.getAmbient());
		loadVector(sunDiffLoc, sun.getDiffuse());
		loadVector(sunSpecLoc, sun.getSpecular());
		loadVector(sunDirLoc, sun.getDirection());
	}
	
	public void loadWaveHeight(float height) {
		loadFloat(waveHeightLoc, height);
	}
	
	public void loadFogData(float minFog, float maxFog, Vector4f fogColor) {
		loadFloat(minFogLoc, minFog);
		loadFloat(maxFogLoc, maxFog);
		loadVector(fogColLoc, fogColor);
	}
}
