package de.kjEngine.core.water;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL13.*;

import org.lwjgl.util.vector.*;

import de.kjEngine.core.*;
import de.kjEngine.core.api.Cleanable;
import de.kjEngine.core.api.FogData;
import de.kjEngine.core.light.*;
import de.kjEngine.core.water.heightMapGenerator.HeightMapRenderer;

public class WaterRenderer implements Cleanable {
	
	private WaterShader shader;
	private long time = System.currentTimeMillis();
	private HeightMapRenderer heightMapRenderer;

	public WaterRenderer() {
		shader = new WaterShader();
		heightMapRenderer = new HeightMapRenderer();
	}
	
	public void render(Water water, Matrix4f vMat, Matrix4f pMat, DirectionalLight sun, FogData fog) {
		shader.enable();
		
		Matrix4f mMat = Matrix4f.setIdentity(new Matrix4f());
		mMat.translate(water.getPos());
		
		shader.loadMatrices(pMat, vMat, mMat);
		shader.loadScale(water.getScale());
		shader.loadSun(sun);
		shader.loadAnim((System.currentTimeMillis() - time) * 0.001f);
		shader.loadWaveHeight(water.getWaveheight());
		shader.loadFogData(fog.getMinFog(), fog.getMaxFog(), fog.getFogColor());
		shader.width.loadFloat(water.getWidth());
		shader.width.loadFloat(water.getHeight());
		
		glEnable(GL_CULL_FACE);
		
		water.getModel().enable();
		
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, water.getReflection().getColourTexture());
		
		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D, water.getHeightMap().getColourTexture());
		
		glDrawElements(GL_TRIANGLES, water.getModel().getIndexCount(), GL_UNSIGNED_INT, 0);
		
		water.getModel().disable();
		
		shader.disable();
	}

	/**
	 * @return the heightMapRenderer
	 */
	public HeightMapRenderer getHeightMapRenderer() {
		return heightMapRenderer;
	}

	@Override
	public void cleanUp() {
		shader.cleanUp();
	}
}
