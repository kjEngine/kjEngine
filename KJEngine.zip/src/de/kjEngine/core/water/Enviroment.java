package de.kjEngine.core.water;

import org.lwjgl.util.vector.Vector2f;

public class Enviroment {
	
	public float time;
	public Vector2f wind = new Vector2f();

	public Enviroment() {
	}
}
