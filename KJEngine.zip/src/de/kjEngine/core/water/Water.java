package de.kjEngine.core.water;

import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL30;
import org.lwjgl.util.vector.Vector3f;

import de.kjEngine.core.api.AsEntity;
import de.kjEngine.core.api.Entity;
import de.kjEngine.core.awt.DisplayManager;
import de.kjEngine.core.model.Model;
import de.kjEngine.core.postProcessing.Fbo;
import de.kjEngine.core.util.Loader;
import de.kjEngine.core.water.heightMapGenerator.indices.ButterflyData;

public class Water implements AsEntity {

	private Model model;
	private float scale, waveheight;
	private Fbo reflection;
	private Vector3f pos;
	private int width, height;
	private Fbo heightMap, frequencyComps, frequency, b0, b1, b2, indices, dx, dy, dz;
	private ButterflyData butterflyData;
	private Enviroment enviroment;
	private float t;
	private int N;

	public Water(int width, int height, float scale, float waveheight) {
		model = Loader.genTerrain(width, height, scale, 0f, 1f, 0, 1f, "water");
		setScale(scale);
		setWaveheight(waveheight);
		reflection = new Fbo(Display.getWidth(), Display.getHeight(), Fbo.NONE,
				new int[] { GL30.GL_COLOR_ATTACHMENT0 });
		pos = new Vector3f();
		setWidth(width);
		setHeight(height);
		heightMap = new Fbo(width, height, Fbo.NONE, new int[] { GL30.GL_COLOR_ATTACHMENT0 });
		frequencyComps = new Fbo(width, height, Fbo.NONE,
				new int[] { GL30.GL_COLOR_ATTACHMENT0, GL30.GL_COLOR_ATTACHMENT1 });

		frequency = new Fbo(width, height, Fbo.NONE,
				new int[] { GL30.GL_COLOR_ATTACHMENT0, GL30.GL_COLOR_ATTACHMENT1, GL30.GL_COLOR_ATTACHMENT2 });
		b0 = new Fbo(width, height, Fbo.NONE, new int[] { GL30.GL_COLOR_ATTACHMENT0 });
		b1 = new Fbo(width, height, Fbo.NONE, new int[] { GL30.GL_COLOR_ATTACHMENT1 });
		b2 = new Fbo(width, height, Fbo.NONE, new int[] { GL30.GL_COLOR_ATTACHMENT2 });
		dx = new Fbo(width, height, Fbo.NONE, new int[] { GL30.GL_COLOR_ATTACHMENT0 });
		dy = new Fbo(width, height, Fbo.NONE, new int[] { GL30.GL_COLOR_ATTACHMENT1 });
		dz = new Fbo(width, height, Fbo.NONE, new int[] { GL30.GL_COLOR_ATTACHMENT2 });
		indices = new Fbo(4, height, Fbo.NONE, new int[] { GL30.GL_COLOR_ATTACHMENT0 });

		enviroment = new Enviroment();
		
		butterflyData = new ButterflyData(width, height);
		
		N = width;
	}

	public Vector3f getPos() {
		return pos;
	}

	public void setPos(Vector3f pos) {
		this.pos = pos;
	}

	public Model getModel() {
		return model;
	}

	public void setModel(Model model) {
		this.model = model;
	}

	public float getScale() {
		return scale;
	}

	public void setScale(float scale) {
		this.scale = scale;
	}

	public float getWaveheight() {
		return waveheight;
	}

	public void setWaveheight(float waveheight) {
		this.waveheight = waveheight;
	}

	public Fbo getReflection() {
		return reflection;
	}

	public void setReflection(Fbo reflection) {
		this.reflection = reflection;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	@Override
	public Entity getEntity() {
		return new Entity(pos, 0f, 0f, 0f, new Vector3f(1f, 1f, 1f), model);
	}

	@Override
	public String toString() {
		return "Water [scale=" + scale + ", waveheight=" + waveheight + ", pos=" + pos + ", width=" + width
				+ ", height=" + height + "]";
	}

	/**
	 * @return the heightMap
	 */
	public Fbo getHeightMap() {
		return heightMap;
	}

	public void updateSurface(WaterRenderer renderer) {
		renderer.getHeightMapRenderer().getFrequencyRenderer().render(this);
		renderer.getHeightMapRenderer().getIndicesRenderer().render(this);
		renderer.getHeightMapRenderer().render(this);
		t += DisplayManager.getDelta();
	}

	/**
	 * @return the enviroment
	 */
	public Enviroment getEnviroment() {
		return enviroment;
	}

	/**
	 * @return the frequency
	 */
	public Fbo getFrequencyComps() {
		return frequencyComps;
	}

	/**
	 * @return the frequency
	 */
	public Fbo getFrequency() {
		return frequency;
	}

	/**
	 * @return the b0
	 */
	public Fbo getB0() {
		return b0;
	}

	/**
	 * @return the b1
	 */
	public Fbo getB1() {
		return b1;
	}

	/**
	 * @return the b2
	 */
	public Fbo getB2() {
		return b2;
	}

	public void resolveFrequencyComps() {
		frequencyComps.resolveToFbo(GL30.GL_COLOR_ATTACHMENT0, b0);
		frequencyComps.resolveToFbo(GL30.GL_COLOR_ATTACHMENT1, b1);
	}

	public void resolveFrequency() {
		frequency.resolveToFbo(GL30.GL_COLOR_ATTACHMENT0, b0);
		frequency.resolveToFbo(GL30.GL_COLOR_ATTACHMENT1, b1);
		frequency.resolveToFbo(GL30.GL_COLOR_ATTACHMENT2, b2);
	}

	/**
	 * @return the t
	 */
	public float getT() {
		return t;
	}

	/**
	 * @return the indices
	 */
	public Fbo getIndices() {
		return indices;
	}

	/**
	 * @return the butterflyData
	 */
	public ButterflyData getButterflyData() {
		return butterflyData;
	}

	/**
	 * @return the n
	 */
	public int getN() {
		return N;
	}

	/**
	 * @return the dx
	 */
	public Fbo getDx() {
		return dx;
	}

	/**
	 * @return the dy
	 */
	public Fbo getDy() {
		return dy;
	}

	/**
	 * @return the dz
	 */
	public Fbo getDz() {
		return dz;
	}
}
