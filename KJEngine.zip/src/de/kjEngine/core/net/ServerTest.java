package de.kjEngine.core.net;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class ServerTest {

	public static void main(String[] args) {
		InetAddress address = null;
		try {
			address = InetAddress.getLocalHost();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		System.out.println(address.getHostName());
//		try {
//			Server client = new TCPServer(800);
//			client.setHandler(new PacketHandler() {
//				
//				@Override
//				public void process(DatagramPacket packet) {
//					try {
//						client.send(packet.getData(), InetAddress.getByName("localhost"), 801);
//					} catch (UnknownHostException e) {
//						e.printStackTrace();
//					}
//				}
//			});
//			client.start();
//			
//			Server server = new TCPServer(801);
//			server.setHandler(new PacketHandler() {
//				
//				@Override
//				public void process(DatagramPacket packet) {
//					try {
//						server.send(packet.getData(), InetAddress.getByName("localhost"), 800);
//					} catch (UnknownHostException e) {
//						e.printStackTrace();
//					}
//				}
//			});
//			server.start();
//			
//			client.send("Hello".getBytes(), InetAddress.getByName("localhost"), 801);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
	}
}
