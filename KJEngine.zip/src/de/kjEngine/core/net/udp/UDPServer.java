package de.kjEngine.core.net.udp;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

import de.kjEngine.core.net.Server;

public class UDPServer extends Server {

	private Thread transiver;
	private boolean transiving = false;
	private DatagramSocket socket;
	private InetAddress address;

	private static final int MAX_PACKET_SIZE = 508;
	private static final byte[] buffer = new byte[MAX_PACKET_SIZE];

	public UDPServer(int port, InetAddress address) {
		super(port);
		setAddress(address);
	}

	public boolean isTransiving() {
		return transiving;
	}

	public void start() {
		if (transiving)
			return;

		try {
			socket = new DatagramSocket(getPort());
		} catch (SocketException e) {
			e.printStackTrace();
			return;
		}

		transiving = true;
		transiver = new Thread(new Runnable() {

			@Override
			public void run() {
				listen();
			}
		}, "transiver");
		transiver.start();
	}

	private void listen() {
		while (transiving) {
			for (int i = 0; i < buffer.length; i++) {
				buffer[i] = 0;
			}
			DatagramPacket packet = new DatagramPacket(buffer, MAX_PACKET_SIZE);
			try {
				socket.receive(packet);
			} catch (IOException e) {
				e.printStackTrace();
			}
			if (handler != null)
				handler.process(packet);
		}
	}

	public static void dumpPacket(DatagramPacket packet) {
		// extract data
		byte[] data = packet.getData();
		int port = packet.getPort();
		InetAddress address = packet.getAddress();
		// dump
		System.out.println("************************************************");
		System.out.println("Packet recieved:");
		System.out.println("\tInformation:");
		System.out.println("\t\tport: " + port + " ,  address: " + address.getHostAddress());
		System.out.println("\tContent:");
		System.out.println(new String(data));
		System.out.println();
		System.out.println("************************************************");
	}

	public void send(byte[] data, InetAddress address, int port) {
		DatagramPacket packet = new DatagramPacket(data, Math.min(data.length, MAX_PACKET_SIZE), address, port);
		try {
			socket.send(packet);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void stop() {
		if (!transiving)
			return;
		transiving = false;
		socket.close();
	}

	public InetAddress getAddress() {
		return address;
	}

	public void setAddress(InetAddress address) {
		this.address = address;
	}

	public DatagramSocket getSocket() {
		return socket;
	}
}
