package de.kjEngine.core.net.udp;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

public class Client {
	
	private String ipAddress;
	private int port;
	
	private InetAddress serverAddress;
	private DatagramSocket socket;
	
	private Error connectionStatus = Error.NONE;
	
	public enum Error {
		NONE, INVALID_HOST, NO_CONNECTION;
	}
	
	/**
	 * Format: ipAddress:serverPort
	 * @param address
	 */
	public Client(String address) {
		String[] parts = address.split(":");
		if(parts.length != 2) {
			connectionStatus = Error.INVALID_HOST;
			return;
		}
		ipAddress = parts[0];
		try {
			port = Integer.parseInt(parts[1]);
		} catch (NumberFormatException e) {
			e.printStackTrace();
			connectionStatus = Error.INVALID_HOST;
			return;
		}
	}
	
	public Client(String address, int port) {
		this.port = port;
		ipAddress = address;
	}
	
	public boolean connect() {
		try {
			serverAddress = InetAddress.getByName(ipAddress);
		} catch (UnknownHostException e) {
			e.printStackTrace();
			connectionStatus = Error.INVALID_HOST;
			return false;
		}
		
		try {
			socket = new DatagramSocket(0);
		} catch (SocketException e) {
			e.printStackTrace();
			connectionStatus = Error.NO_CONNECTION;
			return false;
		}
		
		return true;
	}
	
	public void send(byte[] data) {
		assert (socket.isConnected() && connectionStatus == Error.NONE);
		DatagramPacket packet = new DatagramPacket(data, data.length, serverAddress, port);
		try {
			socket.send(packet);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public int getPort() {
		return port;
	}

	public Error getConnectionStatus() {
		return connectionStatus;
	}
}
