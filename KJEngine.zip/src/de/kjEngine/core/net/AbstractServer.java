package de.kjEngine.core.net;

import java.net.InetAddress;

import de.kjEngine.core.api.Startable;
import de.kjEngine.core.api.Stoppable;

public interface AbstractServer extends Startable, Stoppable {
	
	void send(byte[] data, InetAddress address, int port);
}
