package de.kjEngine.core.net.tcp;

import java.net.Socket;

public class Message {
	
	private Socket socket;
	private String content;

	public Message(Socket socket, String content) {
		this.socket = socket;
		this.content = content;
	}

	public Socket getSocket() {
		return socket;
	}

	public String getContent() {
		return content;
	}
}
