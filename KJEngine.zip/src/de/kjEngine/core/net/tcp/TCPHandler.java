package de.kjEngine.core.net.tcp;

import java.util.LinkedList;
import java.util.Queue;

public abstract class TCPHandler extends Thread {

	protected Queue<Message> messages = new LinkedList<>();
	protected boolean running = false;

	public TCPHandler() {
	}

	@Override
	public synchronized void start() {
		if (!running) {
			running = true;
			super.start();
		}
	}

	public Queue<Message> getMessages() {
		return messages;
	}

	public boolean isRunning() {
		return running;
	}
}
