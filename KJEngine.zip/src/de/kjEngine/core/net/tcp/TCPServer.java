package de.kjEngine.core.net.tcp;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;

import de.kjEngine.core.net.Server;

public class TCPServer extends Server {

	private ServerSocket socket;
	private Thread listener;
	private boolean listening = false;
	private Map<String, Socket> sockets = new HashMap<>();
	private TCPHandler tcpHandler;

	public TCPServer(int port) {
		super(port);
		try {
			socket = new ServerSocket(port);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public boolean isListening() {
		return listening;
	}

	public void start() {
		if (listening)
			return;
		listening = true;
		listener = new Thread(new Runnable() {

			@Override
			public void run() {
				listen();
			}
		});
		listener.start();
	}

	private void listen() {
		while (listening) {
			try (Socket s = socket.accept()) {
				System.out.println("Connected to " + s.getRemoteSocketAddress());
				BufferedReader input = new BufferedReader(new InputStreamReader(s.getInputStream()));
				StringBuilder sb = new StringBuilder();
				String line = "";
				while ((line = input.readLine()) != null) {
					sb.append(line + "\n");
				}
				String content = sb.toString();
				System.out.println(content);
				if (handler != null) {
					handler.process(
							new DatagramPacket(content.getBytes(), content.length(), s.getInetAddress(), s.getPort()));
				}
				if (tcpHandler != null) {
					tcpHandler.messages.offer(new Message(s, content));
					tcpHandler.start();
				}
			} catch (IOException e) {
				if (!(e instanceof SocketException)) {
					e.printStackTrace();
				}
			}
		}
	}

	public void stop() {
		if (!listening)
			return;
		listening = false;
	}

	public void send(byte[] data, InetAddress address, int port) {
		Socket s = null;
		String key = address.getHostAddress() + ":" + port;
		if (!sockets.containsKey(key)) {
			try {
				s = new Socket(address.getHostName(), port);
			} catch (UnknownHostException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			sockets.put(key, s);
		} else {
			s = sockets.get(key);
		}
		try {
			BufferedWriter w = new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));
			w.write(new String(data));
			w.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public TCPHandler getTcpHandler() {
		return tcpHandler;
	}

	public void setTcpHandler(TCPHandler tcpHandler) {
		this.tcpHandler = tcpHandler;
	}
}
