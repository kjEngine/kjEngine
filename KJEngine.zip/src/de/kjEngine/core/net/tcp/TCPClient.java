package de.kjEngine.core.net.tcp;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.Socket;

public class TCPClient {

	private Socket socket;
	private Thread listener;
	private boolean listening = false;
	private BufferedReader input;
	private int port;

	public TCPClient(InetAddress address, int port, InetAddress localAddr, int localPort) {
		this.port = localPort;
		try {
			socket = new Socket(address, port, localAddr, localPort);
			input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void start() {
		if (listening)
			return;
		listening = true;
		listener = new Thread(new Runnable() {

			@Override
			public void run() {
				listen();
			}
		});
		listener.start();
	}

	private void listen() {
		while (listening) {
			try {
				System.out.println(input.readLine());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public void stop() {
		if (!listening)
			return;
		listening = false;
	}
	
	public void send(byte[] data) {
		try {
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
			out.write(new String(data));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public boolean isListening() {
		return listening;
	}

	public int getPort() {
		return port;
	}
}
