package de.kjEngine.core.net.http;

import java.io.File;

import de.kjEngine.core.net.tcp.Message;
import de.kjEngine.core.net.tcp.TCPHandler;
import de.kjEngine.core.net.tcp.TCPServer;

public class HTTPServer extends TCPServer {
	
	private File root;

	public HTTPServer(int port, File root) {
		super(port);
		setRoot(root);
		setTcpHandler(new TCPHandler() {

			@Override
			public void run() {
				Message current = null;
				while ((current = messages.poll()) != null) {
					HTTPHandler handler = new HTTPHandler(current, HTTPServer.this.root);
					handler.start();
				}
			}
		});
	}

	public File getRoot() {
		return root;
	}

	public void setRoot(File root) {
		this.root = root;
	}
}
