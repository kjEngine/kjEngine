package de.kjEngine.core.net.http;

import java.io.File;

public class ExampleServer {

	public static void main(String[] args) {
		HTTPServer server = new HTTPServer(34567, new File("web"));
		server.start();
	}
}
