package de.kjEngine.core.net.http;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;

import de.kjEngine.core.net.tcp.Message;

public class HTTPHandler extends Thread {

	protected File root;
	protected Message message;

	public HTTPHandler(Message message, File root) {
		this.message = message;
		this.root = root;
	}

	@Override
	public void run() {
		try (BufferedOutputStream out = new BufferedOutputStream(message.getSocket().getOutputStream())) {
			String data = message.getContent();
			String[] lines = data.split("\n");
			if (lines.length == 0) {
				return;
			}
			String[] line1 = lines[0].split(" ");
			String method = line1[0].trim();
			if ("GET".equals(method)) {
				String path = line1[1].trim();
				File file = new File(path);
				if (file.isDirectory()) {
					File index = new File(file, "index.html");
					if (index.exists() && !index.isDirectory()) {
						file = index;
					} else {
						sendError(out, Status.FORBIDDEN);
						return;
					}
					if (!file.exists()) {
						sendError(out, Status.NOT_FOUND);
						return;
					}
					BufferedInputStream in = new BufferedInputStream(new FileInputStream(file));
					String contentType = URLConnection.getFileNameMap().getContentTypeFor(file.getName());
					if (contentType == null) {
						contentType = "application/octet-stream";
					}
					sendHeader(out, Status.OK, contentType, file.length(), file.lastModified());
					byte[] buffer = new byte[1024];
					int bytesRead;
					while ((bytesRead = in.read(buffer)) != -1) {
						out.write(buffer, 0, bytesRead);
					}
					out.flush();
					in.close();
				}
			} else {
				sendError(out, Status.NOT_IMPLEMENTED);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private void sendError(BufferedOutputStream out, Status status) throws IOException {
		String msg = status.getMessage();
		sendHeader(out, status, "text/html", msg.length(), System.currentTimeMillis());
		out.write(msg.getBytes());
		out.flush();
	}

	private void sendHeader(BufferedOutputStream out, Status status, String contentType, long length, long time)
			throws IOException {
		String header = "HTTP/1.1 " + status.getCode() + " " + status.getMessage() + "\r\nDate: "
				+ getTime(System.currentTimeMillis()) + "\r\nServer: SimpleWebserver" + "\r\nContent-Type: "
				+ contentType + "\r\nContent-Length: " + length + "\r\nLast-Modified: " + getTime(time)
				+ "\r\nConnection: close" + "\r\n\r\n";
		out.write(header.getBytes());
	}

	private String getTime(long millis) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(millis);
		SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss 'GMT'", Locale.US);
		dateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
		return dateFormat.format(calendar.getTime());
	}

	public File getRoot() {
		return root;
	}

	public Message getMessage() {
		return message;
	}
}
