package de.kjEngine.core.net;

public abstract class Server implements AbstractServer {
	
	protected int port;
	protected PacketHandler handler;

	public Server(int port) {
		this.port = port;
	}

	/**
	 * @return the port
	 */
	public int getPort() {
		return port;
	}

	/**
	 * @return the handler
	 */
	public PacketHandler getHandler() {
		return handler;
	}

	/**
	 * @param handler the handler to set
	 */
	public void setHandler(PacketHandler handler) {
		this.handler = handler;
	}
}
