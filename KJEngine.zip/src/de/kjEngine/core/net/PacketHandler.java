package de.kjEngine.core.net;

import java.net.DatagramPacket;

public interface PacketHandler {
	
	void process(DatagramPacket packet);
}
