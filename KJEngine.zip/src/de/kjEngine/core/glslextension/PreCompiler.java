package de.kjEngine.core.glslextension;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

public class PreCompiler {

	private static Map<String, String> liberies = new HashMap<>();
	
	static {
		// install standart liberies
		addLibery("vertex.glsl", "/de/kjEngine/core/glslextension/vertex.glsl");
		addLibery("ads_lighting.glsl", "/de/kjEngine/core/glslextension/ads_lighting.glsl");
		addLibery("geometry_utils.glsl", "/de/kjEngine/core/glslextension/geometry_utils.glsl");
		addLibery("normal_map.glsl", "/de/kjEngine/core/glslextension/normal_map.glsl");
		addLibery("raytracing.glsl", "/de/kjEngine/core/raytracing/raytracing.glsl");
	}

	public static void addLibery(String name, String path) {
		// create read vars
		BufferedReader r = new BufferedReader(new InputStreamReader(PreCompiler.class.getResourceAsStream(path)));
		StringBuilder sb = new StringBuilder();
		String line;
		// read file
		try {
			while ((line = r.readLine()) != null) {
				sb.append(line + "\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		String src = compile(sb.toString());
		liberies.put(name, src);
	}

	public static String compile(String src) {
		String[] lines = src.split("\n");
		for (int j = 0; j < lines.length; j++) {
			String line = lines[j];
			String trimmedLine = line.trim();
			if (trimmedLine.startsWith("#include")) {
				StringBuilder libnameBuilder = new StringBuilder();
				boolean writable = false;
				for (int i = "#include".length(); i < trimmedLine.length(); i++) {
					char c = trimmedLine.charAt(i);
					if (c == '<') {
						writable = true;
					} else if (c == '>') {
						break;
					} else if (writable) {
						libnameBuilder.append(c);
					}
				}
				lines[j] = liberies.get(libnameBuilder.toString());
			}
		}
		return String.join("\n", lines);
	}
}
