package de.kjEngine.core.shadows;

import org.lwjgl.util.vector.*;

import static org.lwjgl.opengl.GL20.*;

import de.kjEngine.core.*;
import de.kjEngine.core.api.Shader;

public class ShadowShader extends Shader {
	
	private static final String VERTEX_FILE = "/de/kjEngine/core/shadows/shadowVertexShader.glsl";
	private static final String FRAGMENT_FILE = "/de/kjEngine/core/shadows/shadowFragmentShader.glsl";
	
	private int location_pvMatrix;

	protected ShadowShader() {
		super(VERTEX_FILE, FRAGMENT_FILE);
	}

	@Override
	protected void loadUniformLocations() {
		location_pvMatrix = glGetUniformLocation(id, "pvMat");
		
	}
	
	protected void loadPvMatrix(Matrix4f pvMatrix){
		loadMatrix(location_pvMatrix, pvMatrix);
	}
}
