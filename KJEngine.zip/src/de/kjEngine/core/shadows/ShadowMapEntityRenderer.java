package de.kjEngine.core.shadows;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL20.*;
import static org.lwjgl.opengl.GL31.*;

import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.lwjgl.BufferUtils;
import org.lwjgl.util.vector.Matrix4f;

import de.kjEngine.core.api.Cleanable;
import de.kjEngine.core.api.Entity;
import de.kjEngine.core.model.Model;
import de.kjEngine.core.util.Loader;

public class ShadowMapEntityRenderer implements Cleanable {

	private Matrix4f projectionViewMatrix;
	private ShadowShader shader;

	private int vbo;
	private int pointer = 0;

	private static final int MAX_INSTANCES = 10000;
	private static final int INSTANCE_DATA_LENGTH = 16;

	private static final FloatBuffer buffer = BufferUtils.createFloatBuffer(MAX_INSTANCES * INSTANCE_DATA_LENGTH);

	/**
	 * @param shader
	 *            - the simple shader program being used for the shadow render
	 *            pass.
	 * @param projectionViewMatrix
	 *            - the orthographic projection matrix multiplied by the light's
	 *            "view" matrix.
	 */
	protected ShadowMapEntityRenderer(ShadowShader shader, Matrix4f projectionViewMatrix) {
		this.shader = shader;
		this.projectionViewMatrix = projectionViewMatrix;
		vbo = Loader.createEmptyVbo(INSTANCE_DATA_LENGTH * MAX_INSTANCES);
	}

	/**
	 * Renders entieis to the shadow map. Each model is first bound and then all
	 * of the entities using that model are rendered to the shadow map.
	 * 
	 * @param entities
	 *            - the entities to be rendered to the shadow map.
	 */
	protected void render(Map<Model, List<Entity>> entities) {
		// for (Model model : entities.keySet()) {
		// model.enable();
		// for (Entity entity : entities.get(model)) {
		// prepareInstance(entity);
		// GL11.glDrawElements(GL11.GL_TRIANGLES, model.getIndexCount(),
		// GL11.GL_UNSIGNED_INT, 0);
		// }
		// model.disable();
		// }
		shader.loadPvMatrix(projectionViewMatrix);

		for (Model m : entities.keySet()) {
			Loader.addInstanceAttribute(m.getVao(), vbo, 3, 4, INSTANCE_DATA_LENGTH, 0);
			Loader.addInstanceAttribute(m.getVao(), vbo, 4, 4, INSTANCE_DATA_LENGTH, 4);
			Loader.addInstanceAttribute(m.getVao(), vbo, 5, 4, INSTANCE_DATA_LENGTH, 8);
			Loader.addInstanceAttribute(m.getVao(), vbo, 6, 4, INSTANCE_DATA_LENGTH, 12);

			m.enable();
			glEnableVertexAttribArray(3);
			glEnableVertexAttribArray(4);
			glEnableVertexAttribArray(5);
			glEnableVertexAttribArray(6);

			List<Entity> el = new ArrayList<>();
			el = entities.get(m);

			pointer = 0;
			float[] vboData = new float[el.size() * INSTANCE_DATA_LENGTH];

			for (Entity e : el) {
				storeMatrix(e.getLocation(), vboData);
			}

			Loader.updateVbo(vbo, vboData, buffer);

			glDrawElementsInstanced(GL_TRIANGLES, m.getIndexCount(), GL_UNSIGNED_INT, 0, el.size());

			glDisableVertexAttribArray(3);
			glDisableVertexAttribArray(4);
			glDisableVertexAttribArray(5);
			glDisableVertexAttribArray(6);
			m.disable();
		}
	}

	private void storeMatrix(Matrix4f m, float[] f) {
		f[pointer++] = m.m00;
		f[pointer++] = m.m01;
		f[pointer++] = m.m02;
		f[pointer++] = m.m03;

		f[pointer++] = m.m10;
		f[pointer++] = m.m11;
		f[pointer++] = m.m12;
		f[pointer++] = m.m13;

		f[pointer++] = m.m20;
		f[pointer++] = m.m21;
		f[pointer++] = m.m22;
		f[pointer++] = m.m23;

		f[pointer++] = m.m30;
		f[pointer++] = m.m31;
		f[pointer++] = m.m32;
		f[pointer++] = m.m33;
	}

	@Override
	public void cleanUp() {
		shader.cleanUp();
	}
}
