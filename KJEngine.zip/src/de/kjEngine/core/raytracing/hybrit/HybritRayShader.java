package de.kjEngine.core.raytracing.hybrit;

import de.kjEngine.core.api.Shader;
import de.kjEngine.core.uniforms.UniformMat4;

public class HybritRayShader extends Shader {
	
	public UniformMat4 mMat, vpMat;

	public HybritRayShader() {
		super("/de/kjEngine/core/raytracing/hybrit/vertexShader.glsl",
				"/de/kjEngine/core/raytracing/hybrit/fragmentShader.glsl");
	}

	@Override
	protected void loadUniformLocations() {
		mMat = new UniformMat4(id, "mMat");
		vpMat = new UniformMat4(id, "vpMat");
	}
}
