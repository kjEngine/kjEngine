package de.kjEngine.core.raytracing.hybrit;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL15.*;
import static org.lwjgl.opengl.GL30.*;
import static org.lwjgl.opengl.GL43.*;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GL42;
import org.lwjgl.opengl.GL43;
import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector4f;

import de.kjEngine.core.api.Cleanable;
import de.kjEngine.core.api.Entity;
import de.kjEngine.core.model.Mesh;
import de.kjEngine.core.model.Model;
import de.kjEngine.core.postProcessing.Fbo;
import de.kjEngine.core.postProcessing.NoFilter;
import de.kjEngine.core.postProcessing.PostProcessing;
import de.kjEngine.core.util.OpenGlUtils;

public class HybritRayTracer implements Cleanable {

	private HybritRayShader shader;
	private TraceShader tracer;
	private Fbo buffer, normal, diffuse, position;
	private NoFilter renderer;
	private int result;
	private int tri_buffer, i_buffer;

	public HybritRayTracer() {
		shader = new HybritRayShader();
		tracer = new TraceShader();
		buffer = new Fbo(Display.getWidth(), Display.getHeight(), Fbo.DEPTH_TEXTURE, GL30.GL_COLOR_ATTACHMENT0,
				GL30.GL_COLOR_ATTACHMENT1, GL30.GL_COLOR_ATTACHMENT2);
		normal = new Fbo(Display.getWidth(), Display.getHeight(), Fbo.NONE, GL30.GL_COLOR_ATTACHMENT0);
		position = new Fbo(Display.getWidth(), Display.getHeight(), Fbo.NONE, GL30.GL_COLOR_ATTACHMENT0);
		diffuse = new Fbo(Display.getWidth(), Display.getHeight(), Fbo.NONE, GL30.GL_COLOR_ATTACHMENT0);
		result = GL11.glGenTextures();
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, result);
		GL42.glTexStorage2D(GL11.GL_TEXTURE_2D, 1, GL_RGBA8, Display.getWidth(), Display.getHeight());
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, 0);
		renderer = new NoFilter();
	}

	private void fillBuffer(Map<Model, List<Entity>> entities) {
		int float_size = 0;
		int in_size = 0;
		Set<Model> keys = entities.keySet();
		/*
		 * Calculate the size of the buffers. Format: float: position 3 tc 2 normal 3
		 * int: index 1
		 */
		for (Model m : keys) {
			int count = entities.get(m).size();
			Mesh mesh = m.getMesh();
			float_size += mesh.getVertices().length * count;
			float_size += mesh.getTexCoords().length * count;
			float_size += mesh.getNormals().length * count;
			in_size += m.getIndexCount() * count;
		}
		FloatBuffer t_buffer = BufferUtils.createFloatBuffer(float_size);
		IntBuffer i_buffer = BufferUtils.createIntBuffer(in_size);
		int i_off = 0;
		for (Model m : keys) {
			Mesh mesh = m.getMesh();
			float[] pa = mesh.getVertices();
			float[] ta = mesh.getTexCoords();
			float[] na = mesh.getNormals();
			for (Entity e : entities.get(m)) {
				// indices
				for (int i : mesh.getIndices()) {
					i_buffer.put(i + i_off);
				}
				int v_length = mesh.getTexCoords().length >> 1;
				i_off += v_length;
				Matrix4f mMat = e.getLocation();
				Matrix4f nMat = new Matrix4f(mMat);
				nMat.m30 = 0f;
				nMat.m31 = 0f;
				nMat.m32 = 0f;
				nMat.m33 = 1f;
				nMat.m23 = 0f;
				nMat.m13 = 0f;
				nMat.m03 = 0f;
				
				// f data
				for (int i = 0; i < v_length; i++) {
					int i3 = i * 3;
					int i2 = i << 1;
					// position
					Vector4f pos = new Vector4f(pa[i3], pa[i3 + 1], pa[i3 + 2], 1f);
					Matrix4f.transform(mMat, pos, pos);
					t_buffer.put(pos.x);
					t_buffer.put(pos.y);
					t_buffer.put(pos.z);
					// tc
					t_buffer.put(ta[i2]);
					t_buffer.put(ta[i2 + 1]);
					// normals
					Vector4f normal = new Vector4f(na[i3], na[i3 + 1], na[i3 + 2], 1f);
					Matrix4f.transform(nMat, normal, normal);
					t_buffer.put(normal.x);
					t_buffer.put(normal.y);
					t_buffer.put(normal.z);
				}
			}
		}
		
		t_buffer.flip();
		i_buffer.flip();
		
		if (tri_buffer != 0) {
			glDeleteBuffers(tri_buffer);
		}
		if (this.i_buffer != 0) {
			glDeleteBuffers(this.i_buffer);
		}
		tri_buffer = glGenBuffers();
		this.i_buffer = glGenBuffers();
		glBindBuffer(GL_ARRAY_BUFFER, tri_buffer);
		glBufferData(GL_ARRAY_BUFFER, t_buffer, GL_STATIC_DRAW);
		glBindBuffer(GL_ARRAY_BUFFER, 0);
		glBindBuffer(GL_ARRAY_BUFFER, this.i_buffer);
		glBufferData(GL_ARRAY_BUFFER, i_buffer, GL_STATIC_DRAW);
		glBindBuffer(GL_ARRAY_BUFFER, 0);
	}

	public void render(Map<Model, List<Entity>> entities, Matrix4f vMat, Matrix4f pMat) {
		buffer.bindFrameBuffer();

		GL11.glClear(GL11.GL_COLOR_BUFFER_BIT);
		GL11.glClear(GL11.GL_DEPTH_BUFFER_BIT);

		shader.enable();
		OpenGlUtils.enableDepthTesting(true);
		OpenGlUtils.cullBackFaces(true);
		OpenGlUtils.disableBlending();
		shader.vpMat.loadMatrix(Matrix4f.mul(pMat, vMat, null));
		for (Model m : entities.keySet()) {
			m.enable();
			OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE0, m.getTexture().getID());
			for (Entity e : entities.get(m)) {
				shader.mMat.loadMatrix(e.getLocation());
				GL11.glDrawElements(GL11.GL_TRIANGLES, m.getIndexCount(), GL11.GL_UNSIGNED_INT, 0);
			}
			m.disable();
		}
		shader.disable();
		buffer.unbindFrameBuffer();

		buffer.resolveToFbo(GL30.GL_COLOR_ATTACHMENT0, diffuse);
		buffer.resolveToFbo(GL30.GL_COLOR_ATTACHMENT1, normal);
		buffer.resolveToFbo(GL30.GL_COLOR_ATTACHMENT2, position);
		
		fillBuffer(entities);

		tracer.enable();
		GL42.glBindImageTexture(0, result, 0, false, 0, GL15.GL_WRITE_ONLY, GL11.GL_RGBA8);
		OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE1, diffuse.getColourTexture());
		OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE2, normal.getColourTexture());
		OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE3, position.getColourTexture());
		OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE6, position.getDepthTexture());
		
		glBindBufferBase(GL_SHADER_STORAGE_BUFFER, tracer.triangles, tri_buffer);
		glBindBufferBase(GL_SHADER_STORAGE_BUFFER, tracer.indices, i_buffer);

		GL43.glDispatchCompute(Display.getWidth(), Display.getHeight(), 1);

		GL42.glMemoryBarrier(GL42.GL_SHADER_IMAGE_ACCESS_BARRIER_BIT);
		
		glBindBufferBase(GL_SHADER_STORAGE_BUFFER, tracer.triangles, 0);
		glBindBufferBase(GL_SHADER_STORAGE_BUFFER, tracer.indices, 0);

		GL42.glBindImageTexture(0, 0, 0, false, 0, GL15.GL_WRITE_ONLY, GL11.GL_RGBA8);
		tracer.disable();

		PostProcessing.start();
		renderer.render(result);
		PostProcessing.end();
	}

	@Override
	public void cleanUp() {
		shader.cleanUp();
		tracer.cleanUp();
	}
}
