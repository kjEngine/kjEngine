package de.kjEngine.core.raytracing.hybrit;

import org.lwjgl.opengl.Display;
import org.lwjgl.util.vector.Vector3f;

import de.kjEngine.core.api.Entity;
import de.kjEngine.core.api.FirstPersonCamera;
import de.kjEngine.core.api.ViewPortSetting;
import de.kjEngine.core.awt.DisplayManager;
import de.kjEngine.core.awt.KColor;
import de.kjEngine.core.mainrendering.Renderer;
import de.kjEngine.core.model.Model;
import de.kjEngine.core.util.KJEngineException;
import de.kjEngine.core.util.KTexture;
import de.kjEngine.core.util.Loader;

public class Example {

	public static void main(String[] args) {
		try {
			DisplayManager.create(720, 400, "ray test", false, false);
		} catch (KJEngineException e) {
			e.printStackTrace();
		}
		FirstPersonCamera cam = new FirstPersonCamera();
		cam.setPos(new Vector3f(-4.7836175f, -1.3139966f, -3.2785435f));
		cam.setRotY(-1.2919968f);
		cam.setRotX(0.16000006f);
		Renderer renderer = new Renderer(new ViewPortSetting(60f, DisplayManager.getAspect(), 0.1f, 100f), cam);
		renderer.setRemovingEntitysAfterRendering(false);

		Model model = Loader.loadRelativeObjModel("/de/kjEngine/res/models/bird.obj",
				new KTexture(KColor.WHITE.getId()), "bird", Example.class);
		Entity entity = new Entity(new Vector3f(), 0f, 0f, 0f, new Vector3f(1f, 1f, 1f), model);
		
		renderer.processEntity(entity);

		while (!Display.isCloseRequested()) {
			renderer.clear();

			cam.update();
			renderer.getHybritRayTracer().render(renderer.getEntitys(), cam.getLocation(), renderer.getpMat());

			try {
				DisplayManager.update();
			} catch (KJEngineException e) {
				e.printStackTrace();
			}
			Display.setTitle("ray test | " + DisplayManager.getFps() + " fps");
		}

		renderer.cleanUp();
		DisplayManager.destroy();

		System.exit(0);
	}
}
