package de.kjEngine.core.raytracing.hybrit;

import org.lwjgl.opengl.GL31;

import de.kjEngine.core.api.Shader;

public class TraceShader extends Shader {

	public int triangles, indices;

	public TraceShader() {
		super("/de/kjEngine/core/raytracing/hybrit/tracer.comp");
	}

	@Override
	protected void loadUniformLocations() {
		triangles = GL31.glGetUniformBlockIndex(id, "triangles");
		GL31.glUniformBlockBinding(id, triangles, 4);
		indices = GL31.glGetUniformBlockIndex(id, "indices");
		GL31.glUniformBlockBinding(id, indices, 5);
	}
}
