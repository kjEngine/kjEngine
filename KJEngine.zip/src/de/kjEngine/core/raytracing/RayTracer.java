package de.kjEngine.core.raytracing;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL31;

import de.kjEngine.core.api.Camera;
import de.kjEngine.core.api.Cleanable;
import de.kjEngine.core.api.InstancedVbo;
import de.kjEngine.core.awt.DisplayManager;
import de.kjEngine.core.model.Model;
import de.kjEngine.core.raytracing.geom.Plane;
import de.kjEngine.core.raytracing.geom.Sphere;
import de.kjEngine.core.util.KTexture;

public class RayTracer implements Cleanable {

	private static final float[] POSITIONS = { -1f, 1f, 0f, -1f, -1f, 0f, 1f, 1f, 0f, 1f, -1f, 0f };
	private static final Model quad = de.kjEngine.core.util.Loader.loadModel3D(POSITIONS, null, null, new int[] { 0, 1, 2 },
			new KTexture(0), "quad");

	private RayShader shader;
	private InstancedVbo spheres, planes;

	public RayTracer() {
		shader = new RayShader();
		spheres = new InstancedVbo(1024, 8);
		planes = new InstancedVbo(1024, 8);
	}

	public void render(Sphere[] spheres, Plane[] planes, Camera cam) {
		GL11.glDisable(GL11.GL_DEPTH_TEST);
		shader.enable();
//		loadInstanceData(spheres, planes);
		quad.enable();
//		this.spheres.enable();
//		this.planes.enable();
		shader.sphereArray.loadSphereArray(spheres);
		shader.planeArray.loadPlaneArray(planes);
		shader.camPos.loadVec3(cam.getPos());
		shader.camRot.loadMatrix(cam.getLocation());
		shader.aspect.loadFloat(DisplayManager.getAspect());
		GL31.glDrawArraysInstanced(GL11.GL_TRIANGLE_STRIP, 0, 4, 1);
		shader.disable();
		GL11.glEnable(GL11.GL_DEPTH_TEST);
//		this.spheres.disble();
//		this.planes.disble();
		quad.disable();
	}

	private void loadInstanceData(Sphere[] spheresp, Plane[] planesp) {
		int pointer = spheres.attachAttribs(quad.getVao(), 1);
		pointer = planes.attachAttribs(quad.getVao(), pointer);
		
		float[] sphere_data = new float[spheresp.length * 8];
		pointer = 0;
		for (Sphere s : spheresp) {
			sphere_data[pointer++] = s.pos.x;
			sphere_data[pointer++] = s.pos.y;
			sphere_data[pointer++] = s.pos.z;
			sphere_data[pointer++] = s.r;
			sphere_data[pointer++] = s.mat.color.x;
			sphere_data[pointer++] = s.mat.color.y;
			sphere_data[pointer++] = s.mat.color.z;
			sphere_data[pointer++] = s.mat.shy;
		}
		
		pointer = 0;
		float[] plane_data = new float[planesp.length * 8];
		for (Plane p : planesp) {
			plane_data[pointer++] = p.normal.x;
			plane_data[pointer++] = p.normal.y;
			plane_data[pointer++] = p.normal.z;
			plane_data[pointer++] = p.d;
			plane_data[pointer++] = p.mat.color.x;
			plane_data[pointer++] = p.mat.color.y;
			plane_data[pointer++] = p.mat.color.z;
			plane_data[pointer++] = p.mat.shy;
		}
		
		spheres.put(sphere_data);
		planes.put(plane_data);
	}

	@Override
	public void cleanUp() {
		shader.cleanUp();
	}
}
