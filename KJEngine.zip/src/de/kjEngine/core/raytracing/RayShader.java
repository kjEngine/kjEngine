package de.kjEngine.core.raytracing;

import de.kjEngine.core.api.Shader;
import de.kjEngine.core.raytracing.geom.UniformPlaneArray;
import de.kjEngine.core.raytracing.geom.UniformSphereArray;
import de.kjEngine.core.uniforms.UniformFloat;
import de.kjEngine.core.uniforms.UniformMat4;
import de.kjEngine.core.uniforms.UniformVec3;

public class RayShader extends Shader {
	
	public UniformSphereArray sphereArray;
	public UniformPlaneArray planeArray;
	public UniformVec3 camPos;
	public UniformMat4 camRot;
	public UniformFloat aspect;

	public RayShader() {
		super("/de/kjEngine/core/raytracing/vertexShader.glsl", "/de/kjEngine/core/raytracing/fragmentShader.glsl");
	}

	@Override
	protected void loadUniformLocations() {
		sphereArray = new UniformSphereArray(id, "spheres", 128);
		planeArray = new UniformPlaneArray(id, "planes", 100);
		camPos = new UniformVec3(id, "camPos");
		camRot = new UniformMat4(id, "camRot");
		aspect = new UniformFloat(id, "aspect");
	}
}
