package de.kjEngine.core.raytracing;

import org.lwjgl.opengl.Display;
import org.lwjgl.util.vector.Vector3f;

import de.kjEngine.core.api.FirstPersonCamera;
import de.kjEngine.core.api.ViewPortSetting;
import de.kjEngine.core.awt.DisplayManager;
import de.kjEngine.core.mainrendering.Renderer;
import de.kjEngine.core.postProcessing.PostProcessing;
import de.kjEngine.core.raytracing.geom.Material;
import de.kjEngine.core.raytracing.geom.Plane;
import de.kjEngine.core.raytracing.geom.Sphere;
import de.kjEngine.core.util.KJEngineException;

public class Example {

	public static void main(String[] args) {
		try {
			DisplayManager.create(720, 400, "ray test", false, false);
		} catch (KJEngineException e) {
			e.printStackTrace();
		}
		FirstPersonCamera cam = new FirstPersonCamera();
		cam.setPos(new Vector3f(0f, 1f, -3f));
		Renderer renderer = new Renderer(new ViewPortSetting(60f, DisplayManager.getAspect(), 0.1f, 100f), cam);
		PostProcessing.init();

		int a = 11;
		Sphere[] spheres = new Sphere[a * a];
		for (int y = 0; y < a; y++) {
			for (int x = 0; x < a; x++) {
				spheres[x + y * a] = new Sphere(new Vector3f(x, 0f, y), 0.2f, new Material(new Vector3f(0f, 1f, 0f), 1f));
			}
		}
		
		Plane[] planes = new Plane[1];
		planes[0] = new Plane(new Vector3f(0f, 1f, 0f), -1f, new Material(new Vector3f(0.1f, 0.7f, 0.1f), 0f));

		while (!Display.isCloseRequested()) {
			renderer.clear();

			cam.update();
			renderer.getRayTracer().render(spheres, planes, cam);

			try {
				DisplayManager.update();
			} catch (KJEngineException e) {
				e.printStackTrace();
			}
			Display.setTitle("ray test | " + DisplayManager.getFps() + " fps");
		}

		renderer.cleanUp();
		DisplayManager.destroy();

		System.exit(0);
	}
}
