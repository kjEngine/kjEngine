package de.kjEngine.core.raytracing.geom;

import de.kjEngine.core.uniforms.Uniform;
import de.kjEngine.core.uniforms.UniformFloat;
import de.kjEngine.core.uniforms.UniformVec3;

public class UniformSphere extends Uniform {
	
	private UniformVec3 pos;
	private UniformFloat r;
	private UniformMaterial mat;

	public UniformSphere(int program, String name) {
		super(program, name);
	}
	
	@Override
	protected void storeUniformLocation(int programID) {
		pos = new UniformVec3(programID, name + ".pos");
		r = new UniformFloat(programID, name + ".r");
		mat = new UniformMaterial(programID, name + ".mat");
	}

	public void loadSphere(Sphere s) {
		pos.loadVec3(s.pos);
		r.loadFloat(s.r);
		mat.loadMaterial(s.mat);
	}
}
