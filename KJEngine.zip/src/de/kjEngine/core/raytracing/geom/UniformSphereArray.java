package de.kjEngine.core.raytracing.geom;

import de.kjEngine.core.uniforms.Uniform;

public class UniformSphereArray extends Uniform {
	
	private UniformSphere[] spheres;

	public UniformSphereArray(int program, String name, int n) {
		super(program, name);
		spheres = new UniformSphere[n];
		for (int i = 0; i < n; i++) {
			spheres[i] = new UniformSphere(program, name + "[" + i + "]");
		}
	}

	@Override
	protected void storeUniformLocation(int programID) {
	}
	
	public void loadSphereArray(Sphere[] spheres) {
		for (int i = 0; i < spheres.length; i++) {
			this.spheres[i].loadSphere(spheres[i]);
		}
	}
}
