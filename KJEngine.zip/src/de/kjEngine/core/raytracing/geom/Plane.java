package de.kjEngine.core.raytracing.geom;

import org.lwjgl.util.vector.Vector3f;

public class Plane {
	
	public Vector3f normal;
	public float d;
	public Material mat;
	
	public Plane() {
		this(new Vector3f(0f, 1f, 0f), 0f, new Material());
	}

	public Plane(Vector3f normal, float d, Material mat) {
		this.normal = normal;
		this.d = d;
		this.mat = mat;
	}
}
