package de.kjEngine.core.raytracing.geom;

import org.lwjgl.util.vector.Vector3f;

public class Sphere {
	
	public Vector3f pos;
	public float r;
	public Material mat;
	
	public Sphere() {
		this(new Vector3f(), 1f, new Material());
	}

	public Sphere(Vector3f pos, float r, Material mat) {
		this.pos = pos;
		this.r = r;
		this.mat = mat;
	}
}
