package de.kjEngine.core.raytracing.geom;

import de.kjEngine.core.uniforms.Uniform;

public class UniformPlaneArray extends Uniform {
	
	private UniformPlane[] planes;

	public UniformPlaneArray(int program, String name, int n) {
		super(program, name);
		planes = new UniformPlane[n];
		for (int i = 0; i < n; i++) {
			planes[i] = new UniformPlane(program, name + "[" + i + "]");
		}
	}

	@Override
	protected void storeUniformLocation(int programID) {
	}
	
	public void loadPlaneArray(Plane[] planes) {
		for (int i = 0; i < planes.length; i++) {
			this.planes[i].loadPlane(planes[i]);
		}
	}
}
