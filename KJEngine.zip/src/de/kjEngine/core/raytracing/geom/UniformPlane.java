package de.kjEngine.core.raytracing.geom;

import de.kjEngine.core.uniforms.Uniform;
import de.kjEngine.core.uniforms.UniformFloat;
import de.kjEngine.core.uniforms.UniformVec3;

public class UniformPlane extends Uniform {

	private UniformVec3 normal;
	private UniformFloat d;
	private UniformMaterial mat;

	public UniformPlane(int program, String name) {
		super(program, name);
	}
	
	@Override
	protected void storeUniformLocation(int programID) {
		normal = new UniformVec3(programID, name + ".normal");
		d = new UniformFloat(programID, name + ".d");
		mat = new UniformMaterial(programID, name + ".mat");
	}

	public void loadPlane(Plane p) {
		normal.loadVec3(p.normal);
		d.loadFloat(p.d);
		mat.loadMaterial(p.mat);
	}
}
