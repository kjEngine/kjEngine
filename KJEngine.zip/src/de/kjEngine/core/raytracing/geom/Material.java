package de.kjEngine.core.raytracing.geom;

import org.lwjgl.util.vector.Vector3f;

public class Material {
	
	public Vector3f color;
	public float shy;
	
	public Material() {
		this(new Vector3f(), 1f);
	}
	
	public Material(Vector3f color, float shy) {
		this.color = color;
		this.shy = shy;
	}
}
