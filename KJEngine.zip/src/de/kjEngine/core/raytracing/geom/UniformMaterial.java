package de.kjEngine.core.raytracing.geom;

import de.kjEngine.core.uniforms.Uniform;
import de.kjEngine.core.uniforms.UniformFloat;
import de.kjEngine.core.uniforms.UniformVec3;

public class UniformMaterial extends Uniform {
	
	private UniformVec3 color;
	private UniformFloat shy;

	protected UniformMaterial(int program, String name) {
		super(program, name);
		color = new UniformVec3(program, name + ".color");
		shy = new UniformFloat(program, name + ".shy");
	}

	@Override
	protected void storeUniformLocation(int programID) {
	}
	
	public void loadMaterial(Material mat) {
		color.loadVec3(mat.color);
		shy.loadFloat(mat.shy);
	}
}
