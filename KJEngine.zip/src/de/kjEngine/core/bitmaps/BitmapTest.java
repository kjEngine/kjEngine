package de.kjEngine.core.bitmaps;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;

public class BitmapTest {

	public static void main(String[] args) {
		BufferedImage img = new BufferedImage(720, 400, BufferedImage.TYPE_INT_RGB);
		int[] pixels = ((DataBufferInt) img.getRaster().getDataBuffer()).getData();
		int w = img.getWidth();
		int h = img.getHeight();
		JFrame frame = new JFrame();
		Canvas c = new Canvas();
		Bitmap map = new Bitmap(w, h, pixels);
		Graphics g = map.getGraphics();

		c.setSize(w, h);
		frame.add(c);
		frame.pack();
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);

		new Thread(new Runnable() {

			@Override
			public void run() {
				float anim = 0;

				BufferedImage ti0 = null;

				try {
					ti0 = ImageIO.read(new File("res/images/warship.jpg"));
				} catch (IOException e) {
					e.printStackTrace();
				}

				while (true) {
					// testing
					g.setColor(Color.BLACK);
					g.fillRect(0, 0, w, h);
					g.setColor(Color.RED);
					g.fillRect(20, 20, 50, 50);
					g.drawLine(70, 70, 70 + (int) (Math.cos(anim) * 30f), 70 + (int) (Math.sin(anim) * 30f));
					g.fillOval(200, 200, (int) ((Math.cos(anim * 0.1f) + 1.2f) * 100), 100);
					g.drawOval(300, 20, (int) ((Math.cos(anim * 0.1f) + 1.2f) * 100), 100);
					g.drawImage(ti0, 70, 70, 120 + (int) (Math.cos(anim + 0.1f) * 30f), 120, null);
					// rendering bitmap
					BufferStrategy bs = c.getBufferStrategy();
					if (bs == null) {
						c.createBufferStrategy(3);
						continue;
					}
					Graphics g0 = bs.getDrawGraphics();
					g0.drawImage(img, 0, 0, c.getWidth(), c.getHeight(), null);
					g0.dispose();
					bs.show();

					anim += 0.05;
				}
			}
		}).start();
	}
}
