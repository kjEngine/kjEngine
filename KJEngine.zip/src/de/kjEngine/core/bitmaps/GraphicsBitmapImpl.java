package de.kjEngine.core.bitmaps;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.text.AttributedCharacterIterator;

import org.lwjgl.util.vector.Vector2f;

public class GraphicsBitmapImpl extends Graphics {

	private Bitmap parent;
	private int trans_x, trans_y;
	private Color color;

	public GraphicsBitmapImpl(Bitmap parent) {
		setParent(parent);
	}

	public Bitmap getParent() {
		return parent;
	}

	public void setParent(Bitmap parent) {
		this.parent = parent;
	}

	@Override
	public Graphics create() {
		return new GraphicsBitmapImpl(new Bitmap(parent.getWidth(), parent.getHeight(), parent.getPixels()));
	}

	@Override
	public void translate(int x, int y) {
		trans_x += x;
		trans_y += y;
	}

	@Override
	public Color getColor() {
		return color;
	}

	@Override
	public void setColor(Color c) {
		if (c == null)
			throw new NullPointerException();
		color = c;
	}

	@Override
	public void setPaintMode() {
	}

	@Override
	public void setXORMode(Color c1) {
	}

	@Override
	public Font getFont() {
		return null;
	}

	@Override
	public void setFont(Font font) {
	}

	@Override
	public FontMetrics getFontMetrics(Font f) {
		return null;
	}

	@Override
	public Rectangle getClipBounds() {
		return null;
	}

	@Override
	public void clipRect(int x, int y, int width, int height) {
	}

	@Override
	public void setClip(int x, int y, int width, int height) {
	}

	@Override
	public Shape getClip() {
		return null;
	}

	@Override
	public void setClip(Shape clip) {
	}

	@Override
	public void copyArea(int x, int y, int width, int height, int dx, int dy) {
	}

	@Override
	public void drawLine(int x1, int y1, int x2, int y2) {
		int ax1 = x1 + trans_x;
		int ay1 = y1 + trans_y;
		int ax2 = x2 + trans_x;
		int ay2 = y2 + trans_y;
		Vector2f dir = new Vector2f(ax2 - ax1, ay2 - ay1);
		Vector2f pos = new Vector2f(ax1, ay1);
		float length = dir.length();
		dir.scale(1f / length);
		int ilength = (int) length;
		int col = getColori();
		for (int i = 0; i < ilength; i++) {
			parent.pixels[(int) pos.x + (int) pos.y * parent.width] = col;
			Vector2f.add(pos, dir, pos);
		}
	}

	@Override
	public void fillRect(int x, int y, int width, int height) {
		int ax = x + trans_x;
		int ay = y + trans_y;
		int col = getColori();
		for (int yp = ay; yp < ay + height; yp++) {
			for (int xp = ax; xp < ax + width; xp++) {
				parent.pixels[xp + yp * parent.width] = col;
			}
		}
	}

	@Override
	public void clearRect(int x, int y, int width, int height) {
	}

	@Override
	public void drawRoundRect(int x, int y, int width, int height, int arcWidth, int arcHeight) {
	}

	@Override
	public void fillRoundRect(int x, int y, int width, int height, int arcWidth, int arcHeight) {
	}

	@Override
	public void drawOval(int x, int y, int width, int height) {
		int ax = x + trans_x;
		int ay = y + trans_y;
		int col = getColori();
		float aspect = (float) width / (float) height;
		float hw = width * 0.5f;
		float hh = height * 0.5f;
		float r = hw * hw;
		float r2 = (hw - 3) * (hw - 3);
		for (int yp = ay; yp < ay + height; yp++) {
			for (int xp = ax; xp < ax + width; xp++) {
				float tx = (float) (xp - ax - hw);
				float ty = (float) (yp - ay - hh) * aspect;
				float l2 = tx * tx + ty * ty;
				if (l2 <= r && l2 > r2)
					parent.pixels[xp + yp * parent.width] = col;
			}
		}
	}

	@Override
	public void fillOval(int x, int y, int width, int height) {
		int ax = x + trans_x;
		int ay = y + trans_y;
		int col = getColori();
		float aspect = (float) width / (float) height;
		float hw = width * 0.5f;
		float hh = height * 0.5f;
		float r = hw * hw;
		for (int yp = ay; yp < ay + height; yp++) {
			if (yp < 0 || yp > parent.height - 1)
				continue;
			for (int xp = ax; xp < ax + width; xp++) {
				if (xp < 0 || yp > parent.width - 1)
					continue;
				float tx = (float) (xp - ax - hw);
				float ty = (float) (yp - ay - hh) * aspect;
				if (tx * tx + ty * ty <= r)
					parent.pixels[xp + yp * parent.width] = col;
			}
		}
	}

	@Override
	public void drawArc(int x, int y, int width, int height, int startAngle, int arcAngle) {
	}

	@Override
	public void fillArc(int x, int y, int width, int height, int startAngle, int arcAngle) {
	}

	@Override
	public void drawPolyline(int[] xPoints, int[] yPoints, int nPoints) {
	}

	@Override
	public void drawPolygon(int[] xPoints, int[] yPoints, int nPoints) {
	}

	@Override
	public void fillPolygon(int[] xPoints, int[] yPoints, int nPoints) {
	}

	@Override
	public void drawString(String str, int x, int y) {
	}

	@Override
	public void drawString(AttributedCharacterIterator iterator, int x, int y) {
	}

	@Override
	public boolean drawImage(Image img, int x, int y, ImageObserver observer) {
		if (img instanceof BufferedImage) {
			BufferedImage i = (BufferedImage) img;
			return drawImage(i, x, y, i.getWidth(), i.getHeight(), observer);
		}
		return false;
	}

	@Override
	public boolean drawImage(Image img, int x, int y, int width, int height, ImageObserver observer) {
		if (img instanceof BufferedImage) {
			BufferedImage i = (BufferedImage) img;
			int ax = x + trans_x;
			int ay = y + trans_y;
			int col = 0;
			float xs = (float) i.getWidth() / (float) width;
			float ys = (float) i.getHeight() / (float) height;
			for (int yp = ay; yp < ay + height; yp++) {
				if (yp < 0 || yp > parent.height - 1)
					continue;
				for (int xp = ax; xp < ax + width; xp++) {
					if (xp < 0 || yp > parent.width - 1)
						continue;
					col = i.getRGB((int) ((xp - ax) * xs), (int) ((yp - ay) * ys));
					parent.pixels[xp + yp * parent.width] = col;
				}
			}
		}
		return false;
	}

	@Override
	public boolean drawImage(Image img, int x, int y, Color bgcolor, ImageObserver observer) {
		return false;
	}

	@Override
	public boolean drawImage(Image img, int x, int y, int width, int height, Color bgcolor, ImageObserver observer) {
		return false;
	}

	@Override
	public boolean drawImage(Image img, int dx1, int dy1, int dx2, int dy2, int sx1, int sy1, int sx2, int sy2,
			ImageObserver observer) {
		return false;
	}

	@Override
	public boolean drawImage(Image img, int dx1, int dy1, int dx2, int dy2, int sx1, int sy1, int sx2, int sy2,
			Color bgcolor, ImageObserver observer) {
		return false;
	}

	@Override
	public void dispose() {
	}

	private int getColori() {
		return getColori(color);
	}

	private int getColori(Color c) {
		return (c.getAlpha() << 24) | (c.getRed() << 16) | (c.getGreen() << 8) | c.getBlue();
	}
}
