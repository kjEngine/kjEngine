package de.kjEngine.core.bitmaps;

import java.awt.Graphics;

public class Bitmap {
	
	int[] pixels;
	int width, height;

	public Bitmap(int width, int height, int[] pixels) {
		setWidth(width);
		setHeight(height);
		setPixels(pixels);
	}

	public int[] getPixels() {
		return pixels;
	}

	public void setPixels(int[] pixels) {
		this.pixels = pixels;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}
	
	public Graphics getGraphics() {
		return new GraphicsBitmapImpl(this);
	}
}
