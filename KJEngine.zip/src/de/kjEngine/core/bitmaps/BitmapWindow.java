package de.kjEngine.core.bitmaps;

import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;

import javax.swing.JFrame;

public class BitmapWindow extends JFrame {
	private static final long serialVersionUID = 1L;
	
	private Canvas canvas;
	private BufferedImage image;
	private int[] raster;
	private Bitmap bitmap;

	public BitmapWindow() {
		this("");
		canvas = new Canvas();
		add(canvas);
	}

	public BitmapWindow(String title) {
		super(title);
	}

	@Override
	public void setSize(Dimension d) {
		canvas.setSize(d);
		pack();
		updateImage();
	}

	@Override
	public void setSize(int width, int height) {
		canvas.setSize(width, height);
		pack();
		updateImage();
	}

	private void updateImage() {
		image = new BufferedImage(canvas.getWidth(), canvas.getHeight(), BufferedImage.TYPE_INT_RGB);
		raster = ((DataBufferInt) image.getRaster().getDataBuffer()).getData();
		bitmap = new Bitmap(image.getWidth(), image.getHeight(), getRaster());
	}

	public Canvas getCanvas() {
		return canvas;
	}

	public BufferedImage getImage() {
		return image;
	}

	public int[] getRaster() {
		return raster;
	}

	public Bitmap getBitmap() {
		return bitmap;
	}
}
