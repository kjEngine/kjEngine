package de.kjEngine.core.terrain.quadtree_oriented;

import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;

import de.kjEngine.core.GameEngine;
import de.kjEngine.core.model.Patch;
import de.kjEngine.core.terrain.quadtree_oriented.quadtree.Node;

public class TerrainNode extends Node {

	private boolean isLeaf;
	private QuadtreeTerrain terrain;
	private int lod;
	private Vector2f location;
	private Vector3f worldPos;
	private Vector2f index;
	private float gap;
	private Patch buffer;

	public TerrainNode(Patch patch, QuadtreeTerrain terrain, Vector2f location, int lod, Vector2f index) {
		buffer = patch;
		this.terrain = terrain;
		this.location = location;
		this.lod = lod;
		this.index = index;
		isLeaf = true;
		gap = 1f / (TerrainQuadtree.getRootNodes() * (float) (Math.pow(2f, lod)));

		Vector3f localScale = new Vector3f(gap, 0f, gap);
		Vector3f localTrans = new Vector3f(location.x, 0f, location.y);

		getLocalTransform().setScale(localScale);
		getLocalTransform().setTranslation(localTrans);

		getWorldTransform().translate(new Vector3f(-terrain.gethScale() * 0.5f, 0f, -terrain.gethScale() * 0.5f));
		getWorldTransform().scale(new Vector3f(terrain.gethScale(), terrain.getvScale(), terrain.gethScale()));
		
		computeWorldPos();
		updateQuadtree();
	}

	public void render() {
		if (isLeaf) {
			GameEngine.getRenderer().getQuadtreeTerrainRenderer().render(GameEngine.getVPMat(), this);
		}
		super.render();
	}
	
	public void update() {
		updateQuadtree();
		super.update();
	}

	public void updateQuadtree() {
		for (Node child : getChildren()) {
			((TerrainNode) child).updateQuadtree();
		}
		updateChildNodes();
	}

	public void updateChildNodes() {
		float dist = Vector3f.sub(GameEngine.getCam().getPos(), worldPos, null).length();

		if (dist < terrain.getLod_ranges()[lod]) {
			addChildNodes(lod + 1);
		} else if (dist >= terrain.getLod_ranges()[lod]) {
			removeChildNodes();
		}
	}

	private void addChildNodes(int lod) {
		if (isLeaf) {
			isLeaf = false;
		}
		if (getChildren().size() == 0) {
			for (int i = 0; i < 2; i++) {
				for (int j = 0; j < 2; j++) {
					addChild(new TerrainNode(buffer, terrain,
							Vector2f.add(location, new Vector2f(i * gap * 0.5f, j * gap * 0.5f), null), lod,
							new Vector2f(i, j)));
				}
			}
		}
	}
	
	private void removeChildNodes() {
		if (!isLeaf) {
			isLeaf = true;
		}
		if (getChildren().size() != 0) {
			getChildren().clear();
		}
	}
	
	public void computeWorldPos() {
		Vector2f loc = Vector2f.add(location, new Vector2f(gap * 0.5f, gap * 0.5f), null);
		loc.scale(terrain.gethScale());
		loc.x -= terrain.gethScale() * 0.5f;
		loc.y -= terrain.gethScale() * 0.5f;
		
		worldPos = new Vector3f(loc.x, 0f, loc.y);
	}

	/**
	 * @return the isLeaf
	 */
	public boolean isLeaf() {
		return isLeaf;
	}

	/**
	 * @param isLeaf
	 *            the isLeaf to set
	 */
	public void setLeaf(boolean isLeaf) {
		this.isLeaf = isLeaf;
	}

	/**
	 * @return the terrain
	 */
	public QuadtreeTerrain getTerrain() {
		return terrain;
	}

	/**
	 * @param terrain
	 *            the terrain to set
	 */
	public void setTerrain(QuadtreeTerrain terrain) {
		this.terrain = terrain;
	}

	/**
	 * @return the lod
	 */
	public int getLod() {
		return lod;
	}

	/**
	 * @param lod
	 *            the lod to set
	 */
	public void setLod(int lod) {
		this.lod = lod;
	}

	/**
	 * @return the location
	 */
	public Vector2f getLocation() {
		return location;
	}

	/**
	 * @param location
	 *            the location to set
	 */
	public void setLocation(Vector2f location) {
		this.location = location;
	}

	/**
	 * @return the worldPos
	 */
	public Vector3f getWorldPos() {
		return worldPos;
	}

	/**
	 * @param worldPos
	 *            the worldPos to set
	 */
	public void setWorldPos(Vector3f worldPos) {
		this.worldPos = worldPos;
	}

	/**
	 * @return the index
	 */
	public Vector2f getIndex() {
		return index;
	}

	/**
	 * @param index
	 *            the index to set
	 */
	public void setIndex(Vector2f index) {
		this.index = index;
	}

	/**
	 * @return the gap
	 */
	public float getGap() {
		return gap;
	}

	/**
	 * @param gap
	 *            the gap to set
	 */
	public void setGap(float gap) {
		this.gap = gap;
	}

	/**
	 * @return the buffer
	 */
	public Patch getBuffer() {
		return buffer;
	}

	/**
	 * @param buffer
	 *            the buffer to set
	 */
	public void setBuffer(Patch buffer) {
		this.buffer = buffer;
	}
}
