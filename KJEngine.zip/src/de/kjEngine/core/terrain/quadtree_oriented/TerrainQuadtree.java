package de.kjEngine.core.terrain.quadtree_oriented;

import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;

import de.kjEngine.core.model.Patch;
import de.kjEngine.core.terrain.quadtree_oriented.quadtree.Node;
import de.kjEngine.core.util.Loader;

public class TerrainQuadtree extends Node {

	private static int rootNodes = 8;

	public TerrainQuadtree(QuadtreeTerrain terrain) {
		Patch patch = new Patch(Loader.loadPatch2D(genVertexDataf()));
		for (int y = 0; y < rootNodes; y++) {
			for (int x = 0; x < rootNodes; x++) {
				addChild(new TerrainNode(patch, terrain, new Vector2f(x / (float) rootNodes, y / (float) rootNodes), 0,
						new Vector2f(x, y)));
			}
		}

		getWorldTransform().translate(new Vector3f(-terrain.gethScale() * 0.5f, 0f, -terrain.gethScale() * 0.5f));
		getWorldTransform().scale(new Vector3f(terrain.gethScale(), terrain.getvScale(), terrain.gethScale()));
	}
	
	public float[] genVertexDataf() {
		Vector2f[] src = genVertexData();
		float[] dest = new float[src.length * 2];
		for (int i = 0; i < src.length; i++) {
			dest[i * 2 + 0] = src[i].x;
			dest[i * 2 + 1] = src[i].y;
		}
		return dest;
	}

	public Vector2f[] genVertexData() {
		Vector2f[] vertices = new Vector2f[16];
		float scl = 0.3333333f;
		for (int y = 0; y < 4; y++) {
			for (int x = 0; x < 4; x++) {
				vertices[x + y * 4] = new Vector2f(x * scl, y * scl);
			}
		}
		return vertices;
	}

	/**
	 * @return the rootNodes
	 */
	public static int getRootNodes() {
		return rootNodes;
	}

	/**
	 * @param rootNodes
	 *            the rootNodes to set
	 */
	public static void setRootNodes(int rootNodes) {
		TerrainQuadtree.rootNodes = rootNodes;
	}
}
