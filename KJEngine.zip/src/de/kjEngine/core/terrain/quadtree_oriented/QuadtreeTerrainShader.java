package de.kjEngine.core.terrain.quadtree_oriented;

import de.kjEngine.core.api.Shader;
import de.kjEngine.core.uniforms.UniformFloat;
import de.kjEngine.core.uniforms.UniformInt;
import de.kjEngine.core.uniforms.UniformIntArray;
import de.kjEngine.core.uniforms.UniformMat4;
import de.kjEngine.core.uniforms.UniformVec2;
import de.kjEngine.core.uniforms.UniformVec3;

public class QuadtreeTerrainShader extends Shader {
	
	public UniformVec3 camPos;
	public UniformFloat scaleY;
	public UniformInt lod;
	public UniformVec2 index;
	public UniformMat4 localMat;
	public UniformMat4 worldMat;
	public UniformFloat gap;
	public UniformVec2 location;
	public UniformIntArray lod_morph_area;
	public UniformMat4 vpMat;

	public QuadtreeTerrainShader() {
		super("/de/kjEngine/core/terrain/quadtree_oriented/vertexShader.glsl",
				"/de/kjEngine/core/terrain/quadtree_oriented/fragmentShader.glsl",
				"/de/kjEngine/core/terrain/quadtree_oriented/tessCShader.glsl",
				"/de/kjEngine/core/terrain/quadtree_oriented/tessEShader.glsl",
				"/de/kjEngine/core/terrain/quadtree_oriented/geometryShader.glsl");
	}

	@Override
	protected void loadUniformLocations() {
		camPos = new UniformVec3(id, "camPos");
		scaleY = new UniformFloat(id, "scaleY");
		lod = new UniformInt(id, "lod");
		index = new UniformVec2(id, "index");
		localMat = new UniformMat4(id, "localMat");
		worldMat = new UniformMat4(id, "worldMat");
		gap = new UniformFloat(id, "gap");
		location = new UniformVec2(id, "location");
		lod_morph_area = new UniformIntArray(id, "lod_morph_area", 8);
		vpMat = new UniformMat4(id, "vpMat");
	}
}
