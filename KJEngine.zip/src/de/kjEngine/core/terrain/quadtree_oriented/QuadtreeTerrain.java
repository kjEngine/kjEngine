package de.kjEngine.core.terrain.quadtree_oriented;

import de.kjEngine.core.terrain.quadtree_oriented.quadtree.Node;

public class QuadtreeTerrain extends Node {
	
	private float hScale, vScale;
	
	private int[] lod_ranges = new int[8];
	private int[] lod_morphing_area = new int[8];

	public QuadtreeTerrain() {
	}

	/**
	 * @return the hScale
	 */
	public float gethScale() {
		return hScale;
	}

	/**
	 * @param hScale the hScale to set
	 */
	public void sethScale(float hScale) {
		this.hScale = hScale;
	}

	/**
	 * @return the vScale
	 */
	public float getvScale() {
		return vScale;
	}

	/**
	 * @param vScale the vScale to set
	 */
	public void setvScale(float vScale) {
		this.vScale = vScale;
	}

	/**
	 * @return the lod_ranges
	 */
	public int[] getLod_ranges() {
		return lod_ranges;
	}

	/**
	 * @param lod_ranges the lod_ranges to set
	 */
	public void setLod_ranges(int[] lod_ranges) {
		this.lod_ranges = lod_ranges;
	}

	/**
	 * @return the lod_morphing_area
	 */
	public int[] getLod_morphing_area() {
		return lod_morphing_area;
	}

	/**
	 * @param lod_morphing_area the lod_morphing_area to set
	 */
	public void setLod_morphing_area(int[] lod_morphing_area) {
		this.lod_morphing_area = lod_morphing_area;
	}
}
