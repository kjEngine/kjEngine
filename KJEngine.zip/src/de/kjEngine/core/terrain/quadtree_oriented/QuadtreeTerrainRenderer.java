package de.kjEngine.core.terrain.quadtree_oriented;

import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector3f;

import de.kjEngine.core.GameEngine;
import de.kjEngine.core.api.Cleanable;

public class QuadtreeTerrainRenderer implements Cleanable {
	
	private QuadtreeTerrainShader shader;

	public QuadtreeTerrainRenderer() {
		shader = new QuadtreeTerrainShader();
	}
	
	public void render(Matrix4f vpMat, TerrainNode node) {
		shader.enable();
		loadUniforms(vpMat, node);
		node.getBuffer().render();
		shader.disable();
	}

	private void loadUniforms(Matrix4f vpMat, TerrainNode node) {
		shader.camPos.loadVec3(Vector3f.sub(new Vector3f(), GameEngine.getCam().getPos(), null));
		shader.vpMat.loadMatrix(vpMat);
		QuadtreeTerrain terrain = node.getTerrain();
		shader.lod.loadInt(node.getLod());
		shader.index.loadVec2(node.getIndex());
		shader.gap.loadFloat(node.getGap());
		shader.location.loadVec2(node.getLocation());
		shader.localMat.loadMatrix(node.getLocalTransform().getMatrix());
		shader.worldMat.loadMatrix(node.getWorldTransform().getMatrix());
		shader.scaleY.loadFloat(terrain.getvScale());
		shader.lod_morph_area.loadIntArray(terrain.getLod_morphing_area());
	}

	@Override
	public void cleanUp() {
		shader.cleanUp();
	}
}
