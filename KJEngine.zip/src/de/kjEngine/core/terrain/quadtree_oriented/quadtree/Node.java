package de.kjEngine.core.terrain.quadtree_oriented.quadtree;

import java.util.ArrayList;
import java.util.List;

import de.kjEngine.core.api.Transform;

public class Node {
	
	private Node parent;
	private List<Node> children = new ArrayList<>();
	private Transform worldTransform, localTransform;

	public Node() {
		setWorldTransform(new Transform());
		setLocalTransform(new Transform());
	}
	
	public void addChild(Node e) {
		e.setParent(this);
		children.add(e);
	}
	
	public void update() {
		for (Node n : children) {
			n.update();
		}
	}
	
	public void input() {
		for (Node n : children) {
			n.input();
		}
	}
	
	public void render() {
		for (Node n : children) {
			n.render();
		}
	}
	
	public void shutdown() {
		for (Node n : children) {
			n.shutdown();
		}
	}

	/**
	 * @return the parent
	 */
	public Node getParent() {
		return parent;
	}

	/**
	 * @param parent the parent to set
	 */
	public void setParent(Node parent) {
		this.parent = parent;
	}

	/**
	 * @return the children
	 */
	public List<Node> getChildren() {
		return children;
	}

	/**
	 * @return the worldTransform
	 */
	public Transform getWorldTransform() {
		return worldTransform;
	}

	/**
	 * @param worldTransform the worldTransform to set
	 */
	public void setWorldTransform(Transform worldTransform) {
		this.worldTransform = worldTransform;
	}

	/**
	 * @return the localTransform
	 */
	public Transform getLocalTransform() {
		return localTransform;
	}

	/**
	 * @param localTransform the localTransform to set
	 */
	public void setLocalTransform(Transform localTransform) {
		this.localTransform = localTransform;
	}
}
