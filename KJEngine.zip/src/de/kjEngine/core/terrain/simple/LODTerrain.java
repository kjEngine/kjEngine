package de.kjEngine.core.terrain.simple;

import java.util.ArrayList;
import java.util.List;

import org.lwjgl.opengl.GL11;
import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector3f;

import de.kjEngine.core.GameEngine;
import de.kjEngine.core.light.advanced.Material;
import de.kjEngine.core.util.Loader;

public class LODTerrain {

	private int minRes, maxRes;
	private float width, length;
	private HeightMap heightMap;
	private int normalMap;
	private List<Material> materials = new ArrayList<>();

	public LODTerrain(int minRes, int maxRes, float width, float length) {
		setMinRes(minRes);
		setMaxRes(maxRes);
		setWidth(width);
		setLength(length);
	}

	/**
	 * @return the minRes
	 */
	public int getMinRes() {
		return minRes;
	}

	/**
	 * @param minRes
	 *            the minRes to set
	 */
	public void setMinRes(int minRes) {
		if (minRes < 0) {
			throw new IllegalArgumentException("minRes < 0");
		}
		this.minRes = minRes;
	}

	/**
	 * @return the maxRes
	 */
	public int getMaxRes() {
		return maxRes;
	}

	/**
	 * @param maxRes
	 *            the maxRes to set
	 */
	public void setMaxRes(int maxRes) {
		if (maxRes < 0) {
			throw new IllegalArgumentException("maxRes < 0");
		}
		this.maxRes = maxRes;
	}

	/**
	 * @return the width
	 */
	public float getWidth() {
		return width;
	}

	/**
	 * @param width
	 *            the width to set
	 */
	public void setWidth(float width) {
		this.width = width;
	}

	/**
	 * @return the length
	 */
	public float getLength() {
		return length;
	}

	/**
	 * @param length
	 *            the length to set
	 */
	public void setLength(float length) {
		this.length = length;
	}

	Matrix4f getTransform() {
		Matrix4f mat = Matrix4f.setIdentity(new Matrix4f());
		mat.scale(new Vector3f(width, 1f, length));
		return mat;
	}

	/**
	 * @return the heightMaps
	 */
	public HeightMap getHeightMap() {
		return heightMap;
	}

	/**
	 * @param heightMaps
	 *            the heightMaps to set
	 */
	public void setHeightMap(HeightMap heightMap) {
		this.heightMap = heightMap;
		normalMap = Loader.loadEmptyTexture(heightMap.width, heightMap.height, GL11.GL_RGBA);
		GameEngine.getRenderer().getNormalMapRenderer().render(normalMap, heightMap.texture, heightMap.width, 1f);
	}

	/**
	 * @return the normalMap
	 */
	public int getNormalMap() {
		return normalMap;
	}

	/**
	 * @param normalMap the normalMap to set
	 */
	public void setNormalMap(int normalMap) {
		this.normalMap = normalMap;
	}

	/**
	 * @return the materials
	 */
	public List<Material> getMaterials() {
		return materials;
	}
}
