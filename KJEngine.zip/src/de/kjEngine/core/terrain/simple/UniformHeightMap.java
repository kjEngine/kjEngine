package de.kjEngine.core.terrain.simple;

import de.kjEngine.core.uniforms.Uniform;
import de.kjEngine.core.uniforms.UniformFloat;
import de.kjEngine.core.uniforms.UniformInt;

public class UniformHeightMap extends Uniform {
	
	private UniformInt sampler;
	private UniformFloat tileSize, amplitude;

	public UniformHeightMap(int program, String name) {
		super(program, name);
	}

	@Override
	protected void storeUniformLocation(int programID) {
		sampler = new UniformInt(programID, name + ".map");
		tileSize = new UniformFloat(programID, name + ".tile_size");
		amplitude = new UniformFloat(programID, name + ".amplitude");
	}
	
	public void loadHeightMap(HeightMap map) {
		loadHeightMap(map.sampler, map.tile_size, map.amplitude);
	}
	
	public void loadHeightMap(int sampler, float tile_size, float amplitude) {
		this.sampler.loadInt(sampler);
		this.tileSize.loadFloat(tile_size);
		this.amplitude.loadFloat(amplitude);
	}
}
