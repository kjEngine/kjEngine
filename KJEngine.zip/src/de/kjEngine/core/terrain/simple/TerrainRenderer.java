package de.kjEngine.core.terrain.simple;

import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL40;
import org.lwjgl.util.vector.Matrix4f;

import de.kjEngine.core.api.Camera;
import de.kjEngine.core.light.advanced.Material;
import de.kjEngine.core.util.OpenGlUtils;

public class TerrainRenderer {

	private TerrainShader shader;

	public TerrainRenderer() {
		shader = new TerrainShader();
	}

	public void render(Matrix4f mMat, Camera cam, Matrix4f pMat, LODTerrain terrain, int width, int length) {
		shader.enable();
		loadUniforms(mMat, cam, pMat, terrain, width, length);

		OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE0, terrain.getHeightMap().texture);
		OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE1, terrain.getNormalMap());
		
		for (int i = 0; i < terrain.getMaterials().size(); i++) {
			OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE0 + i + 2, terrain.getMaterials().get(i).getDisplacemap());
			OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE0 + i + 4, terrain.getMaterials().get(i).getDiffusemap());
			OpenGlUtils.loadTexture2D(GL13.GL_TEXTURE0 + i + 6, terrain.getMaterials().get(i).getNormalmap());
		}

		OpenGlUtils.cullBackFaces(true);

		GL40.glPatchParameteri(GL40.GL_PATCH_VERTICES, 1);
		if (Keyboard.isKeyDown(Keyboard.KEY_G)) {
			OpenGlUtils.goWireframe(true);
		}
		GL11.glDrawArrays(GL40.GL_PATCHES, 0, 1 * width * length);
		shader.disable();
	}

	private void loadUniforms(Matrix4f mMat, Camera cam, Matrix4f pMat, LODTerrain terrain, int width, int length) {
		shader.camPos.loadVec3(cam.getPos());
		shader.mMat.loadMatrix(Matrix4f.mul(mMat, terrain.getTransform(), null));
		shader.vMat.loadMatrix(cam.getLocation());
		shader.pMat.loadMatrix(pMat);
		shader.width.loadInt(width);
		shader.length.loadInt(length);
		shader.heightMap.loadHeightMap(terrain.getHeightMap());
		shader.materials.loadMaterialArray(terrain.getMaterials().toArray(new Material[2]), new int[] { 2, 3 },
				new int[] { 4, 5 }, new int[] { 6, 7 });
	}
}
