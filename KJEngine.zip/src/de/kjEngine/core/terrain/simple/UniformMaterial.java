package de.kjEngine.core.terrain.simple;

import de.kjEngine.core.light.advanced.Material;
import de.kjEngine.core.uniforms.Uniform;
import de.kjEngine.core.uniforms.UniformFloat;
import de.kjEngine.core.uniforms.UniformInt;

public class UniformMaterial extends Uniform {
	
	private UniformInt disp, diff, nrm;
	private UniformFloat heightScale, horizontalScale;

	protected UniformMaterial(int program, String name) {
		super(program, name);
	}

	@Override
	protected void storeUniformLocation(int programID) {
		disp = new UniformInt(programID, name + ".disp");
		diff = new UniformInt(programID, name + ".diff");
		nrm = new UniformInt(programID, name + ".nrm");
		heightScale = new UniformFloat(programID, name + ".heightScale");
		horizontalScale = new UniformFloat(programID, name + ".horizontalScale");
	}
	
	public void loadMaterial(Material m, int disp_sampler, int diff_sampler, int nrm_sampler) {
		disp.loadInt(disp_sampler);
		diff.loadInt(diff_sampler);
		nrm.loadInt(nrm_sampler);
		heightScale.loadFloat(m.getDisplaceScale());
		horizontalScale.loadFloat(m.getHorizontalScale());
	}
}
