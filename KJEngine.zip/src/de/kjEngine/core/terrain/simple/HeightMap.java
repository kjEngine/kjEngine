package de.kjEngine.core.terrain.simple;

public class HeightMap {
	
	public int sampler, texture;
	public float tile_size, amplitude;
	public final int width, height;

	public HeightMap(int sampler, int texture, float tile_size, float amplitude, int width, int height) {
		this.sampler = sampler;
		this.texture = texture;
		this.tile_size = tile_size;
		this.amplitude = amplitude;
		this.width = width;
		this.height = height;
	}
}
