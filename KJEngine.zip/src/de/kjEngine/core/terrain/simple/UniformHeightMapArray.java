package de.kjEngine.core.terrain.simple;

import de.kjEngine.core.uniforms.Uniform;

public class UniformHeightMapArray extends Uniform {
	
	private UniformHeightMap[] heightMaps;

	public UniformHeightMapArray(int program, String name, int size) {
		super(program, name);
		heightMaps = new UniformHeightMap[size];
		for (int i = 0; i < heightMaps.length; i++) {
			heightMaps[i] = new UniformHeightMap(program, name + "[" + i + "]");
		}
	}

	@Override
	protected void storeUniformLocation(int programID) {
	}
	
	public void loadHeightMaps(HeightMap[] maps) {
		for (int i = 0; i < maps.length; i++) {
			heightMaps[i].loadHeightMap(maps[i]);
		}
	}
}
