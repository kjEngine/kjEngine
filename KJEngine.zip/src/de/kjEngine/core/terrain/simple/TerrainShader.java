package de.kjEngine.core.terrain.simple;

import de.kjEngine.core.api.Shader;
import de.kjEngine.core.uniforms.UniformInt;
import de.kjEngine.core.uniforms.UniformMat4;
import de.kjEngine.core.uniforms.UniformVec3;

public class TerrainShader extends Shader {

	public UniformVec3 camPos;
	public UniformMat4 mMat, vMat, pMat;
	public UniformInt width, length;
	public UniformHeightMap heightMap;
	public UniformMaterialArray materials;

	public TerrainShader() {
		super("/de/kjEngine/core/terrain/simple/vertexShader.glsl",
				"/de/kjEngine/core/terrain/simple/fragmentShader.glsl",
				"/de/kjEngine/core/terrain/simple/tessControlShader.glsl",
				"/de/kjEngine/core/terrain/simple/tessEvaluationShader.glsl",
				"/de/kjEngine/core/terrain/simple/geometryShader.glsl");
	}

	@Override
	protected void loadUniformLocations() {
		camPos = new UniformVec3(id, "camPos");
		mMat = new UniformMat4(id, "mMat");
		vMat = new UniformMat4(id, "vMat");
		pMat = new UniformMat4(id, "pMat");
		width = new UniformInt(id, "width");
		length = new UniformInt(id, "length");
		heightMap = new UniformHeightMap(id, "hm");
		materials = new UniformMaterialArray(id, "materials", 2);
	}
}
