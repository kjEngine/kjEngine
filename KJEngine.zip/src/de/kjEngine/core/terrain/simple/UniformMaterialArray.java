package de.kjEngine.core.terrain.simple;

import de.kjEngine.core.light.advanced.Material;
import de.kjEngine.core.uniforms.Uniform;

public class UniformMaterialArray extends Uniform {

	private UniformMaterial[] array;

	protected UniformMaterialArray(int program, String name, int size) {
		super(program, name);
		array = new UniformMaterial[size];
		for (int i = 0; i < size; i++) {
			array[i] = new UniformMaterial(program, name + "[" + i + "]");
		}
	}

	@Override
	protected void storeUniformLocation(int programID) {
	}

	public void loadMaterialArray(Material[] m, int[] disp_sampler, int[] diff_sampler, int[] nrm_sampler) {
		for (int i = 0; i < m.length; i++) {
			if (m[i] != null) {
				array[i].loadMaterial(m[i], disp_sampler[i], diff_sampler[i], nrm_sampler[i]);
			}
		}
	}
}
